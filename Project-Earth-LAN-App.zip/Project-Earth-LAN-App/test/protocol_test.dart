// Prueft die App gegen echte Pakete, die der Windows-Manager erzeugt hat
// (Testvektoren mit Netzwerk-Code "TestCode12345678").
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:project_earth_lan/core/mail_crypto.dart';
import 'package:project_earth_lan/core/mail_service.dart';
import 'package:project_earth_lan/core/status_service.dart';
import 'package:project_earth_lan/core/util.dart';
import 'package:project_earth_lan/core/voice_service.dart';

const secret = 'TestCode12345678';

void main() {
  test('HMAC wie Get-PelHmacBase64', () {
    expect(pelHmac(secret, ''), '09RBrLqcgGmItiYPFJ4GUXjSCQzoed0DzT90rS4wEe0=');
    expect(pelHmac(secret, 'abc'), '3edUm4o1RCgvgUDKFNXetHnWZvwQlIPIMS6DOkakFZo=');
  });

  test('PESTAT1 V1 (F.E.A.R.-Server)', () {
    final p = buildPestat(
      secret: secret,
      name: 'Alex-PC',
      ip: '10.147.17.5',
      zt: true,
      friendsOnline: 2,
      friendsTotal: 5,
      version: '2026.09.23',
      gameTitle: 'F.E.A.R. Combat (Server)',
      gameExe: 'FEARMP.exe',
      joinPort: 27888,
    );
    expect(p,
        'PESTAT1|Alex-PC|10.147.17.5|1|2|5|2026.09.23|F.E.A.R. Combat (Server)|FEARMP.exe|27888||igY5m3VIbvRVu58o9ne2444ViItx9F8k/5hmQK1axPQ=');
  });

  test('PESTAT1 V3 (Umlaute, ohne ZeroTier)', () {
    final p = buildPestat(secret: secret, name: 'Jürgen Müller', ip: '', zt: false, version: '2026.09.23');
    expect(p, 'PESTAT1|Jürgen Müller||0|0|0|2026.09.23|||0||G1T5w9RFp9I14FHRdp1quTqBULXFxizZP4hfPYvTcKM=');
  });

  test('PESTAT1 V4 (Titel bereinigen)', () {
    final p = buildPestat(
      secret: secret,
      name: 'Alex-PC',
      ip: '10.147.17.5',
      zt: true,
      version: '2026.09.23',
      gameTitle: '  A|B\tSuper Long Game Title That Goes On And On Forever ÄÖÜ',
      gameExe: 'a|b.exe',
    );
    expect(p,
        'PESTAT1|Alex-PC|10.147.17.5|1|0|0|2026.09.23|A/B Super Long Game Title That Goes On And On Fo|a/b.exe|0||t6Z0uY4LucJtvGeiDSM7Avi6jLCz4rmL7yU7jil7+No=');
  });

  test('PEEVTREQ1 V5', () {
    expect(pelSigned(secret, 'PEEVTREQ1|1790000000000'),
        'PEEVTREQ1|1790000000000|6jZ/ukZKvG792jTPI6ygsKYcpWX47KMnMUniQcql7hM=');
  });

  test('PEEVT1 V6/V7 bauen und lesen', () {
    final e = PelEvent(
      id: 'a1b2c3d4e5f6',
      title: 'FEAR-Abend',
      game: 'F.E.A.R. Combat',
      organizer: 'Alex-PC',
      note: 'Bitte vorher patchen: 1.08 - Grüße!',
      start: 1790100000,
      created: 1790000000,
      cancelHash: sha256B64('00112233445566778899aabbccddeeff'),
    );
    expect(e.cancelHash, 'WUfXwz14P5SztMGpbryJke0o8bBptx4DN2y6jKqYpyA=');
    const v6 =
        'PEEVT1|a1b2c3d4e5f6|1790100000|1790000000|RkVBUi1BYmVuZA==|Ri5FLkEuUi4gQ29tYmF0|QWxleC1QQw==|Qml0dGUgdm9yaGVyIHBhdGNoZW46IDEuMDggLSBHcsO8w59lIQ==|WUfXwz14P5SztMGpbryJke0o8bBptx4DN2y6jKqYpyA=|0||88IM5GDmCEzafHalf0+d/2lrYeT7HoVgxOrdTTdqMzg=';
    expect(buildEventWire(secret, e), v6);
    e.cancelled = true;
    e.cancelToken = '00112233445566778899aabbccddeeff';
    expect(buildEventWire(secret, e).endsWith('|1|00112233445566778899aabbccddeeff|T3TSfFjZXzwzho8XKe5auHEniD4+hBKAhwRU1uErMsI='), isTrue);
    final back = parseEventWire(secret, v6)!;
    expect(back.note, 'Bitte vorher patchen: 1.08 - Grüße!');
    expect(parseEventWire(secret, v6.replaceFirst('a1b2c3d4e5f6', 'a1b2c3d4e5f7')), isNull);
  });

  test('PEEVT1 V8 (leere Felder)', () {
    const v8 =
        'PEEVT1|0123456789ab|1790200000|1790000100|TEFO||Qm9i||WUfXwz14P5SztMGpbryJke0o8bBptx4DN2y6jKqYpyA=|0||YrGi0/kxuNrwnoOFpNN2K00obeCHJNoxMbLF+MQuwzI=';
    final e = parseEventWire(secret, v8)!;
    expect(e.title, 'LAN');
    expect(e.game, '');
    expect(buildEventWire(secret, e), v8);
  });

  test('Postfach: MSG-Zeile wie der Windows-Manager', () {
    const body = 'Hallo Test\nZeile 2 mit Umlaut: äöü ß \\ Backslash';
    final core = 'PEMAIL1|MSG|0123456789abcdef0123456789abcdef|${b64Text('Alex-PC')}|10.147.20.9|1790000000000|'
        '${b64Text('Hallo Test')}|${b64Text(body)}';
    expect(pelSigned(secret, core),
        'PEMAIL1|MSG|0123456789abcdef0123456789abcdef|QWxleC1QQw==|10.147.20.9|1790000000000|SGFsbG8gVGVzdA==|SGFsbG8gVGVzdApaZWlsZSAyIG1pdCBVbWxhdXQ6IMOkw7bDvCDDnyBcIEJhY2tzbGFzaA==|XNtNPKOPLAMpR9xs/fmkdtKeg1d8nANVSKSJbQhbf04=');
  });

  test('Postfach: PEMSG1 hin und zurueck', () {
    final m = MailMsg()
      ..id = '0123456789abcdef0123456789abcdef'
      ..fromName = 'Alex-PC'
      ..fromIp = '10.147.20.5'
      ..toIp = '10.147.20.9'
      ..subject = 'Hallo Test'
      ..createdUtc = 1790000000000
      ..body = 'Hallo Test\nZeile 2 mit Umlaut: äöü ß \\ Backslash';
    final t = m.toText();
    expect(t.contains('Body=Hallo Test\\nZeile 2 mit Umlaut: äöü ß \\\\ Backslash\n'), isTrue);
    final back = MailMsg.fromText(t)!;
    expect(back.body, m.body);
    expect(back.signText, '0123456789abcdef0123456789abcdef|10.147.20.5|10.147.20.9|1790000000000|Hallo Test|${m.body}');
  });

  test('Postfach: Versiegeln/Oeffnen/Signieren mit .NET-Schluesseln', () {
    final priv = RsaKeys.fromXml(_recipientPrivXml)!;
    final pub = RsaKeys.fromXml(priv.toPublicXml())!;
    expect(priv.toPublicXml(), _recipientPubXml);
    final blob = seal(pub, 'PEMSG1\nId=0123456789abcdef0123456789abcdef\nBody=Hallo\n');
    final raw = base64.decode(blob);
    expect(raw[0], 1);
    expect((raw[1] << 8) | raw[2], 256);
    expect(openSealed(priv, blob), 'PEMSG1\nId=0123456789abcdef0123456789abcdef\nBody=Hallo\n');
    final sig = signText(priv, 'abc');
    expect(base64.decode(sig).length, 256);
    expect(verifyText(pub, 'abc', sig), isTrue);
    expect(verifyText(pub, 'abd', sig), isFalse);
    // Neu erzeugtes privates XML muss dieselben festen Laengen wie .NET haben
    expect(RsaKeys.fromXml(priv.toPrivateXml())!.toPrivateXml(), priv.toPrivateXml());
  });

  test('Postfach: echter Windows-Block oeffnen, Signatur identisch', () {
    final recipient = RsaKeys.fromXml(_recipientPrivXml)!;
    final sender = RsaKeys.fromXml(_senderPrivXml)!;
    final senderPub = RsaKeys.fromXml(_senderPubXml)!;
    final plain = openSealed(recipient, _dotnetSealedBlob);
    expect(plain, _dotnetInnerPlain);
    final inner = MailMsg.fromText(plain!)!;
    expect(inner.signText, _dotnetSignText);
    expect(verifyText(senderPub, inner.signText, inner.blob), isTrue);
    // PKCS#1 v1.5 ist deterministisch -> gleiche Signatur wie .NET
    expect(signText(sender, _dotnetSignText), _dotnetSignature);
    // gleicher Aufbau des inneren Datensatzes wie EarthMailStore.ToText
    final again = MailMsg()
      ..id = inner.id
      ..fromName = inner.fromName
      ..fromIp = inner.fromIp
      ..toIp = inner.toIp
      ..createdUtc = inner.createdUtc
      ..subject = inner.subject
      ..body = inner.body
      ..blob = inner.blob;
    expect(again.toText(), _dotnetInnerPlain);
  });

  test('Voice: Kanal-Passwort und u-law wie EarthVoiceNode', () {
    expect(voiceHashPw('Lobby', 'TestCode12345678'), '9E1111EDEB87084C6D899A09B361A89B');
    expect(voiceHashPw('Lobby', ''), 'EB8522D21CB8AC33DB355139D0B2563B');
    expect(muLawEncode(0), 0xFF);
    expect(muLawEncode(1000), 0xCE);
    expect(muLawEncode(-1000), 0x4E);
    expect(muLawEncode(32767), 0x80);
    expect(muLawEncode(-32768), 0x00);
    expect(muLawDecode(0xCE), 988);
    expect(muLawDecode(0x4E), -988);
    expect(muLawDecode(0x80), 32124);
    expect(muLawDecode(muLawEncode(5)), 8);
  });

  test('Subnetz-Rechnung', () {
    expect(broadcastFor('10.147.17.5', 24), '10.147.17.255');
    expect(broadcastFor('10.147.17.5', 16), '10.147.255.255');
    expect(hostsInSubnet('10.147.17.5', 16).length, 254);
    expect(dateToTicks(DateTime.fromMillisecondsSinceEpoch(1700000000000, isUtc: true)), 638355968000000000);
    expect(isValidIpv4('10.147.17.05'), isFalse);
  });
}

const _recipientPrivXml =
    '<RSAKeyValue><Modulus>67xbT5qpp9v77U1wUGKyGNlsE2rRETo9RQ8/cpIMbE0F3ivmYEMuJAE7NSeJ+whCYshqFHYBgsUz5JjQaK+HK6ah0BW6MlGutSRidBPTCIxzShLHZuSGW0U4r9jkXlYcjBKs37/YvKPwstd1Q23OumtlsJp/dSph3D8wtiZ5UaQunnj44xA4NVOO0VAR1ref5t67iYtnvt0tccYGn9vkqPCesfPy2NJUihaSgphxnCkmb/xdaDJbomNiPa4bwKL03/BdzpXEvegFTWH6hIEZM5jCOeKRWMjPDlXLWegojiHF597PUZf7IEmaeOh63Jx0er2d+hit5aRsDcVHzKCSCQ==</Modulus><Exponent>AQAB</Exponent><P>/L6YLHHNYN98mTk4tFbeac2BGY72SNO4rG5HT5yX4+h7VC0fJZkKsED8rYwdT+MGRFvg7csR5dePoCeKCeikFicsCrWM5tJ+ORyHcsO3R1XZqmNebG3AseHakbJuAcfpiRtJzxqiUpRdLqcLgc0Vhw46l3zK0sYi/pTWKSUB9Fc=</P><Q>7sWtX5kK3cgk4JoZfNLa0BgwNToNJwEd5wX6VvTu2eu+DM+lrUijzlqhKdpNIgrqqC8Y/DsAN8gqG0RQtiKYjyXcG+FTLj0cJG6lhn8bx2x6iLqJ1bMWClBpWpVvtwrXNs/TWWCiZ4z1qrncHN3MdsPuzjThy1ADnMFWeBZCsJ8=</Q><DP>1HSaknGvRMlYgax6IA4NtD6NUSC9ooZm7Hte8msduvUIBsBPOFmnhHV8cZ4gXbDm6buaHgnfp6dGEkhqXt3yYLTY7r+iC73RYMy8hxpCDHL8H6CcFOVFX8IM6wBkPJcBlsEbkD5BSM1ybu74W0o72GV7ly/NhtQLQpl2VOvI8s0=</DP><DQ>edUjwcO1Z7TYHEKE/swYGlY9Qut8CornVxoVwoj31voS3zaUsvZ9nq1fzps1AEnRsj9V4F26nrvjwEX7aPP+JAyNYyx15QIJeg17KEVzRy5y15FXA1N9y4V8PFxDxIIjjjQ9Az3roCqsr5BmX9RMn80Z7N3O2I7bSQDdviidnsE=</DQ><InverseQ>GVzc9UEIXnfC/GmS0XK2QRQTRRJ9hCxvIqUsyw/Bh6tM3d3X3R/HFXCwsnnebcUew7aVNEDGJxcFspmZ9sNDeyu0zebUn7SLQRDsSMUF0YFY+lUcEa9odUosglya9Y28lWSN3sTjNoiNDAHRJT1LeRpKa5wHbJK5ShONKEhhiyg=</InverseQ><D>CbeedfYUp0A4rswB5LZkzARuYZCGJLUnYGjj/yeJDo/QPZvGp9ItHTvVwneqRuhMwECtqsFAh7D0Vih8csxFgKWiRu8WWUunrXzd+BX3HYOYnwWOJa4m4a1FTG5e34qiK537dU+1sfT6D401Hr3whxu1OeXsehpwpUEPk3qbhqNvK63R/0mzZkVgeyXTdJ4Z+1Nxh7AzJnj2MQ6bXQviiWMyTn0uTqQyBd4BLISy5O4ZaNjEg9d7ZuWyZDTXs28PuakL2aaKIt+9mhJQRnJTqN6gHZGgYVh/sYWlEdvPRkSWGBitdWlCJSBrzj7+1Kfwizts5INb1XxEtcS7nQNSjw==</D></RSAKeyValue>';

const _recipientPubXml =
    '<RSAKeyValue><Modulus>67xbT5qpp9v77U1wUGKyGNlsE2rRETo9RQ8/cpIMbE0F3ivmYEMuJAE7NSeJ+whCYshqFHYBgsUz5JjQaK+HK6ah0BW6MlGutSRidBPTCIxzShLHZuSGW0U4r9jkXlYcjBKs37/YvKPwstd1Q23OumtlsJp/dSph3D8wtiZ5UaQunnj44xA4NVOO0VAR1ref5t67iYtnvt0tccYGn9vkqPCesfPy2NJUihaSgphxnCkmb/xdaDJbomNiPa4bwKL03/BdzpXEvegFTWH6hIEZM5jCOeKRWMjPDlXLWegojiHF597PUZf7IEmaeOh63Jx0er2d+hit5aRsDcVHzKCSCQ==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>';

const _senderPrivXml = '<RSAKeyValue><Modulus>rRBErlYu/43+b8hpmEnSFPI+WNcc7Z/rKBL62W8djdl5YKZe4Bxxs7aBBgQJyfphf+DEPw4STFg/19eMsHVEQ2AQ5yvrnGOQyCovC6QL6XMbTV1N4bIbjKkxXROC2qZ5UJ9YkW6lcSH0KkTrHchDjIIm/WW0z+bObOSpmPAdFAkgi6N6mG/hLQPQFm2W3uVamVyCbrO6Xas4UY7UGFzplgwy0qn7lMOtdWc2wkiHrc4dBM8HkkE4F0mrC1yWwhNCDJR6+2CaFKINKHWMwDaRmPu6sjeVVQGsE3hy+50Y8VZd/6PKHPrAbJEZ65zodg6OUKt118K/cZOGoMR0AqnxNw==</Modulus><Exponent>AQAB</Exponent><P>3PBBcXAb2PsS8N/ywoqDvTBhua0zuPGrW4iwUdMBkjiXY9Vik0iE49GypPRGVlCrRwIIbA/id8hiUxKhaQcS08YRJph+4NbYTLc96zBItdLU2PFfJ1DuKasYqigbgUKEaRMZa9Q/W3YrrAkBjMhzzwuLs2HrIUEQyvtmc6rYurE=</P><Q>yIcRNr7l919z1v/KuJiEXtkKSOVAXDg+PEV2mDr3RTsk4ty3jrLXk0krBs5pDXmoViMcJd8D/Cn7YsWdUslv3f/mZW+barIIXuqAURkrBZJrcMDex2tkZkfj7hGKMp1jnuG9kVzMUGLsSUdCWQAz5wQUq+6a+Dy1ge0UEAsxFGc=</Q><DP>zIw22pJDhfB1icKcm1XoP8jCQUhEoY5E6nqzWx3yz3BLYOdW2ysBtXYYYbWyRQlseVI9f+Z48hL4TRbrjzQ4Tw6KJGR82yatnODtl4fdWVD3NF7LjLfVt4grTqXRSSvPMQS4vWcEvWW7awvvfmq7JU34KbyXFvOJW5PDN4VOIBE=</DP><DQ>cVF6ldBdDmTfhnD4c0alDyBhon4C19pkuRScBzzTPUlF9/m4tSg1kKL5cJg2X4oPadXfcztK+jYTPGbmF8GDuRWCcnIWhr3i4xhruOibGkP6+TXU7yauDuqzUHaS/TVZ9ZAl2z5wq0CrvGFLihYGPpdcwyhMZNmRzMFX5BUfACM=</DQ><InverseQ>gyYMtOVPWMr7vzF1PWEmYxSgRweWQw7z/WoEx+sYX3PbMdSkSWwu0rNOtV/eveFORvrUlJWXHaZ5ugQ92nYSrj9qh3cwMMjTKMwtT+7oY75moU7N4GCaadIXwTa26cTlF8iGBfXLSqng9LlIAi2Wk50D7Q9U3OW9EOx4Ust3H0Y=</InverseQ><D>A1V5ZTxeymiDWsbrFdZyOBoUjmSSd5dpkcuPzol/8cAbQPvjfwC9Rf+Bi8qfH6d1ol+DmE1el97pV/CckrenmX6rxLBJaSlX3CtH3bsKybQAdiSSgAMM2dBWlZrvHeQwGRgAvkh54myLhhbuypOVjYriUmZXrdud5WYgSERz4vNj8Re/fe1zYIKtGlSZLCzObDpvVCBbv9v+ihmB3jJgUQ3mGBh9UiG1X9gfd94M3XB6LyZa/sscVTPAdPwhwB6PUPTr+37Cu5l9lflJEQie1L9LJXs7NNzGt297XtoztbrA6JNabT8dT9v5Ew8LaKi/CL28cN1/uuscrgqqmOdK0Q==</D></RSAKeyValue>';

const _senderPubXml = '<RSAKeyValue><Modulus>rRBErlYu/43+b8hpmEnSFPI+WNcc7Z/rKBL62W8djdl5YKZe4Bxxs7aBBgQJyfphf+DEPw4STFg/19eMsHVEQ2AQ5yvrnGOQyCovC6QL6XMbTV1N4bIbjKkxXROC2qZ5UJ9YkW6lcSH0KkTrHchDjIIm/WW0z+bObOSpmPAdFAkgi6N6mG/hLQPQFm2W3uVamVyCbrO6Xas4UY7UGFzplgwy0qn7lMOtdWc2wkiHrc4dBM8HkkE4F0mrC1yWwhNCDJR6+2CaFKINKHWMwDaRmPu6sjeVVQGsE3hy+50Y8VZd/6PKHPrAbJEZ65zodg6OUKt118K/cZOGoMR0AqnxNw==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>';

const _dotnetSealedBlob = 'AQEAMRnj5Z3Z9Zq0KcMkr0SygHhMJBnNIYx1DbN97N7/egc0C3yGUdAHhKDOsj87eSMMhudPt81JQszXow6ru2FJgDYz5wi2Wj5yK0KfW8IMgAEUvt5ySNXiOyvwyUo/3SZZQ73bbEx4dlGpn0w+X9FhsFe+W33Mj++eIilEzQwMfu7E4JkieoOZ6hWxnFGrhENLga8RoQZt5U/aHrmNyP5Y5wwcX9OhwJx5z/DP2A9UlE+/DL/CV60FakL23SrfuXY81e7qCoPtYyGO8J3exC7nH8s/smlVOPtZk5DBmi6sIxbrJwbPzED5H5AdfQtPK6uZT4nJIQP43+dUdMiiSP/JdK5eq8Q/WgZcTn9iCHvEQIJ9XBYIfFvF/y2Z6pYE1Cj4NkiAMo/PhxsR2XDn+F+VJb5SporR6qeZZ6tRrY8TgPaNYUAFuk7xfq8a2bSffsegdHFxSm44a/S5frQz2FxSUIiNZc3o/gM2iZDpl8xR0Uf9F2NpLj/yj/qVX9o1qKM7YJLIjxpy6nT/5cAWafJCf5ZYmulAs6Yvm2Sp7jFxngweoUklJz4hfFpbYPPRG9p4u9K7rwxrKy0r/8uOzmzAIjToLRtNFRIHPn/gltxu8ttwIbRdNh8Td5439ChiiVHLCewmDf5O2eRePrlaq/21NTp6mXZSLJtUtIhPgsadipT53AEyZDPtTNK/AwHf0X5vzksf4W5jD78/t+NdEORStSK18hHSL/HjCH0eBNfY+NSAnt2nIym0Sn3A+0TjKWOLbcEfuIaW3LFXvc2kKFJGAg0wWIDEi2pLJCPPBoP7e8IS/mlqlDxQkr37O/f6w+WzUL13NWKzowacO8h0QENyhWc0IyG23DjaySBRaGexvwAa2hftUNZmfegRK68NZX1C9K1e4c2bIzk4pKfdRMhqfAdU7YNfLgiUfNHyewGZHBjs4+Q2YqiyZS7Ysu5GB9f7Ut/3us6GoUtOpGewVPx3trAoqAjM1JAu5NhalKaDdPrBlF5ITLWTreNQIXbWZ6IVoNHhIkhRuRgKgzFf8//MEbV4BAeMw6NTvg6A4nYHJZIins+bab4Vyr6toJWX/MjomTxLEJp29z9Eoyi2hDNymWkGy9iKw8H/XkEVBCD32x4CEpsDtEByCel5LW/elC7WRFHjhgJevHi07lnxvCLXoEaVTdsr+KpdDaf+33lzDO95wptC66N5x8jrif0vdXnpcr5yAiifNX+AcXeWBFmHUvYOwM4IalBzGg59nPv+Gx/bIiCMGfM+j5oxA9cSfo/M5FgObUCx72+x38OpGxgh+9u/+j6PQ0AYIZDitzIoYIc=';

const _dotnetInnerPlain = 'PEMSG1\nId=0123456789abcdef0123456789abcdef\nFromName=Alex-PC\nFromIp=10.147.20.5\nToName=\nToIp=10.147.20.9\nSubject=Hallo Test\nCreatedUtc=1790000000000\nReceivedUtc=0\nDeliveredUtc=0\nRead=0\nVia=\nVerified=0\nAttempts=0\nNextTryUtc=0\nLastError=\nRelayed=0\nRelayedTo=\nExpiresUtc=0\nBlob=kmJSwG8jnFjodKyMWuAMlv04l0p91HBToIixwPpp7yUGx68mK9numVFeIcS1h6z5zf896ECHFTTunlZuEUmV3TmgmxcjO1ZerCA3OtnSLh6E6lJFVtr8azaPNkZjEuoVrrnIs+Q9mY1OkdEpDC8jxw4Z0BwCXOOv9w7qF9e4KfvZWWJALazyf77IPwFWGSup9AC6kqnqIdfxrG40JVVXA7E9v1qFoGzeh4zTSnwrreybIbNl7L0/NsMwe/5ENWpH9/xObYMRYGwmB5d/EasJ1RsYAJ2patrtlBrXYAok/7C0r4cw4wU+8S3JMVUlnSA4maWMeh0W95xhJuqr05q92A==\nBody=Hallo Test\\nZeile 2 mit Umlaut: äöü ß \\\\ Backslash\n';

const _dotnetSignText = '0123456789abcdef0123456789abcdef|10.147.20.5|10.147.20.9|1790000000000|Hallo Test|Hallo Test\nZeile 2 mit Umlaut: äöü ß \\ Backslash';

const _dotnetSignature = 'kmJSwG8jnFjodKyMWuAMlv04l0p91HBToIixwPpp7yUGx68mK9numVFeIcS1h6z5zf896ECHFTTunlZuEUmV3TmgmxcjO1ZerCA3OtnSLh6E6lJFVtr8azaPNkZjEuoVrrnIs+Q9mY1OkdEpDC8jxw4Z0BwCXOOv9w7qF9e4KfvZWWJALazyf77IPwFWGSup9AC6kqnqIdfxrG40JVVXA7E9v1qFoGzeh4zTSnwrreybIbNl7L0/NsMwe/5ENWpH9/xObYMRYGwmB5d/EasJ1RsYAJ2patrtlBrXYAok/7C0r4cw4wU+8S3JMVUlnSA4maWMeh0W95xhJuqr05q92A==';
