// Mikrofon und Lautsprecher: 16 kHz, mono, 16 Bit (little endian).
//  * Android / macOS: eigener nativer Code (MainActivity.kt / PelAudio.swift)
//  * Linux: PulseAudio/PipeWire-Werkzeuge "parec"/"pacat" (Fallback: arecord/aplay)
import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';

abstract class AudioIo {
  /// Startet Aufnahme und Wiedergabe. Rueckgabe: Fehlermeldung oder null.
  Future<String?> start(void Function(Uint8List pcm) onPcm);
  void play(Uint8List pcm);
  Future<void> stop();

  static AudioIo create() => Platform.isLinux ? LinuxAudioIo() : NativeAudioIo();
}

class NativeAudioIo implements AudioIo {
  static const MethodChannel _ch = MethodChannel('projectearthlan/audio');
  static const EventChannel _in = EventChannel('projectearthlan/audio_in');
  StreamSubscription<dynamic>? _sub;
  bool _running = false;

  @override
  Future<String?> start(void Function(Uint8List pcm) onPcm) async {
    try {
      _sub = _in.receiveBroadcastStream().listen((dynamic d) {
        if (d is Uint8List) onPcm(d);
      }, onError: (Object _) {});
      await _ch.invokeMethod<void>('start');
      _running = true;
      return null;
    } on PlatformException catch (e) {
      await _sub?.cancel();
      _sub = null;
      return e.message ?? e.code;
    } catch (e) {
      await _sub?.cancel();
      _sub = null;
      return '$e';
    }
  }

  @override
  void play(Uint8List pcm) {
    if (!_running) return;
    _ch.invokeMethod<void>('play', pcm).catchError((Object _) {});
  }

  @override
  Future<void> stop() async {
    _running = false;
    try {
      await _ch.invokeMethod<void>('stop');
    } catch (_) {}
    await _sub?.cancel();
    _sub = null;
  }
}

class LinuxAudioIo implements AudioIo {
  Process? _rec;
  Process? _play;

  static const _fmt = <String>['--raw', '--format=s16le', '--rate=16000', '--channels=1'];

  @override
  Future<String?> start(void Function(Uint8List pcm) onPcm) async {
    var pulseOk = false;
    try {
      _rec = await Process.start('parec', <String>[..._fmt, '--latency-msec=40']);
      _play = await Process.start('pacat', <String>[..._fmt, '--latency-msec=80']);
      pulseOk = !await _diesQuickly(_rec!) && !await _diesQuickly(_play!);
    } catch (_) {
      pulseOk = false;
    }
    if (!pulseOk) {
      await stop();
      try {
        _rec = await Process.start('arecord', <String>['-q', '-t', 'raw', '-f', 'S16_LE', '-r', '16000', '-c', '1']);
        _play = await Process.start('aplay', <String>['-q', '-t', 'raw', '-f', 'S16_LE', '-r', '16000', '-c', '1']);
      } catch (_) {
        await stop();
        return 'Kein Audio-Werkzeug gefunden. Bitte "pulseaudio-utils" (parec/pacat) oder "alsa-utils" installieren.';
      }
      if (await _diesQuickly(_rec!) || await _diesQuickly(_play!)) {
        await stop();
        return 'Mikrofon/Lautsprecher konnten nicht geöffnet werden (PulseAudio/PipeWire bzw. ALSA prüfen).';
      }
    }
    _play!.stdin.done.catchError((Object _) {});
    _rec!.stdout.listen((List<int> d) => onPcm(d is Uint8List ? d : Uint8List.fromList(d)));
    _rec!.stderr.drain<void>();
    _play!.stdout.drain<void>();
    _play!.stderr.drain<void>();
    return null;
  }

  /// true, wenn der Prozess innerhalb von 300 ms wieder beendet ist (z. B. kein Audio-Server).
  static Future<bool> _diesQuickly(Process p) async {
    final r = await Future.any<int?>(<Future<int?>>[
      p.exitCode.then<int?>((c) => c),
      Future<int?>.delayed(const Duration(milliseconds: 300), () => null),
    ]);
    return r != null;
  }

  @override
  void play(Uint8List pcm) {
    try {
      _play?.stdin.add(pcm);
    } catch (_) {}
  }

  @override
  Future<void> stop() async {
    try {
      _rec?.kill();
    } catch (_) {}
    try {
      await _play?.stdin.close();
    } catch (_) {}
    try {
      _play?.kill();
    } catch (_) {}
    _rec = null;
    _play = null;
  }
}
