// Gemeinsame Hilfsfunktionen: HMAC-Signatur (wie Get-PelHmacBase64 im
// Windows-Manager), Text-Bereinigung, IPv4-Rechnerei, Zeilen-/Byte-Leser fuer
// TCP-Verbindungen und ein einfacher Mutex.
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

final Random _rng = Random.secure();

/// Zufaellige Kleinbuchstaben-Hex-Zeichenkette (wie Guid.ToString("N").Substring(0, n)).
String randomHex(int chars) {
  const hex = '0123456789abcdef';
  final sb = StringBuffer();
  for (var i = 0; i < chars; i++) {
    sb.write(hex[_rng.nextInt(16)]);
  }
  return sb.toString();
}

Uint8List randomBytes(int n) {
  final b = Uint8List(n);
  for (var i = 0; i < n; i++) {
    b[i] = _rng.nextInt(256);
  }
  return b;
}

int nowMs() => DateTime.now().toUtc().millisecondsSinceEpoch;
int nowSec() => nowMs() ~/ 1000;

// ---------------------------------------------------------------- HMAC
/// Base64(HMAC-SHA256(key = UTF8(secret), msg = UTF8(text))) - 44 Zeichen.
String pelHmac(String secret, String text) {
  final h = Hmac(sha256, utf8.encode(secret));
  return base64.encode(h.convert(utf8.encode(text)).bytes);
}

/// "core|signatur"
String pelSigned(String secret, String core) => '$core|${pelHmac(secret, core)}';

bool constTimeEquals(String a, String b) {
  if (a.length != b.length) return false;
  var diff = 0;
  for (var i = 0; i < a.length; i++) {
    diff |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
  }
  return diff == 0;
}

/// Prueft "core|sig" und gibt die Felder des Kerns zurueck (oder null).
List<String>? pelCheckSigned(String secret, String line) {
  final cut = line.lastIndexOf('|');
  if (cut <= 0) return null;
  final core = line.substring(0, cut);
  final sig = line.substring(cut + 1);
  if (sig.isEmpty) return null;
  if (!constTimeEquals(pelHmac(secret, core), sig)) return null;
  return core.split('|');
}

// ---------------------------------------------------------------- Text
/// Wie Limit-PelText: CR/LF/TAB-Folgen -> ein Leerzeichen, trimmen, kuerzen.
String limitText(String s, int max) {
  var t = s.replaceAll(RegExp(r'[\r\n\t]+'), ' ').trim();
  if (t.length > max) t = t.substring(0, max);
  return t;
}

/// CleanName der C#-Dienste: CR/LF -> Leerzeichen, | -> /, trimmen, kuerzen.
String cleanName(String s, int max) {
  var t = s.replaceAll('\r', ' ').replaceAll('\n', ' ').replaceAll('|', '/').trim();
  if (t.length > max) t = t.substring(0, max);
  return t;
}

/// Name fuer den Live-Status (Get-PelDisplayName): | CR LF -> Leerzeichen, max 32.
String displayName(String s) {
  var t = s.replaceAll(RegExp(r'[|\r\n]'), ' ').trim();
  if (t.length > 32) t = t.substring(0, 32);
  return t;
}

String b64Text(String s) => s.isEmpty ? '' : base64.encode(utf8.encode(s));

String unB64Text(String s) {
  if (s.isEmpty) return '';
  try {
    return utf8.decode(base64.decode(s), allowMalformed: true);
  } catch (_) {
    return '';
  }
}

String two(int v) => v.toString().padLeft(2, '0');

String formatTime(DateTime t) => '${two(t.hour)}:${two(t.minute)}:${two(t.second)}';

String formatDateTime(DateTime t) =>
    '${two(t.day)}.${two(t.month)}.${t.year} ${two(t.hour)}:${two(t.minute)}';

String formatBytes(int b) {
  if (b < 0) return '';
  if (b >= 1 << 30) return '${(b / (1 << 30)).toStringAsFixed(1)} GB';
  if (b >= 1 << 20) return '${(b / (1 << 20)).toStringAsFixed(1)} MB';
  if (b >= 1 << 10) return '${(b / (1 << 10)).toStringAsFixed(0)} KB';
  return '$b B';
}

// ---------------------------------------------------------------- IPv4
bool isValidIpv4(String s) {
  final p = s.split('.');
  if (p.length != 4) return false;
  for (final x in p) {
    if (x.isEmpty || x.length > 3) return false;
    final v = int.tryParse(x);
    if (v == null || v < 0 || v > 255) return false;
    if (x.length > 1 && x.startsWith('0')) return false; // kanonisch wie IPAddress.ToString()
  }
  return true;
}

int ipToInt(String ip) {
  final p = ip.split('.').map(int.parse).toList();
  return (p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3];
}

String intToIp(int v) =>
    '${(v >> 24) & 255}.${(v >> 16) & 255}.${(v >> 8) & 255}.${v & 255}';

int prefixMask(int prefix) {
  if (prefix <= 0) return 0;
  if (prefix >= 32) return 0xFFFFFFFF;
  return (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF;
}

String broadcastFor(String ip, int prefix) {
  final m = prefixMask(prefix);
  return intToIp((ipToInt(ip) & m) | (~m & 0xFFFFFFFF));
}

/// Alle Hosts im Subnetz; bei mehr als [max] Hosts nur das eigene /24 (wie HostRange).
List<String> hostsInSubnet(String ip, int prefix, {int max = 1022}) {
  var pfx = prefix;
  if (pfx < 1 || pfx > 30) pfx = 24;
  final count = (1 << (32 - pfx)) - 2;
  if (count > max) pfx = 24;
  final m = prefixMask(pfx);
  final net = ipToInt(ip) & m;
  final bc = net | (~m & 0xFFFFFFFF);
  final out = <String>[];
  for (var v = net + 1; v < bc; v++) {
    out.add(intToIp(v));
  }
  return out;
}

bool sameSubnet(String a, String b, int prefix) {
  if (!isValidIpv4(a) || !isValidIpv4(b)) return false;
  final m = prefixMask(prefix);
  return (ipToInt(a) & m) == (ipToInt(b) & m);
}

// .NET-Ticks <-> Dateizeit
const int _ticksAtUnixEpoch = 621355968000000000;
int dateToTicks(DateTime d) => d.toUtc().millisecondsSinceEpoch * 10000 + _ticksAtUnixEpoch;
DateTime ticksToDate(int ticks) =>
    DateTime.fromMillisecondsSinceEpoch((ticks - _ticksAtUnixEpoch) ~/ 10000, isUtc: true);

// ---------------------------------------------------------------- Mutex
class Mutex {
  Future<void> _last = Future<void>.value();

  Future<T> run<T>(Future<T> Function() action) {
    final prev = _last;
    final done = Completer<void>();
    _last = done.future;
    return prev.then((_) => action()).whenComplete(done.complete);
  }
}

// ---------------------------------------------------------------- SocketReader
/// Liest Zeilen (bis LF) und feste Byte-Mengen aus einem Socket.
/// [crIsBreak]: true = ein einzelnes CR beendet ebenfalls eine Zeile (Chat-Verhalten
/// von StreamReader.ReadLine), false = CR wird verworfen (Datei-/Postfach-Dienste).
class SocketReader {
  SocketReader(Socket socket, {this.crIsBreak = false}) {
    _sub = socket.listen(
      (data) {
        _chunks.add(data);
        _wake();
      },
      onError: (Object _) {
        _done = true;
        _wake();
      },
      onDone: () {
        _done = true;
        _wake();
      },
      cancelOnError: true,
    );
  }

  final bool crIsBreak;
  late final StreamSubscription<Uint8List> _sub;
  final List<Uint8List> _chunks = <Uint8List>[];
  int _off = 0;
  bool _done = false;
  bool _skipLf = false;
  Completer<void>? _wait;

  bool get isDone => _done && _chunks.isEmpty;

  void _wake() {
    final w = _wait;
    _wait = null;
    if (w != null && !w.isCompleted) w.complete();
  }

  Future<void> _more(Duration? timeout) {
    if (_done) return Future<void>.value();
    final w = _wait ??= Completer<void>();
    return timeout == null ? w.future : w.future.timeout(timeout);
  }

  void _dropEmpty() {
    while (_chunks.isNotEmpty && _off >= _chunks.first.length) {
      _chunks.removeAt(0);
      _off = 0;
    }
  }

  /// Naechste Zeile ohne Zeilenende; null bei Verbindungsende ohne Daten.
  Future<String?> readLine({int maxBytes = 70000, Duration? timeout}) async {
    final tmp = <int>[];
    while (true) {
      _dropEmpty();
      while (_chunks.isNotEmpty) {
        final c = _chunks.first;
        while (_off < c.length) {
          final b = c[_off++];
          if (_skipLf) {
            _skipLf = false;
            if (b == 10) continue;
          }
          if (b == 10) {
            return utf8.decode(tmp, allowMalformed: true);
          }
          if (b == 13) {
            if (crIsBreak) {
              _skipLf = true;
              return utf8.decode(tmp, allowMalformed: true);
            }
            continue;
          }
          tmp.add(b);
          if (tmp.length > maxBytes) {
            throw const FormatException('Zeile zu lang');
          }
        }
        _dropEmpty();
      }
      if (_done) {
        if (tmp.isEmpty) return null;
        return utf8.decode(tmp, allowMalformed: true);
      }
      await _more(timeout);
    }
  }

  /// Genau [n] Bytes; null wenn die Verbindung vorher endet.
  Future<Uint8List?> readBytes(int n, {Duration? timeout}) async {
    final out = Uint8List(n);
    var got = 0;
    while (got < n) {
      _dropEmpty();
      if (_chunks.isNotEmpty) {
        final c = _chunks.first;
        final take = min(n - got, c.length - _off);
        out.setRange(got, got + take, c, _off);
        _off += take;
        got += take;
        continue;
      }
      if (_done) return null;
      await _more(timeout);
    }
    return out;
  }

  Future<void> cancel() => _sub.cancel();
}

/// Verbindet mit Zeitlimit; null bei Fehler.
Future<Socket?> connectTcp(String ip, int port, Duration timeout, {String? sourceIp}) async {
  try {
    final s = await Socket.connect(ip, port,
        timeout: timeout, sourceAddress: sourceIp == null ? null : InternetAddress(sourceIp));
    s.setOption(SocketOption.tcpNoDelay, true);
    return s;
  } catch (_) {
    if (sourceIp != null) {
      try {
        final s = await Socket.connect(ip, port, timeout: timeout);
        s.setOption(SocketOption.tcpNoDelay, true);
        return s;
      } catch (_) {}
    }
    return null;
  }
}

void writeLine(Socket s, String line) => s.add(utf8.encode('$line\n'));
