// Verschluesselung fuer das Postfach - identisch zu EarthMailCrypto (Windows):
//  * RSA-2048, Schluessel im .NET-XML-Format (ToXmlString)
//  * Versiegeln: 0x01 | Laenge(2, big endian) | RSA-OAEP-SHA1(aesKey32+macKey32)
//                | IV(16) | HMAC-SHA256(macKey, IV+Cipher) | AES-256-CBC-PKCS7
//  * Signatur: RSA PKCS#1 v1.5 mit SHA-256
import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' as c;
import 'package:pointycastle/export.dart';

import 'util.dart';

class RsaKeys {
  RsaKeys({required this.n, required this.e, this.d, this.p, this.q});
  final BigInt n;
  final BigInt e;
  final BigInt? d;
  final BigInt? p;
  final BigInt? q;

  bool get isPrivate => d != null && p != null && q != null;

  RSAPublicKey get publicKey => RSAPublicKey(n, e);
  RSAPrivateKey get privateKey => RSAPrivateKey(n, d!, p!, q!);

  String toPublicXml() =>
      '<RSAKeyValue><Modulus>${_b64(n, 256)}</Modulus><Exponent>${_b64(e, 3)}</Exponent></RSAKeyValue>';

  String toPrivateXml() {
    final dp = d! % (p! - BigInt.one);
    final dq = d! % (q! - BigInt.one);
    final iq = q!.modInverse(p!);
    return '<RSAKeyValue><Modulus>${_b64(n, 256)}</Modulus><Exponent>${_b64(e, 3)}</Exponent>'
        '<P>${_b64(p!, 128)}</P><Q>${_b64(q!, 128)}</Q><DP>${_b64(dp, 128)}</DP><DQ>${_b64(dq, 128)}</DQ>'
        '<InverseQ>${_b64(iq, 128)}</InverseQ><D>${_b64(d!, 256)}</D></RSAKeyValue>';
  }

  static RsaKeys? fromXml(String xml) {
    String? tag(String t) => RegExp('<$t>([^<]*)</$t>').firstMatch(xml)?.group(1)?.trim();
    try {
      final mod = tag('Modulus');
      final exp = tag('Exponent');
      if (mod == null || exp == null) return null;
      final d = tag('D');
      final p = tag('P');
      final q = tag('Q');
      return RsaKeys(
        n: bytesToBigInt(base64.decode(mod)),
        e: bytesToBigInt(base64.decode(exp)),
        d: d == null ? null : bytesToBigInt(base64.decode(d)),
        p: p == null ? null : bytesToBigInt(base64.decode(p)),
        q: q == null ? null : bytesToBigInt(base64.decode(q)),
      );
    } catch (_) {
      return null;
    }
  }

  static String _b64(BigInt v, int width) => base64.encode(bigIntToBytes(v, width));
}

BigInt bytesToBigInt(List<int> b) {
  var r = BigInt.zero;
  for (final x in b) {
    r = (r << 8) | BigInt.from(x);
  }
  return r;
}

/// Vorzeichenlos, big endian, mindestens [width] Bytes (vorne mit 0 aufgefuellt).
Uint8List bigIntToBytes(BigInt v, int width) {
  final bytes = <int>[];
  var x = v;
  final ff = BigInt.from(255);
  while (x > BigInt.zero) {
    bytes.insert(0, (x & ff).toInt());
    x = x >> 8;
  }
  while (bytes.length < width) {
    bytes.insert(0, 0);
  }
  return Uint8List.fromList(bytes);
}

Uint8List _leftPad(Uint8List b, int len) {
  if (b.length >= len) return b;
  final out = Uint8List(len);
  out.setRange(len - b.length, len, b);
  return out;
}

SecureRandom _secureRandom() {
  final r = FortunaRandom();
  r.seed(KeyParameter(randomBytes(32)));
  return r;
}

/// Neues Schluesselpaar als privates XML (fuer Isolate.run geeignet).
String generatePrivateKeyXml() {
  final gen = RSAKeyGenerator()
    ..init(ParametersWithRandom(RSAKeyGeneratorParameters(BigInt.from(65537), 2048, 64), _secureRandom()));
  final pair = gen.generateKeyPair();
  final pub = pair.publicKey as RSAPublicKey;
  final priv = pair.privateKey as RSAPrivateKey;
  return RsaKeys(n: pub.modulus!, e: pub.exponent!, d: priv.privateExponent!, p: priv.p!, q: priv.q!).toPrivateXml();
}

String signText(RsaKeys priv, String text) {
  final s = RSASigner(SHA256Digest(), '0609608648016503040201');
  s.init(true, PrivateKeyParameter<RSAPrivateKey>(priv.privateKey));
  final sig = s.generateSignature(Uint8List.fromList(utf8.encode(text)));
  return base64.encode(_leftPad(sig.bytes, 256));
}

bool verifyText(RsaKeys pub, String text, String sigB64) {
  try {
    final s = RSASigner(SHA256Digest(), '0609608648016503040201');
    s.init(false, PublicKeyParameter<RSAPublicKey>(pub.publicKey));
    return s.verifySignature(Uint8List.fromList(utf8.encode(text)), RSASignature(base64.decode(sigB64)));
  } catch (_) {
    return false;
  }
}

Uint8List _aes(bool enc, Uint8List key, Uint8List iv, Uint8List data) {
  final cipher = PaddedBlockCipherImpl(PKCS7Padding(), CBCBlockCipher(AESEngine()));
  cipher.init(enc, PaddedBlockCipherParameters<ParametersWithIV<KeyParameter>, Null>(ParametersWithIV<KeyParameter>(KeyParameter(key), iv), null));
  return cipher.process(data);
}

Uint8List _hmac(Uint8List key, Uint8List data) => Uint8List.fromList(c.Hmac(c.sha256, key).convert(data).bytes);

/// Versiegelt [plain] fuer den Empfaenger; Ergebnis Base64.
String seal(RsaKeys recipientPub, String plain) {
  final aesKey = randomBytes(32);
  final macKey = randomBytes(32);
  final iv = randomBytes(16);
  final keys = Uint8List(64)
    ..setRange(0, 32, aesKey)
    ..setRange(32, 64, macKey);
  final oaep = OAEPEncoding(RSAEngine())..init(true, PublicKeyParameter<RSAPublicKey>(recipientPub.publicKey));
  final wrapped = _leftPad(oaep.process(keys), 256);
  final cipher = _aes(true, aesKey, iv, Uint8List.fromList(utf8.encode(plain)));
  final macIn = Uint8List(iv.length + cipher.length)
    ..setRange(0, 16, iv)
    ..setRange(16, 16 + cipher.length, cipher);
  final mac = _hmac(macKey, macIn);
  final out = <int>[1, (wrapped.length >> 8) & 255, wrapped.length & 255, ...wrapped, ...iv, ...mac, ...cipher];
  return base64.encode(out);
}

/// Oeffnet einen versiegelten Block; null bei Fehler.
String? openSealed(RsaKeys priv, String blobB64) {
  try {
    final b = base64.decode(blobB64);
    if (b.length < 3 || b[0] != 1) return null;
    final wl = (b[1] << 8) | b[2];
    if (b.length < 3 + wl + 16 + 32 + 16) return null;
    final wrapped = Uint8List.fromList(b.sublist(3, 3 + wl));
    final iv = Uint8List.fromList(b.sublist(3 + wl, 19 + wl));
    final mac = Uint8List.fromList(b.sublist(19 + wl, 51 + wl));
    final cipher = Uint8List.fromList(b.sublist(51 + wl));
    final oaep = OAEPEncoding(RSAEngine())..init(false, PrivateKeyParameter<RSAPrivateKey>(priv.privateKey));
    final keys = oaep.process(wrapped);
    if (keys.length != 64) return null;
    final aesKey = Uint8List.fromList(keys.sublist(0, 32));
    final macKey = Uint8List.fromList(keys.sublist(32, 64));
    final macIn = Uint8List(16 + cipher.length)
      ..setRange(0, 16, iv)
      ..setRange(16, 16 + cipher.length, cipher);
    final expect = _hmac(macKey, macIn);
    var diff = 0;
    for (var i = 0; i < 32; i++) {
      diff |= expect[i] ^ mac[i];
    }
    if (diff != 0) return null;
    return utf8.decode(_aes(false, aesKey, iv, cipher), allowMalformed: true);
  } catch (_) {
    return null;
  }
}
