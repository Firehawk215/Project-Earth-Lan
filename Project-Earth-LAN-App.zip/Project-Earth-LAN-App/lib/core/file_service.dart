// Dateiuebertragung (TCP/UDP 9876) - kompatibel zu EarthFileNode im Windows-Manager.
// OFFER/ACCEPT ueber eine Steuerverbindung, Daten in 2-MiB-Stuecken mit SHA-256
// ueber 1-8 parallele Verbindungen, Fortsetzen ueber .part/.part.map.
import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';

import 'util.dart';

const int kFilePort = 9876;
const int kChunkSize = 2097152;

class FilePeer {
  FilePeer(this.id, this.name, this.ip, this.seen, {this.manual = false});
  final String id;
  String name;
  final String ip;
  int seen;
  final bool manual;
}

class XferFile {
  XferFile(this.rel, this.size, this.mtimeTicks, {this.localPath = ''});
  final String rel;
  final int size;
  final int mtimeTicks;
  final String localPath; // Quelle (Senden)
  int chunkSize = kChunkSize;
  List<bool> have = <bool>[];
  // Empfang
  String finalPath = '';
  RandomAccessFile? raf;
  final Mutex lock = Mutex();
  bool dirty = false;
  bool finished = false;
  int remaining = 0;

  int get chunks => size == 0 ? 0 : (size + chunkSize - 1) ~/ chunkSize;
  int chunkLen(int ci) => min(chunkSize, size - ci * chunkSize);
}

class Transfer {
  Transfer({required this.id, required this.incoming, required this.peerName, required this.peerIp, required this.files, required this.chunkSize}) {
    for (final f in files) {
      f.chunkSize = chunkSize;
    }
  }
  final String id;
  final bool incoming;
  final String peerName;
  final String peerIp;
  final List<XferFile> files;
  final int chunkSize;
  String token = '';
  bool accepted = false;
  bool cancel = false;
  bool finished = false;
  bool failed = false;
  String status = '';
  int doneBytes = 0;
  int lastProgress = nowMs();

  int get total => files.fold(0, (a, f) => a + f.size);
  String get title => files.length == 1 ? files.first.rel : '${files.length} Dateien';
  double get progress {
    final tot = total;
    if (tot == 0) return finished ? 1.0 : 0.0;
    final p = doneBytes / tot;
    return p < 0 ? 0.0 : (p > 1 ? 1.0 : p);
  }
}

class IncomingOffer {
  IncomingOffer(this.peerName, this.peerIp, this.fileCount, this.total, this.targetDir);
  final String peerName;
  final String peerIp;
  final int fileCount;
  final int total;
  final String targetDir;
}

class FileService extends ChangeNotifier {
  FileService({required this.myName, required this.myIp, required this.broadcast, required this.downloadDir, required this.streams, required this.limitMb});

  final String Function() myName;
  final String Function() myIp;
  final String Function() broadcast;
  final String Function() downloadDir;
  final int Function() streams;
  final int Function() limitMb;

  /// Wird von der Oberflaeche gesetzt: fragt "Annehmen?" (true = ja).
  Future<bool> Function(IncomingOffer offer)? askAccept;

  final String nodeId = randomHex(12);
  final Map<String, FilePeer> peers = <String, FilePeer>{};
  final List<Transfer> transfers = <Transfer>[];
  final List<String> log = <String>[];

  ServerSocket? _server;
  RawDatagramSocket? _rx;
  RawDatagramSocket? _tx;
  Timer? _timer;
  int _tick = 0;

  String get _name => cleanName(myName(), 60);

  Future<void> start() async {
    final ip = myIp();
    try {
      _server = await ServerSocket.bind(ip.isEmpty ? InternetAddress.anyIPv4 : InternetAddress(ip), kFilePort);
    } catch (_) {
      try {
        _server = await ServerSocket.bind(InternetAddress.anyIPv4, kFilePort);
      } catch (e) {
        _log('Datei-Port $kFilePort belegt: $e');
      }
    }
    _server?.listen(_handleConn);
    try {
      _rx = await RawDatagramSocket.bind(InternetAddress.anyIPv4, kFilePort, reuseAddress: true);
      _rx!.broadcastEnabled = true;
      _rx!.listen((ev) {
        if (ev != RawSocketEvent.read) return;
        Datagram? d;
        while ((d = _rx!.receive()) != null) {
          _onBeacon(d!);
        }
      });
    } catch (_) {}
    try {
      _tx = await RawDatagramSocket.bind(ip.isEmpty ? InternetAddress.anyIPv4 : InternetAddress(ip), 0);
    } catch (_) {
      _tx = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    }
    _tx!.broadcastEnabled = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _onTimer());
  }

  Future<void> stop() async {
    _timer?.cancel();
    await _server?.close();
    _rx?.close();
    _tx?.close();
    for (final t in transfers) {
      if (t.incoming) await _saveMaps(t, close: true);
      t.cancel = true;
    }
  }

  void _onTimer() {
    _tick++;
    if (_tick % 3 == 0) {
      final bytes = utf8.encode('PEFS1|$nodeId|$_name');
      for (final t in <String>{'255.255.255.255', broadcast()}) {
        try {
          _tx?.send(bytes, InternetAddress(t), kFilePort);
        } catch (_) {}
      }
      final now = nowMs();
      final n = peers.length;
      peers.removeWhere((k, p) => !p.manual && now - p.seen > 12000);
      if (peers.length != n) notifyListeners();
    }
    if (_tick % 3 == 1) {
      for (final t in transfers) {
        if (t.incoming && !t.finished) unawaited(_saveMaps(t));
        if (t.incoming && !t.finished && !t.failed && nowMs() - t.lastProgress > 10000 && t.accepted) {
          t.status = 'Wartet auf Sender (Fortsetzen möglich)';
        }
      }
      notifyListeners();
    }
  }

  void _onBeacon(Datagram d) {
    final f = utf8.decode(d.data, allowMalformed: true).split('|');
    if (f.length < 3 || f[0] != 'PEFS1' || f[1] == nodeId) return;
    final ip = d.address.address;
    if (ip == myIp()) return;
    final isNew = !peers.containsKey(f[1]);
    peers[f[1]] = FilePeer(f[1], cleanName(f[2], 60), ip, nowMs());
    if (isNew) {
      _log('Manager gefunden: ${cleanName(f[2], 60)} ($ip)');
      notifyListeners();
    }
  }

  void _log(String t) {
    log.add('[${formatTime(DateTime.now())}] $t');
    if (log.length > 300) log.removeAt(0);
    notifyListeners();
  }

  /// Manuell per PING pruefen, ob unter [ip] ein Datei-Manager laeuft.
  Future<bool> probe(String ip) async {
    final s = await connectTcp(ip, kFilePort, const Duration(milliseconds: 2500), sourceIp: _src);
    if (s == null) return false;
    final r = SocketReader(s);
    try {
      writeLine(s, 'PING|$nodeId|$_name');
      final line = await r.readLine(timeout: const Duration(seconds: 3));
      final f = (line ?? '').split('|');
      if (f.length >= 3 && f[0] == 'PONG') {
        peers[f[1]] = FilePeer(f[1], cleanName(f[2], 60), ip, nowMs(), manual: true);
        notifyListeners();
        return true;
      }
    } catch (_) {
    } finally {
      s.destroy();
    }
    return false;
  }

  String? get _src => myIp().isEmpty ? null : myIp();

  // ============================================================ Server
  Future<void> _handleConn(Socket s) async {
    try {
      s.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    final r = SocketReader(s);
    try {
      final first = await r.readLine(maxBytes: 8000000, timeout: const Duration(seconds: 30));
      if (first == null) return;
      final f = first.split('|');
      switch (f[0]) {
        case 'PING':
          writeLine(s, 'PONG|$nodeId|$_name');
          await s.flush();
          break;
        case 'OFFER':
          await _handleOffer(s, r, f);
          break;
        case 'DATA':
          await _handleData(s, r, f);
          break;
      }
    } catch (_) {
    } finally {
      try {
        await s.close();
      } catch (_) {}
      s.destroy();
    }
  }

  static const _reserved = <String>{'CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9', 'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'};

  /// SafeRel des Windows-Managers (gleiche Regeln, damit beide Seiten gleich entscheiden).
  static String? safeRel(String rel) {
    final parts = rel.replaceAll('\\', '/').split('/');
    for (final p in parts) {
      if (p.isEmpty || p == '.' || p == '..') return null;
      if (RegExp(r'[<>:"/\\|?*\x00-\x1F]').hasMatch(p)) return null;
      if (p.endsWith('.') || p.endsWith(' ')) return null;
      final stem = (p.contains('.') ? p.substring(0, p.indexOf('.')) : p).toUpperCase();
      if (_reserved.contains(stem)) return null;
    }
    return parts.join('/');
  }

  /// Macht einen Namensteil Windows-tauglich (fuer eigene Angebote).
  static String sanitizePart(String p) {
    var t = p.replaceAll(RegExp(r'[<>:"/\\|?*\x00-\x1F]'), '_');
    while (t.endsWith('.') || t.endsWith(' ')) {
      t = t.substring(0, t.length - 1);
    }
    if (t.isEmpty) t = '_';
    final stem = (t.contains('.') ? t.substring(0, t.indexOf('.')) : t).toUpperCase();
    if (_reserved.contains(stem)) t = '_$t';
    return t;
  }

  Future<void> _handleOffer(Socket s, SocketReader r, List<String> f) async {
    if (f.length < 7) return;
    final id = f[1];
    final senderName = cleanName(f[3], 60);
    final fc = int.tryParse(f[4]);
    final total = int.tryParse(f[5]);
    final cs = int.tryParse(f[6]);
    if (fc == null || total == null || cs == null) return;
    if (fc < 1 || fc > 200000 || total < 0 || cs < 65536 || cs > 16777216 || id.isEmpty || id.length > 64) return;
    final files = <XferFile>[];
    final seen = <String>{};
    var bad = false;
    for (var i = 0; i < fc; i++) {
      final line = await r.readLine(maxBytes: 8000000, timeout: const Duration(seconds: 30));
      if (line == null) return;
      final p = line.split('|');
      if (p.length < 4 || p[0] != 'F') return;
      final size = int.tryParse(p[2]);
      final mt = int.tryParse(p[3]);
      if (size == null || mt == null || size < 0) return;
      final rel = safeRel(p[1]);
      if (rel == null || !seen.add(rel.toLowerCase())) bad = true;
      files.add(XferFile(rel ?? '', size, mt));
    }
    final end = await r.readLine(timeout: const Duration(seconds: 30));
    if (bad) {
      writeLine(s, 'DENY|Ungueltiger oder doppelter Dateipfad im Angebot');
      await s.flush();
      return;
    }
    if (end != 'END') return;
    for (final x in files) {
      x.chunkSize = cs;
      if (x.chunks > 10000000) {
        writeLine(s, 'DENY|Datei zu gross');
        await s.flush();
        return;
      }
    }

    // Fortsetzen ohne Rueckfrage
    Transfer? t;
    for (final x in transfers) {
      if (x.id == id && x.incoming && !x.finished && x.accepted && !x.failed) t = x;
    }
    if (t != null) {
      s.add(utf8.encode(_acceptText(t)));
      await s.flush();
      return;
    }

    final ip = s.remoteAddress.address;
    final dir = downloadDir();
    t = Transfer(id: id, incoming: true, peerName: senderName, peerIp: ip, files: files, chunkSize: cs);
    t.status = 'Wartet auf deine Zustimmung ...';
    transfers.insert(0, t);
    notifyListeners();
    var ok = false;
    try {
      final ask = askAccept;
      if (ask != null) {
        ok = await ask(IncomingOffer(senderName, ip, fc, total, dir)).timeout(const Duration(seconds: 60), onTimeout: () => false);
      }
    } catch (_) {
      ok = false;
    }
    if (!ok) {
      t.failed = true;
      t.status = 'Abgelehnt';
      notifyListeners();
      writeLine(s, 'DENY|Nicht angenommen');
      await s.flush();
      return;
    }
    try {
      for (final x in files) {
        await _prepareRecv(t, x, dir);
      }
    } catch (e) {
      t.failed = true;
      t.status = 'Zielordner nicht beschreibbar';
      notifyListeners();
      writeLine(s, 'DENY|Zielordner nicht beschreibbar: ${e.toString().replaceAll('|', '/').replaceAll('\n', ' ')}');
      await s.flush();
      return;
    }
    t.token = randomHex(32);
    t.accepted = true;
    t.status = 'Empfange ...';
    t.doneBytes = _haveBytes(t);
    _log('Empfange von $senderName ($ip): ${t.title}');
    s.add(utf8.encode(_acceptText(t)));
    await s.flush();
    await _checkAllDone(t);
    notifyListeners();
  }

  String _acceptText(Transfer t) {
    final sb = StringBuffer('ACCEPT|${t.token}\n');
    for (var i = 0; i < t.files.length; i++) {
      sb.write('H|$i|${t.files[i].have.map((b) => b ? '1' : '0').join()}\n');
    }
    sb.write('GO\n');
    return sb.toString();
  }

  int _haveBytes(Transfer t) {
    var n = 0;
    for (final f in t.files) {
      for (var ci = 0; ci < f.chunks; ci++) {
        if (f.have[ci]) n += f.chunkLen(ci);
      }
    }
    return n;
  }

  String _join(String dir, String rel) => [dir, ...rel.split('/')].join(Platform.pathSeparator);

  Future<void> _prepareRecv(Transfer t, XferFile x, String dir) async {
    x.finalPath = _join(dir, x.rel);
    final parent = File(x.finalPath).parent;
    if (!parent.existsSync()) parent.createSync(recursive: true);
    final fin = File(x.finalPath);
    if (fin.existsSync() && fin.lengthSync() == x.size && (dateToTicks(fin.lastModifiedSync()) - x.mtimeTicks).abs() < 20000000) {
      x.have = List<bool>.filled(x.chunks, true);
      x.remaining = 0;
      x.finished = true;
      return;
    }
    final part = File('${x.finalPath}.part');
    final map = File('${x.finalPath}.part.map');
    List<bool>? bits;
    if (part.existsSync() && map.existsSync()) {
      try {
        final txt = map.readAsStringSync();
        final nl = txt.indexOf('\n');
        if (nl > 0 && txt.substring(0, nl) == '${x.size}|${x.mtimeTicks}|${x.chunkSize}') {
          final b = txt.substring(nl + 1).trim();
          if (b.length == x.chunks) bits = b.split('').map((c) => c == '1').toList();
        }
      } catch (_) {}
    }
    if (bits == null) {
      if (part.existsSync()) part.deleteSync();
      bits = List<bool>.filled(x.chunks, false);
    }
    x.have = bits;
    x.remaining = bits.where((b) => !b).length;
    if (!part.existsSync()) part.createSync(recursive: true);
    x.raf = await part.open(mode: FileMode.append);
    if (x.chunks == 0) await _finalize(t, x);
  }

  Future<void> _saveMaps(Transfer t, {bool close = false}) async {
    for (final x in t.files) {
      if (x.finished || x.finalPath.isEmpty) continue;
      if (x.dirty || close) {
        x.dirty = false;
        try {
          await File('${x.finalPath}.part.map').writeAsString('${x.size}|${x.mtimeTicks}|${x.chunkSize}\n${x.have.map((b) => b ? '1' : '0').join()}');
        } catch (_) {}
      }
      if (close) {
        await x.lock.run(() async {
          try {
            await x.raf?.close();
          } catch (_) {}
          x.raf = null;
        });
      }
    }
  }

  String _uniqueName(String path) {
    final f = File(path);
    final dir = f.parent.path;
    final name = f.uri.pathSegments.isNotEmpty ? f.uri.pathSegments.last : path;
    final dot = name.lastIndexOf('.');
    final stem = dot > 0 ? name.substring(0, dot) : name;
    final ext = dot > 0 ? name.substring(dot) : '';
    for (var i = 1; i < 10000; i++) {
      final cand = '$dir${Platform.pathSeparator}$stem ($i)$ext';
      if (!File(cand).existsSync()) return cand;
    }
    return '$dir${Platform.pathSeparator}$stem (${randomHex(6)})$ext';
  }

  Future<void> _finalize(Transfer t, XferFile x) async {
    if (x.finished) return;
    x.finished = true;
    await x.lock.run(() async {
      final raf = x.raf;
      x.raf = null;
      if (raf != null) {
        await raf.truncate(x.size);
        await raf.flush();
        await raf.close();
      }
    });
    final part = File('${x.finalPath}.part');
    var target = x.finalPath;
    final fin = File(target);
    if (fin.existsSync()) {
      if (fin.lengthSync() == x.size && (dateToTicks(fin.lastModifiedSync()) - x.mtimeTicks).abs() < 20000000) {
        try {
          part.deleteSync();
        } catch (_) {}
        _deleteMap(x);
        return;
      }
      target = _uniqueName(target);
    }
    final moved = await part.rename(target);
    try {
      await moved.setLastModified(ticksToDate(x.mtimeTicks).toLocal());
    } catch (_) {}
    _deleteMap(x);
  }

  void _deleteMap(XferFile x) {
    try {
      final m = File('${x.finalPath}.part.map');
      if (m.existsSync()) m.deleteSync();
    } catch (_) {}
  }

  Future<void> _checkAllDone(Transfer t) async {
    if (t.finished) return;
    if (t.files.every((f) => f.finished)) {
      t.finished = true;
      t.doneBytes = t.total;
      t.status = 'Fertig';
      _log('Fertig: ${t.title}');
      notifyListeners();
    }
  }

  Future<void> _handleData(Socket s, SocketReader r, List<String> f) async {
    Transfer? t;
    if (f.length >= 3) {
      for (final x in transfers) {
        if (x.id == f[1] && x.incoming) t = x;
      }
    }
    if (t == null || t.token != f[2] || t.cancel || !t.accepted || t.failed) {
      writeLine(s, 'NO');
      await s.flush();
      return;
    }
    writeLine(s, 'READY');
    await s.flush();
    while (true) {
      final line = await r.readLine(timeout: const Duration(seconds: 30));
      if (line == null || line == 'BYE' || t.cancel) break;
      final p = line.split('|');
      if (p.length < 5 || p[0] != 'C') break;
      final fi = int.tryParse(p[1]);
      final ci = int.tryParse(p[2]);
      final len = int.tryParse(p[3]);
      if (fi == null || ci == null || len == null) break;
      if (fi < 0 || fi >= t.files.length) break;
      final x = t.files[fi];
      if (ci < 0 || ci >= x.chunks || len != x.chunkLen(ci)) break;
      final data = await r.readBytes(len, timeout: const Duration(seconds: 30));
      if (data == null) break;
      final hash = sha256.convert(data).toString();
      if (hash.toLowerCase() != p[4].toLowerCase()) {
        writeLine(s, 'BAD|$fi|$ci');
        continue;
      }
      if (!x.have[ci] && !x.finished) {
        await x.lock.run(() async {
          final raf = x.raf;
          if (raf == null) return;
          await raf.setPosition(ci * x.chunkSize);
          await raf.writeFrom(data);
        });
        if (!x.have[ci]) {
          x.have[ci] = true;
          x.dirty = true;
          x.remaining--;
          t.doneBytes += len;
          t.lastProgress = nowMs();
          t.status = 'Empfange ...';
          if (x.remaining <= 0) {
            await _finalize(t, x);
            await _checkAllDone(t);
          }
        }
      }
      writeLine(s, 'OK|$fi|$ci');
    }
    await s.flush();
  }

  void cancelTransfer(Transfer t) {
    t.cancel = true;
    if (!t.finished) {
      t.failed = true;
      t.status = 'Abgebrochen';
    }
    if (t.incoming) unawaited(_saveMaps(t, close: true));
    notifyListeners();
  }

  void clearFinished() {
    transfers.removeWhere((t) => t.finished || t.failed);
    notifyListeners();
  }

  // ============================================================ Senden
  /// Dateien und/oder Ordner an [ip] senden.
  Future<void> sendPaths(String ip, List<String> paths, {String peerName = ''}) async {
    final files = <XferFile>[];
    for (final p in paths) {
      final type = FileSystemEntity.typeSync(p, followLinks: false);
      if (type == FileSystemEntityType.directory) {
        final root = Directory(p);
        final base = sanitizePart(root.uri.pathSegments.where((x) => x.isNotEmpty).last);
        try {
          await for (final e in root.list(recursive: true, followLinks: false)) {
            if (e is! File) continue;
            final relLocal = e.path.substring(root.path.length).replaceAll('\\', '/');
            final comps = relLocal.split('/').where((c) => c.isNotEmpty).map(sanitizePart).toList();
            files.add(_entry(e, '$base/${comps.join('/')}'));
          }
        } catch (_) {}
      } else if (type == FileSystemEntityType.file) {
        final fl = File(p);
        files.add(_entry(fl, sanitizePart(fl.uri.pathSegments.last)));
      }
    }
    // doppelte Pfade vermeiden (Windows prueft ohne Gross/Klein)
    final seen = <String>{};
    final unique = <XferFile>[];
    for (final f in files) {
      var rel = f.rel;
      var n = 1;
      while (!seen.add(rel.toLowerCase())) {
        final dot = f.rel.lastIndexOf('.');
        rel = dot > 0 ? '${f.rel.substring(0, dot)} ($n)${f.rel.substring(dot)}' : '${f.rel} ($n)';
        n++;
      }
      unique.add(XferFile(rel, f.size, f.mtimeTicks, localPath: f.localPath));
    }
    if (unique.isEmpty) {
      _log('Nichts zu senden (leere Auswahl).');
      return;
    }
    final t = Transfer(id: randomHex(16), incoming: false, peerName: peerName, peerIp: ip, files: unique, chunkSize: kChunkSize);
    t.status = 'Warte auf Zustimmung ...';
    transfers.insert(0, t);
    notifyListeners();
    unawaited(_sendWorker(t));
  }

  XferFile _entry(File f, String rel) {
    final st = f.statSync();
    return XferFile(rel, st.size, dateToTicks(st.modified), localPath: f.path);
  }

  Future<void> _sendWorker(Transfer t) async {
    for (var attempt = 1; attempt <= 6 && !t.cancel; attempt++) {
      if (attempt > 1) {
        t.status = 'Verbindung wird wiederhergestellt ($attempt) ...';
        notifyListeners();
        await Future<void>.delayed(const Duration(seconds: 4));
        if (t.cancel) break;
      }
      final hs = await _handshake(t);
      if (hs == 'deny') {
        t.failed = true;
        t.status = 'Abgelehnt';
        _log('Abgelehnt: ${t.title}');
        notifyListeners();
        return;
      }
      if (hs != 'ok') continue;
      final result = await _transferData(t);
      if (result == 'done') {
        t.finished = true;
        t.doneBytes = t.total;
        t.status = 'Fertig';
        _log('Gesendet: ${t.title}');
        notifyListeners();
        return;
      }
      if (result == 'aborted') {
        t.failed = true;
        t.status = 'Vom Empfänger abgebrochen';
        notifyListeners();
        return;
      }
      t.status = 'Unterbrochen - versuche Fortsetzen ...';
      notifyListeners();
    }
    if (!t.finished) {
      t.failed = true;
      if (!t.cancel) t.status = 'Unterbrochen - erneut senden setzt fort';
      notifyListeners();
    }
  }

  /// 'ok', 'deny' oder 'fail'
  Future<String> _handshake(Transfer t) async {
    final s = await connectTcp(t.peerIp, kFilePort, const Duration(seconds: 3), sourceIp: _src);
    if (s == null) return 'fail';
    final r = SocketReader(s);
    try {
      final sb = StringBuffer('OFFER|${t.id}|$nodeId|$_name|${t.files.length}|${t.total}|${t.chunkSize}\n');
      for (final f in t.files) {
        sb.write('F|${f.rel}|${f.size}|${f.mtimeTicks}\n');
      }
      sb.write('END\n');
      s.add(utf8.encode(sb.toString()));
      await s.flush();
      final first = await r.readLine(timeout: const Duration(seconds: 90));
      if (first == null) return 'fail';
      if (first.startsWith('DENY')) return 'deny';
      final a = first.split('|');
      if (a.length < 2 || a[0] != 'ACCEPT') return 'fail';
      t.token = a[1];
      for (final f in t.files) {
        f.have = List<bool>.filled(f.chunks, false);
      }
      while (true) {
        final line = await r.readLine(timeout: const Duration(seconds: 30));
        if (line == null || line == 'GO') break;
        final h = line.split('|');
        if (h.length >= 3 && h[0] == 'H') {
          final idx = int.tryParse(h[1]);
          if (idx == null || idx < 0 || idx >= t.files.length) continue;
          final f = t.files[idx];
          for (var ci = 0; ci < f.chunks && ci < h[2].length; ci++) {
            f.have[ci] = h[2][ci] == '1';
          }
        }
      }
      t.accepted = true;
      t.status = 'Sende ...';
      notifyListeners();
      return 'ok';
    } catch (_) {
      return 'fail';
    } finally {
      s.destroy();
    }
  }

  // Tempolimit (gemeinsam fuer alle Sendungen)
  double _bucket = 0;
  int _bucketAt = 0;
  Future<void> _throttle(int bytes) async {
    final lim = limitMb();
    if (lim <= 0) return;
    final rate = lim * 1048576.0;
    final now = nowMs();
    if (_bucketAt == 0) _bucketAt = now;
    _bucket = min(rate, _bucket + (now - _bucketAt) * rate / 1000);
    _bucketAt = now;
    _bucket -= bytes;
    if (_bucket < 0) {
      final wait = min(2000, (-_bucket / rate * 1000).ceil());
      await Future<void>.delayed(Duration(milliseconds: wait));
    }
  }

  /// 'done', 'aborted' oder 'incomplete'
  Future<String> _transferData(Transfer t) async {
    final jobs = Queue<List<int>>(); // [fi, ci, retry]
    var need = 0;
    for (var fi = 0; fi < t.files.length; fi++) {
      final f = t.files[fi];
      for (var ci = 0; ci < f.chunks; ci++) {
        if (!f.have[ci]) {
          jobs.add(<int>[fi, ci, 0]);
          need += f.chunkLen(ci);
        }
      }
    }
    t.doneBytes = t.total - need;
    notifyListeners();
    if (jobs.isEmpty) return 'done';
    var aborted = false;
    var outstanding = jobs.length;

    Future<void> worker() async {
      Socket? s;
      SocketReader? r;
      final files = <int, RandomAccessFile>{};
      var failures = 0;
      try {
        while (!t.cancel && !aborted && jobs.isNotEmpty) {
          final job = jobs.removeFirst();
          final f = t.files[job[0]];
          final ci = job[1];
          try {
            if (s == null) {
              s = await connectTcp(t.peerIp, kFilePort, const Duration(seconds: 3), sourceIp: _src);
              if (s == null) throw Exception('keine Verbindung');
              r = SocketReader(s);
              writeLine(s, 'DATA|${t.id}|${t.token}');
              await s.flush();
              final rep = await r.readLine(timeout: const Duration(seconds: 30));
              if (rep == 'NO') {
                aborted = true;
                jobs.addFirst(job);
                break;
              }
              if (rep != 'READY') throw Exception('kein READY');
            }
            final len = f.chunkLen(ci);
            final raf = files[job[0]] ??= await File(f.localPath).open();
            await raf.setPosition(ci * t.chunkSize);
            final data = await raf.read(len);
            if (data.length != len) throw Exception('Datei hat sich geaendert');
            await _throttle(len);
            final hash = sha256.convert(data).toString();
            s.add(utf8.encode('C|${job[0]}|$ci|$len|$hash\n'));
            s.add(data);
            await s.flush();
            final ack = await r!.readLine(timeout: const Duration(seconds: 30));
            if (ack != null && ack.startsWith('OK|')) {
              outstanding--;
              t.doneBytes += len;
              t.lastProgress = nowMs();
              notifyListeners();
            } else if (ack == null) {
              throw Exception('Verbindung weg');
            } else {
              job[2]++;
              if (job[2] > 8) break;
              jobs.addLast(job);
              await Future<void>.delayed(const Duration(milliseconds: 300));
            }
          } catch (_) {
            failures++;
            try {
              s?.destroy();
            } catch (_) {}
            s = null;
            r = null;
            job[2]++;
            if (job[2] <= 8) jobs.addLast(job);
            if (failures > 30) break;
            await Future<void>.delayed(Duration(milliseconds: min(8000, 300 * (1 << min(failures, 5)))));
          }
        }
      } finally {
        if (s != null) {
          try {
            writeLine(s, 'BYE');
            await s.flush();
          } catch (_) {}
          s.destroy();
        }
        for (final raf in files.values) {
          try {
            await raf.close();
          } catch (_) {}
        }
      }
    }

    final n = max(1, min(streams().clamp(1, 8), jobs.length));
    await Future.wait(List<Future<void>>.generate(n, (_) => worker()));
    if (aborted) return 'aborted';
    return outstanding <= 0 ? 'done' : 'incomplete';
  }
}
