// Einstellungen der App (JSON-Datei im App-Datenordner).
import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Netzwerk-Code, der beim Bauen eingesetzt wird:
///   flutter build apk --dart-define=PEL_NETWORK_CODE=DeinCode
/// Leer = die App fragt beim ersten Start danach.
const String kBuildNetworkCode = String.fromEnvironment('PEL_NETWORK_CODE');

const String kPelVersion = '2026.09.23';
const String kPelNetworkId = '091f0945fc5012f1';
const String kZtnetDefaultUrl = 'http://10.147.0.34:3000';

class Settings {
  String name = '';
  String networkCode = '';
  String adapterIp = ''; // leer = automatisch
  int prefix = 0; // 0 = automatisch
  String downloadDir = '';
  int streams = 4;
  int limitMb = 0;
  String ztnetUrl = kZtnetDefaultUrl;
  String ztnetToken = '';
  List<String> manualPeers = <String>[];

  late Directory dataDir;

  String get effectiveCode => networkCode.isNotEmpty ? networkCode : kBuildNetworkCode;
  bool get hasCode => effectiveCode.isNotEmpty;

  File get _file => File('${dataDir.path}${Platform.pathSeparator}einstellungen.json');

  Future<void> load() async {
    dataDir = await getApplicationSupportDirectory();
    if (!dataDir.existsSync()) dataDir.createSync(recursive: true);
    try {
      if (_file.existsSync()) {
        final j = jsonDecode(await _file.readAsString()) as Map<String, dynamic>;
        name = (j['name'] ?? '') as String;
        networkCode = (j['networkCode'] ?? '') as String;
        adapterIp = (j['adapterIp'] ?? '') as String;
        prefix = (j['prefix'] ?? 0) as int;
        downloadDir = (j['downloadDir'] ?? '') as String;
        streams = (j['streams'] ?? 4) as int;
        limitMb = (j['limitMb'] ?? 0) as int;
        ztnetUrl = (j['ztnetUrl'] ?? kZtnetDefaultUrl) as String;
        ztnetToken = (j['ztnetToken'] ?? '') as String;
        manualPeers = ((j['manualPeers'] ?? <dynamic>[]) as List<dynamic>).map((e) => e.toString()).toList();
      }
    } catch (_) {
      // defekte Datei -> Standardwerte
    }
    if (name.isEmpty) {
      name = Platform.localHostname;
      if (name.isEmpty || name == 'localhost') name = 'Mitspieler';
    }
    if (streams < 1 || streams > 8) streams = 4;
    if (downloadDir.isEmpty) {
      Directory? d;
      try {
        d = await getDownloadsDirectory();
      } catch (_) {}
      d ??= await getApplicationDocumentsDirectory();
      downloadDir = '${d.path}${Platform.pathSeparator}ProjectEarthLAN';
    }
  }

  Future<void> save() async {
    final j = <String, dynamic>{
      'name': name,
      'networkCode': networkCode,
      'adapterIp': adapterIp,
      'prefix': prefix,
      'downloadDir': downloadDir,
      'streams': streams,
      'limitMb': limitMb,
      'ztnetUrl': ztnetUrl,
      'ztnetToken': ztnetToken,
      'manualPeers': manualPeers,
    };
    final tmp = File('${_file.path}.tmp');
    await tmp.writeAsString(const JsonEncoder.withIndent('  ').convert(j), flush: true);
    await tmp.rename(_file.path);
  }
}
