// Netzwerkadapter, eigene IP (bevorzugt ZeroTier), Subnetz-Praefix und
// ZeroTier-Befehle (Linux/macOS).
import 'dart:io';

import 'settings.dart';
import 'util.dart';

class NetIf {
  NetIf(this.name, this.ip);
  final String name;
  final String ip;
  bool get looksZeroTier =>
      name.startsWith('zt') || name.startsWith('feth') || name.toLowerCase().contains('zerotier');
  @override
  String toString() => '$name ($ip)';
}

class NetInfo {
  List<NetIf> interfaces = <NetIf>[];
  Set<String> localIps = <String>{'127.0.0.1'};
  String ip = '';
  int prefix = 24;

  Future<void> refresh(Settings s) async {
    final list = <NetIf>[];
    try {
      final ifs = await NetworkInterface.list(type: InternetAddressType.IPv4, includeLoopback: false);
      for (final i in ifs) {
        for (final a in i.addresses) {
          if (a.address.startsWith('169.254.')) continue;
          list.add(NetIf(i.name, a.address));
        }
      }
    } catch (_) {}
    interfaces = list;
    localIps = <String>{'127.0.0.1', ...list.map((e) => e.ip)};

    // Adapter: gewaehlt > ZeroTier-Adapter > 10.147.x > erster
    var chosen = '';
    if (s.adapterIp.isNotEmpty && list.any((e) => e.ip == s.adapterIp)) chosen = s.adapterIp;
    if (chosen.isEmpty) {
      for (final i in list) {
        if (i.looksZeroTier) {
          chosen = i.ip;
          break;
        }
      }
    }
    if (chosen.isEmpty) {
      for (final i in list) {
        if (i.ip.startsWith('10.147.')) {
          chosen = i.ip;
          break;
        }
      }
    }
    if (chosen.isEmpty) {
      // Android: ZeroTier laeuft als VPN ("tun0")
      for (final i in list) {
        if (i.name.startsWith('tun')) {
          chosen = i.ip;
          break;
        }
      }
    }
    if (chosen.isEmpty && list.isNotEmpty) chosen = list.first.ip;
    ip = chosen;

    if (s.prefix > 0) {
      prefix = s.prefix;
    } else {
      prefix = (ip.isEmpty ? null : await detectPrefix(ip)) ?? 24;
    }
  }

  bool get zeroTierLikely {
    for (final i in interfaces) {
      if (i.ip == ip && (i.looksZeroTier || i.name.startsWith('tun'))) return true;
    }
    return ip.startsWith('10.147.');
  }

  String get broadcast => ip.isEmpty ? '255.255.255.255' : broadcastFor(ip, prefix);

  /// Praefixlaenge per "ip" (Linux) bzw. "ifconfig" (macOS); null wenn unbekannt.
  static Future<int?> detectPrefix(String ip) async {
    try {
      if (Platform.isLinux || Platform.isAndroid) {
        final r = await Process.run('ip', <String>['-o', '-4', 'addr', 'show']);
        final m = RegExp('inet ${RegExp.escape(ip)}/(\\d+)').firstMatch(r.stdout.toString());
        if (m != null) return int.parse(m.group(1)!);
      }
      if (Platform.isMacOS) {
        final r = await Process.run('ifconfig', <String>[]);
        final m = RegExp('inet ${RegExp.escape(ip)} netmask 0x([0-9a-fA-F]{8})').firstMatch(r.stdout.toString());
        if (m != null) {
          var v = int.parse(m.group(1)!, radix: 16);
          var n = 0;
          while (v != 0) {
            n += v & 1;
            v >>= 1;
          }
          return n;
        }
      }
    } catch (_) {}
    return null;
  }
}

// ---------------------------------------------------------------- ZeroTier
class ZeroTier {
  static String get _cli {
    if (Platform.isMacOS) {
      const p = '/Library/Application Support/ZeroTier/One/zerotier-cli';
      if (File(p).existsSync()) return p;
    }
    return 'zerotier-cli';
  }

  static bool get isDesktop => Platform.isLinux || Platform.isMacOS;

  /// Ausgabe von "zerotier-cli listnetworks" (oder Fehlermeldung).
  static Future<String> listNetworks({bool askAdmin = false}) async {
    if (!isDesktop) return '';
    try {
      final r = await Process.run(_cli, <String>['listnetworks']);
      final out = '${r.stdout}${r.stderr}'.trim();
      if (r.exitCode == 0) return out;
      // Linux ohne Rechte: mit Administrator-Rechten nochmal
      if (Platform.isLinux && askAdmin) {
        final r2 = await Process.run('pkexec', <String>['zerotier-cli', 'listnetworks']);
        return '${r2.stdout}${r2.stderr}'.trim();
      }
      return out;
    } catch (e) {
      return 'ZeroTier nicht gefunden: $e';
    }
  }

  /// Tritt dem Netzwerk bei. Gibt eine Meldung fuer den Benutzer zurueck.
  static Future<String> join(String nwid) async {
    if (!isDesktop) return 'Bitte in der ZeroTier-App dem Netzwerk $nwid beitreten.';
    try {
      final r = await Process.run(_cli, <String>['join', nwid]);
      if (r.exitCode == 0) return '${r.stdout}'.trim().isEmpty ? 'Beitritt angefragt.' : '${r.stdout}'.trim();
      if (Platform.isLinux) {
        final r2 = await Process.run('pkexec', <String>['zerotier-cli', 'join', nwid]);
        return '${r2.stdout}${r2.stderr}'.trim();
      }
      if (Platform.isMacOS) {
        final cmd = "'$_cli' join $nwid";
        final script = 'do shell script "${cmd.replaceAll('"', '\\"')}" with administrator privileges';
        final r2 = await Process.run('osascript', <String>['-e', script]);
        return '${r2.stdout}${r2.stderr}'.trim();
      }
      return '${r.stdout}${r.stderr}'.trim();
    } catch (e) {
      return 'ZeroTier ist nicht installiert ($e).\nDownload: https://www.zerotier.com/download/';
    }
  }
}
