// Postfach (TCP 9929) - kompatibel zu EarthMailNode im Windows-Manager.
// Direkt: PEMAIL1|MSG ...   Weiterleitung: RELAY/SEALED (verschluesselt + signiert)
// Schluessel: PEMAIL1|KEY    Anwesenheit: kommt vom Live-Status (PESTAT1).
import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:math';

import 'package:flutter/foundation.dart';

import 'mail_crypto.dart';
import 'util.dart';

const int kMailPort = 9929;
const int kMaxSubject = 100;
const int kMaxBody = 4000;
final RegExp _idRe = RegExp(r'^[0-9a-f]{32}$');

class MailMsg {
  String id = '';
  String fromName = '';
  String fromIp = '';
  String toName = '';
  String toIp = '';
  String subject = '';
  int createdUtc = 0;
  int receivedUtc = 0;
  int deliveredUtc = 0;
  bool read = false;
  String via = '';
  bool verified = false;
  int attempts = 0;
  int nextTryUtc = 0;
  String lastError = '';
  bool relayed = false;
  String relayedTo = '';
  int expiresUtc = 0;
  String blob = '';
  String body = '';
  String folder = '';

  static String _esc(String s) => s.replaceAll('\\', '\\\\').replaceAll('\r', '').replaceAll('\n', '\\n');

  static String _unesc(String s) {
    final sb = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      final ch = s[i];
      if (ch == '\\' && i + 1 < s.length) {
        final nx = s[i + 1];
        if (nx == 'n') {
          sb.write('\n');
          i++;
          continue;
        }
        if (nx == '\\') {
          sb.write('\\');
          i++;
          continue;
        }
      }
      sb.write(ch);
    }
    return sb.toString();
  }

  String toText() {
    final sb = StringBuffer('PEMSG1\n');
    void kv(String k, String v) => sb.write('$k=${_esc(v)}\n');
    kv('Id', id);
    kv('FromName', fromName);
    kv('FromIp', fromIp);
    kv('ToName', toName);
    kv('ToIp', toIp);
    kv('Subject', subject);
    kv('CreatedUtc', '$createdUtc');
    kv('ReceivedUtc', '$receivedUtc');
    kv('DeliveredUtc', '$deliveredUtc');
    kv('Read', read ? '1' : '0');
    kv('Via', via);
    kv('Verified', verified ? '1' : '0');
    kv('Attempts', '$attempts');
    kv('NextTryUtc', '$nextTryUtc');
    kv('LastError', lastError);
    kv('Relayed', relayed ? '1' : '0');
    kv('RelayedTo', relayedTo);
    kv('ExpiresUtc', '$expiresUtc');
    kv('Blob', blob);
    kv('Body', body);
    return sb.toString();
  }

  static MailMsg? fromText(String text) {
    if (!text.startsWith('PEMSG1')) return null;
    final m = MailMsg();
    for (var line in text.split('\n')) {
      if (line.endsWith('\r')) line = line.substring(0, line.length - 1);
      final eq = line.indexOf('=');
      if (eq <= 0) continue;
      final k = line.substring(0, eq);
      final v = _unesc(line.substring(eq + 1));
      int n() => int.tryParse(v) ?? 0;
      switch (k) {
        case 'Id':
          m.id = v;
          break;
        case 'FromName':
          m.fromName = v;
          break;
        case 'FromIp':
          m.fromIp = v;
          break;
        case 'ToName':
          m.toName = v;
          break;
        case 'ToIp':
          m.toIp = v;
          break;
        case 'Subject':
          m.subject = v;
          break;
        case 'CreatedUtc':
          m.createdUtc = n();
          break;
        case 'ReceivedUtc':
          m.receivedUtc = n();
          break;
        case 'DeliveredUtc':
          m.deliveredUtc = n();
          break;
        case 'Read':
          m.read = v == '1';
          break;
        case 'Via':
          m.via = v;
          break;
        case 'Verified':
          m.verified = v == '1';
          break;
        case 'Attempts':
          m.attempts = n();
          break;
        case 'NextTryUtc':
          m.nextTryUtc = n();
          break;
        case 'LastError':
          m.lastError = v;
          break;
        case 'Relayed':
          m.relayed = v == '1';
          break;
        case 'RelayedTo':
          m.relayedTo = v;
          break;
        case 'ExpiresUtc':
          m.expiresUtc = n();
          break;
        case 'Blob':
          m.blob = v;
          break;
        case 'Body':
          m.body = v;
          break;
      }
    }
    if (!_idRe.hasMatch(m.id)) return null;
    return m;
  }

  String get signText => '$id|$fromIp|$toIp|$createdUtc|$subject|$body';
  DateTime get created => DateTime.fromMillisecondsSinceEpoch(createdUtc);
}

String oneLine(String s, int max) {
  var t = s.replaceAll('\r', ' ').replaceAll('\n', ' ').replaceAll('|', '/').trim();
  if (t.length > max) t = t.substring(0, max);
  return t;
}

String cleanBody(String s, int max) {
  var t = s.replaceAll('\r', '');
  if (t.length > max) t = t.substring(0, max);
  return t;
}

class MailService extends ChangeNotifier {
  MailService({required this.secret, required this.myName, required this.myIp, required this.localIps, required this.dataDir});

  final String Function() secret;
  final String Function() myName;
  final String Function() myIp;
  final Set<String> Function() localIps;
  final Directory dataDir;

  RsaKeys? _own;
  bool keyReady = false;
  String status = '';
  final Map<String, int> _onlineSeen = <String, int>{};
  final Map<String, String> _onlineNames = <String, String>{};
  final Set<String> _kicked = <String>{};
  final Set<String> _seen = <String>{};
  final Map<String, int> _keyTry = <String, int>{};
  final Map<String, List<int>> _rate = <String, List<int>>{};
  final Random _rnd = Random();
  ServerSocket? _server;
  Timer? _timer;
  int _tick = 0;
  bool _working = false;
  int unread = 0;

  String get _sep => Platform.pathSeparator;
  String get root => '${dataDir.path}${_sep}Postfach';
  Directory _dir(String name) => Directory('$root$_sep$name');
  File get _seenFile => File('$root${_sep}empfangen.ids');
  File get _keyFile => File('${dataDir.path}${_sep}keys${_sep}postfach_schluessel.xml');

  Future<void> start() async {
    for (final d in <String>['Eingang', 'Ausgang', 'Gesendet', 'Weiterleitung', 'Schluessel']) {
      _dir(d).createSync(recursive: true);
    }
    _loadSeen();
    try {
      _server = await ServerSocket.bind(InternetAddress.anyIPv4, kMailPort);
      _server!.listen(_handleConn);
    } catch (e) {
      status = 'Postfach-Port $kMailPort belegt: $e';
    }
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _work());
    unawaited(_loadKey());
    _countUnread();
  }

  Future<void> stop() async {
    _timer?.cancel();
    await _server?.close();
  }

  Future<void> _loadKey() async {
    try {
      if (_keyFile.existsSync()) {
        var t = _keyFile.readAsStringSync().trim();
        if (t.startsWith('PLAIN:')) t = t.substring(6);
        final k = RsaKeys.fromXml(t);
        if (k != null && k.isPrivate) {
          _own = k;
          keyReady = true;
          notifyListeners();
          return;
        }
      }
    } catch (_) {}
    status = 'Erzeuge Postfach-Schlüssel (einmalig, kann etwas dauern) ...';
    notifyListeners();
    try {
      final xml = await Isolate.run(generatePrivateKeyXml);
      _keyFile.parent.createSync(recursive: true);
      _keyFile.writeAsStringSync('PLAIN:$xml');
      _own = RsaKeys.fromXml(xml);
      keyReady = _own != null;
      status = '';
    } catch (e) {
      status = 'Schlüssel konnte nicht erzeugt werden: $e';
    }
    notifyListeners();
  }

  // ------------------------------------------------------------ Anwesenheit
  void notePeer(String ip, String name) {
    if (!isValidIpv4(ip) || localIps().contains(ip)) return;
    final now = nowMs();
    final last = _onlineSeen[ip] ?? 0;
    _onlineSeen[ip] = now;
    _onlineNames[ip] = oneLine(name, 40);
    if (now - last > 60000) _kicked.add(ip);
  }

  Map<String, String> get onlinePeers {
    final now = nowMs();
    final m = <String, String>{};
    _onlineSeen.forEach((ip, t) {
      if (now - t < 45000) m[ip] = _onlineNames[ip] ?? ip;
    });
    return m;
  }

  // ------------------------------------------------------------ Ablage
  void _loadSeen() {
    try {
      if (_seenFile.existsSync()) {
        for (final l in _seenFile.readAsLinesSync()) {
          final t = l.trim();
          if (_idRe.hasMatch(t)) _seen.add(t);
        }
      }
      for (final f in _dir('Eingang').listSync()) {
        final n = f.uri.pathSegments.last;
        if (n.endsWith('.msg')) _seen.add(n.substring(0, n.length - 4));
      }
    } catch (_) {}
  }

  void _addSeen(String id) {
    if (!_seen.add(id)) return;
    try {
      _seenFile.writeAsStringSync('$id\n', mode: FileMode.append);
      if (_seen.length > 6000) {
        final lines = _seenFile.readAsLinesSync().where((l) => l.trim().isNotEmpty).toList();
        final keep = lines.length > 5000 ? lines.sublist(lines.length - 5000) : lines;
        _seenFile.writeAsStringSync('${keep.join('\n')}\n');
      }
    } catch (_) {}
  }

  void _save(String folder, MailMsg m) {
    if (!_idRe.hasMatch(m.id)) return;
    final f = File('${_dir(folder).path}$_sep${m.id}.msg');
    final tmp = File('${f.path}.${randomHex(8)}.tmp');
    tmp.writeAsStringSync(m.toText());
    tmp.renameSync(f.path);
  }

  bool _exists(String folder, String id) => File('${_dir(folder).path}$_sep$id.msg').existsSync();

  void _saveIfExists(String folder, MailMsg m) {
    if (_exists(folder, m.id)) _save(folder, m);
  }

  void _delete(String folder, String id) {
    try {
      File('${_dir(folder).path}$_sep$id.msg').deleteSync();
    } catch (_) {}
  }

  List<MailMsg> list(String folder) {
    final out = <MailMsg>[];
    try {
      for (final e in _dir(folder).listSync()) {
        if (e is! File || !e.path.endsWith('.msg')) continue;
        try {
          final m = MailMsg.fromText(e.readAsStringSync());
          if (m != null) {
            m.folder = folder;
            out.add(m);
          }
        } catch (_) {}
      }
    } catch (_) {}
    out.sort((a, b) => b.createdUtc.compareTo(a.createdUtc));
    return out;
  }

  void _countUnread() {
    unread = list('Eingang').where((m) => !m.read).length;
  }

  void markRead(MailMsg m, bool read) {
    m.read = read;
    _saveIfExists('Eingang', m);
    _countUnread();
    notifyListeners();
  }

  void deleteMsg(MailMsg m) {
    _delete(m.folder, m.id);
    _countUnread();
    notifyListeners();
  }

  /// Neue Nachricht in den Ausgang legen - wird innerhalb ~1 s zugestellt.
  String? send({required String toIp, String toName = '', required String subject, required String body}) {
    if (!isValidIpv4(toIp)) return 'Ungültige IP-Adresse.';
    if (localIps().contains(toIp) || toIp == myIp()) return 'An dich selbst kannst du nichts senden.';
    if (subject.trim().isEmpty && body.trim().isEmpty) return 'Betreff oder Text fehlt.';
    final m = MailMsg()
      ..id = randomHex(32)
      ..fromName = oneLine(myName(), 40)
      ..fromIp = myIp()
      ..toName = oneLine(toName, 40)
      ..toIp = toIp
      ..subject = oneLine(subject, kMaxSubject)
      ..body = cleanBody(body, kMaxBody)
      ..createdUtc = nowMs();
    _save('Ausgang', m);
    _kicked.add(toIp);
    notifyListeners();
    return null;
  }

  // ------------------------------------------------------------ Server
  Future<void> _handleConn(Socket s) async {
    final ip = s.remoteAddress.address.replaceFirst('::ffff:', '');
    final now = nowMs();
    final hist = _rate.putIfAbsent(ip, () => <int>[]);
    hist.removeWhere((t) => now - t > 60000);
    hist.add(now);
    if (hist.length > 40) {
      s.destroy();
      return;
    }
    final r = SocketReader(s);
    try {
      final line = await r.readLine(maxBytes: 70000, timeout: const Duration(seconds: 8));
      if (line == null) return;
      final reply = _process(line, ip);
      writeLine(s, reply);
      await s.flush();
    } catch (_) {
    } finally {
      try {
        await s.close();
      } catch (_) {}
      s.destroy();
    }
  }

  String _process(String line, String remoteIp) {
    if (!line.startsWith('PEMAIL1|')) return 'ERR|format';
    final f = pelCheckSigned(secret(), line);
    if (f == null || f.length < 3) return 'ERR|format';
    switch (f[1]) {
      case 'KEY':
        final own = _own;
        if (own == null) return 'ERR|nokey';
        return pelSigned(secret(), 'KEY|${b64Text(own.toPublicXml())}');
      case 'MSG':
        return _procMsg(f, remoteIp);
      case 'RELAY':
        return _procRelay(f, remoteIp);
      case 'SEALED':
        return _procSealed(f, remoteIp);
      default:
        return 'ERR|kind';
    }
  }

  String _procMsg(List<String> f, String remoteIp) {
    if (f.length < 8) return 'ERR|format';
    final id = f[2];
    if (!_idRe.hasMatch(id)) return 'ERR|id';
    if (!_isMine(f[4])) return 'NOTME';
    if (_seen.contains(id)) return 'DUP';
    final m = MailMsg()
      ..id = id
      ..fromName = oneLine(unB64Text(f[3]), 40)
      ..fromIp = remoteIp
      ..toIp = f[4]
      ..createdUtc = _sanTime(int.tryParse(f[5]) ?? 0)
      ..subject = oneLine(unB64Text(f[6]), kMaxSubject)
      ..body = cleanBody(unB64Text(f[7]), kMaxBody)
      ..receivedUtc = nowMs()
      ..via = 'direkt'
      ..verified = true;
    try {
      _save('Eingang', m);
    } catch (_) {
      return 'ERR|save';
    }
    _addSeen(id);
    if (m.fromName.isNotEmpty) notePeer(remoteIp, m.fromName);
    _newMail();
    return 'OK';
  }

  String _procRelay(List<String> f, String remoteIp) {
    if (f.length < 7) return 'ERR|format';
    final id = f[2];
    final toIp = f[3];
    if (!_idRe.hasMatch(id) || !isValidIpv4(toIp)) return 'ERR|id';
    final blob = f[6];
    if (blob.length > 30000) return 'ERR|size';
    if (_isMine(toIp)) return _openSealed(id, toIp, blob, '', remoteIp);
    if (_exists('Weiterleitung', id)) return 'OK';
    if (_dir('Weiterleitung').listSync().length >= 300) return 'ERR|full';
    final now = nowMs();
    final created = int.tryParse(f[4]) ?? 0;
    final exp = int.tryParse(f[5]) ?? 0;
    final m = MailMsg()
      ..id = id
      ..fromIp = remoteIp
      ..toIp = toIp
      ..createdUtc = created > 0 ? created : now
      ..receivedUtc = now
      ..expiresUtc = (exp > now && exp < now + 14 * 86400000) ? exp : now + 14 * 86400000
      ..blob = blob
      ..nextTryUtc = now + 3000;
    try {
      _save('Weiterleitung', m);
    } catch (_) {
      return 'ERR|save';
    }
    return 'OK';
  }

  String _procSealed(List<String> f, String remoteIp) {
    if (f.length < 5) return 'ERR|format';
    final id = f[2];
    if (!_idRe.hasMatch(id)) return 'ERR|id';
    if (!_isMine(f[3])) return 'NOTME';
    final holder = f.length >= 6 ? oneLine(unB64Text(f[5]), 40) : '';
    return _openSealed(id, f[3], f[4], holder, remoteIp);
  }

  bool _isMine(String ip) => ip == myIp() || localIps().contains(ip);

  int _sanTime(int t) {
    final now = nowMs();
    return (t <= 0 || t >= now + 86400000) ? now : t;
  }

  String _openSealed(String id, String toIp, String blob, String holderName, String remoteIp) {
    if (_seen.contains(id)) return 'DUP';
    final k = _own;
    if (k == null) return 'ERR|nokey';
    final plain = openSealed(k, blob);
    if (plain == null) return 'ERR|decrypt';
    final inner = MailMsg.fromText(plain);
    if (inner == null || inner.id != id || inner.toIp != toIp) return 'ERR|inner';
    if (!isValidIpv4(inner.fromIp)) {
      _addSeen(id);
      return 'OK';
    }
    var verified = false;
    final pub = _peerKey(inner.fromIp);
    if (pub != null && inner.blob.isNotEmpty) verified = verifyText(pub, inner.signText, inner.blob);
    final hn = holderName.isNotEmpty ? holderName : (_onlineNames[remoteIp] ?? '');
    final m = MailMsg()
      ..id = id
      ..fromName = oneLine(inner.fromName, 40)
      ..fromIp = inner.fromIp
      ..toIp = inner.toIp
      ..subject = oneLine(inner.subject, kMaxSubject)
      ..body = cleanBody(inner.body, kMaxBody)
      ..createdUtc = _sanTime(inner.createdUtc)
      ..receivedUtc = nowMs()
      ..verified = verified
      ..via = hn.isNotEmpty ? 'weitergeleitet über $hn ($remoteIp)' : 'weitergeleitet über $remoteIp';
    try {
      _save('Eingang', m);
    } catch (_) {
      return 'ERR|save';
    }
    _addSeen(id);
    _newMail();
    return 'OK';
  }

  void _newMail() {
    _countUnread();
    notifyListeners();
  }

  // ------------------------------------------------------------ Schluessel
  File _keyPath(String ip) => File('${_dir('Schluessel').path}$_sep${ip.replaceAll(':', '_')}.key');

  RsaKeys? _peerKey(String ip) {
    try {
      final f = _keyPath(ip);
      if (!f.existsSync()) return null;
      return RsaKeys.fromXml(f.readAsStringSync());
    } catch (_) {
      return null;
    }
  }

  Future<void> _fetchKeys() async {
    final now = nowMs();
    for (final ip in onlinePeers.keys) {
      final f = _keyPath(ip);
      final fresh = f.existsSync() && DateTime.now().difference(f.lastModifiedSync()).inHours < 24;
      if (fresh) continue;
      if (now - (_keyTry[ip] ?? 0) < 300000) continue;
      _keyTry[ip] = now;
      final reply = await _request(ip, pelSigned(secret(), 'PEMAIL1|KEY|${randomHex(8)}'));
      if (reply == null || !reply.startsWith('KEY|')) continue;
      final p = pelCheckSigned(secret(), reply);
      if (p == null || p.length < 2) continue;
      final xml = unB64Text(p[1]);
      if (!xml.contains('<Modulus>') || xml.contains('<D>')) continue;
      try {
        f.writeAsStringSync(xml);
      } catch (_) {}
    }
  }

  /// Eine Zeile senden, eine Antwortzeile lesen (null = nicht erreichbar).
  Future<String?> _request(String ip, String line) async {
    final src = myIp();
    final s = await connectTcp(ip, kMailPort, const Duration(milliseconds: 2500), sourceIp: src.isEmpty ? null : src);
    if (s == null) return null;
    final r = SocketReader(s);
    try {
      writeLine(s, line);
      await s.flush();
      return await r.readLine(maxBytes: 70000, timeout: const Duration(seconds: 8));
    } catch (_) {
      return null;
    } finally {
      s.destroy();
    }
  }

  // ------------------------------------------------------------ Arbeitsschleife
  static int _backoff(int attempts) {
    const steps = <int>[15000, 30000, 60000, 120000, 300000, 600000];
    final i = max(0, min(attempts - 1, steps.length - 1));
    return steps[i];
  }

  Future<void> _work() async {
    if (_working) return;
    _working = true;
    _tick++;
    try {
      final now = nowMs();
      final kicked = Set<String>.from(_kicked);
      _kicked.clear();
      var changed = false;
      for (final m in list('Ausgang')) {
        if (m.nextTryUtc > now && !kicked.contains(m.toIp)) continue;
        await _deliver(m);
        changed = true;
      }
      for (final m in list('Weiterleitung')) {
        if (m.expiresUtc < now) {
          _delete('Weiterleitung', m.id);
          continue;
        }
        if (m.nextTryUtc > now && !kicked.contains(m.toIp)) continue;
        final reply = await _request(
            m.toIp, pelSigned(secret(), 'PEMAIL1|SEALED|${m.id}|${m.toIp}|${m.blob}|${b64Text(oneLine(myName(), 40))}'));
        if (reply != null && (reply == 'OK' || reply == 'DUP' || reply == 'NOTME' || reply.startsWith('ERR|decrypt') || reply.startsWith('ERR|inner'))) {
          _delete('Weiterleitung', m.id);
        } else {
          m.attempts++;
          m.nextTryUtc = now + max(30000, _backoff(m.attempts));
          _saveIfExists('Weiterleitung', m);
        }
      }
      if (_tick % 20 == 0) await _fetchKeys();
      if (changed) notifyListeners();
    } catch (_) {
    } finally {
      _working = false;
    }
  }

  Future<void> _deliver(MailMsg m) async {
    final now = nowMs();
    if (!isValidIpv4(m.toIp)) {
      m.lastError = 'Ungültige Empfänger-IP';
      m.nextTryUtc = now + 3600000;
      _saveIfExists('Ausgang', m);
      return;
    }
    if (m.fromIp.isEmpty) m.fromIp = myIp();
    final line = pelSigned(secret(),
        'PEMAIL1|MSG|${m.id}|${b64Text(m.fromName)}|${m.toIp}|${m.createdUtc}|${b64Text(m.subject)}|${b64Text(m.body)}');
    final reply = await _request(m.toIp, line);
    if (reply == 'OK' || reply == 'DUP') {
      m.deliveredUtc = nowMs();
      if (m.via.isEmpty) m.via = 'direkt';
      if (_exists('Ausgang', m.id)) {
        _save('Gesendet', m);
        _delete('Ausgang', m.id);
      }
      return;
    }
    m.attempts++;
    if (reply == null) {
      m.lastError = 'Empfänger nicht erreichbar';
      m.nextTryUtc = now + _backoff(m.attempts);
      if (!m.relayed) await _tryRelay(m);
    } else {
      m.lastError = reply;
      m.nextTryUtc = now + 600000;
    }
    _saveIfExists('Ausgang', m);
  }

  Future<void> _tryRelay(MailMsg m) async {
    final own = _own;
    final pub = _peerKey(m.toIp);
    if (own == null || pub == null) return;
    try {
      final inner = MailMsg()
        ..id = m.id
        ..fromName = m.fromName
        ..fromIp = m.fromIp
        ..toIp = m.toIp
        ..createdUtc = m.createdUtc
        ..subject = m.subject
        ..body = m.body;
      inner.blob = signText(own, inner.signText);
      final blob = seal(pub, inner.toText());
      final exp = nowMs() + 14 * 86400000;
      final holders = onlinePeers.keys.where((ip) => ip != m.toIp && !localIps().contains(ip)).toList()..shuffle(_rnd);
      final ok = <String>[];
      for (final h in holders) {
        if (ok.length >= 3) break;
        final reply = await _request(h, pelSigned(secret(), 'PEMAIL1|RELAY|${m.id}|${m.toIp}|${m.createdUtc}|$exp|$blob'));
        if (reply == 'OK') ok.add(_onlineNames[h] ?? h);
      }
      if (ok.isNotEmpty) {
        m.relayed = true;
        m.relayedTo = ok.join(', ');
      }
    } catch (_) {}
  }
}
