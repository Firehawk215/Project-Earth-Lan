// Live-Status (UDP 9928): PESTAT1 "wer ist online / wer spielt was",
// PEEVT1 Spieleabende, PEEVTREQ1 "bitte alle Spieleabende nochmal senden".
// Byte-genau wie der Windows-Manager (siehe Doku/Protokolle.md).
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';

import 'util.dart';

const int kStatusPort = 9928;

class Manager {
  Manager({
    required this.name,
    required this.ip,
    required this.srcIp,
    required this.zt,
    required this.version,
    this.game = '',
    this.gameExe = '',
    this.joinPort = 0,
    this.server = '',
    required this.seen,
  });
  final String name;
  final String ip;
  String srcIp;
  final bool zt;
  final String version;
  final String game;
  final String gameExe;
  final int joinPort;
  final String server;
  int seen;

  String get address {
    final a = ip.isNotEmpty ? ip : srcIp;
    if (server.isNotEmpty) return server;
    if (game.isNotEmpty && joinPort > 0 && a.isNotEmpty) return '$a:$joinPort';
    return a.isNotEmpty ? a : '-';
  }

  String get bestIp => ip.isNotEmpty ? ip : srcIp;
}

class PelEvent {
  PelEvent({
    required this.id,
    required this.title,
    required this.game,
    required this.organizer,
    required this.note,
    required this.start,
    required this.created,
    required this.cancelHash,
    this.cancelled = false,
    this.cancelToken = '',
  });
  final String id;
  final String title;
  final String game;
  final String organizer;
  final String note;
  final int start; // Unix-Sekunden
  final int created;
  final String cancelHash;
  bool cancelled;
  String cancelToken;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'Id': id,
        'Title': title,
        'Game': game,
        'Organizer': organizer,
        'Note': note,
        'Start': start,
        'Created': created,
        'CancelHash': cancelHash,
        'Cancelled': cancelled,
        'CancelToken': cancelToken,
      };

  static PelEvent fromJson(Map<String, dynamic> j) => PelEvent(
        id: j['Id'] as String,
        title: (j['Title'] ?? '') as String,
        game: (j['Game'] ?? '') as String,
        organizer: (j['Organizer'] ?? '') as String,
        note: (j['Note'] ?? '') as String,
        start: (j['Start'] as num).toInt(),
        created: (j['Created'] as num).toInt(),
        cancelHash: (j['CancelHash'] ?? '') as String,
        cancelled: (j['Cancelled'] ?? false) as bool,
        cancelToken: (j['CancelToken'] ?? '') as String,
      );

  DateTime get startLocal => DateTime.fromMillisecondsSinceEpoch(start * 1000);
}

String sha256B64(String s) => base64.encode(sha256.convert(utf8.encode(s)).bytes);

/// Baut ein PESTAT1-Paket (ohne Spiel: Titel/Exe leer, Port 0, Server leer).
String buildPestat({
  required String secret,
  required String name,
  required String ip,
  required bool zt,
  int friendsOnline = 0,
  int friendsTotal = 0,
  String version = '2026.09.23',
  String gameTitle = '',
  String gameExe = '',
  int joinPort = 0,
  String server = '',
}) {
  final title = limitText(gameTitle.replaceAll('|', '/'), 48);
  final exe = gameExe.replaceAll('|', '/');
  final srv = server.replaceAll('|', '/');
  final core = 'PESTAT1|${displayName(name)}|$ip|${zt ? 1 : 0}|$friendsOnline|$friendsTotal|$version|$title|$exe|$joinPort|$srv';
  return pelSigned(secret, core);
}

String buildEventWire(String secret, PelEvent e) {
  final core = 'PEEVT1|${e.id}|${e.start}|${e.created}|${b64Text(e.title)}|${b64Text(e.game)}|'
      '${b64Text(e.organizer)}|${b64Text(e.note)}|${e.cancelHash}|${e.cancelled ? 1 : 0}|'
      '${e.cancelled ? e.cancelToken : ''}';
  return pelSigned(secret, core);
}

/// ConvertFrom-PelEventWire
PelEvent? parseEventWire(String secret, String txt) {
  final f = txt.split('|');
  if (f.length != 12 || f[0].toUpperCase() != 'PEEVT1') return null;
  final core = f.sublist(0, 11).join('|');
  if (!constTimeEquals(pelHmac(secret, core), f[11])) return null;
  if (!RegExp(r'^[0-9a-fA-F]{12}$').hasMatch(f[1])) return null;
  final start = int.tryParse(f[2].trim());
  final created = int.tryParse(f[3].trim());
  if (start == null || created == null) return null;
  if (f[10].isNotEmpty && !RegExp(r'^[0-9a-fA-F]{32}$').hasMatch(f[10])) return null;
  return PelEvent(
    id: f[1],
    start: start,
    created: created,
    title: limitText(unB64Text(f[4]), 60),
    game: limitText(unB64Text(f[5]), 60),
    organizer: limitText(unB64Text(f[6]), 32),
    note: limitText(unB64Text(f[7]), 160),
    cancelHash: f[8],
    cancelled: f[9] == '1',
    cancelToken: f[10],
  );
}

class StatusService extends ChangeNotifier {
  StatusService({
    required this.secret,
    required this.myName,
    required this.myIp,
    required this.broadcast,
    required this.localIps,
    required this.dataDir,
    required this.unicastTargets,
    required this.onPeerSeen,
  });

  final String Function() secret;
  final String Function() myName;
  final String Function() myIp;
  final String Function() broadcast;
  final Set<String> Function() localIps;
  final Directory dataDir;
  final Iterable<String> Function() unicastTargets;
  final void Function(String ip, String name) onPeerSeen;

  final Map<String, Manager> managers = <String, Manager>{};
  final Map<String, PelEvent> events = <String, PelEvent>{};
  final Map<String, String> ownTokens = <String, String>{};
  final Map<String, int> _lastWire = <String, int>{};
  final Map<String, int> _delay = <String, int>{};
  final Random _rnd = Random();
  final List<String> notices = <String>[];

  String manualGame = '';
  bool zeroTierConnected = false;

  RawDatagramSocket? _rx;
  RawDatagramSocket? _tx;
  Timer? _timer;
  int _tick = 0;
  int _lastReq = 0;
  bool running = false;
  String lastError = '';

  File get _eventsFile => File('${dataDir.path}${Platform.pathSeparator}events.json');
  File get _ownFile => File('${dataDir.path}${Platform.pathSeparator}events_eigene.json');

  Future<void> start() async {
    _loadEvents();
    try {
      _rx = await RawDatagramSocket.bind(InternetAddress.anyIPv4, kStatusPort, reuseAddress: true);
      _rx!.broadcastEnabled = true;
      _rx!.listen((ev) {
        if (ev == RawSocketEvent.read) {
          Datagram? d;
          while ((d = _rx!.receive()) != null) {
            _onDatagram(d!);
          }
        }
      });
    } catch (e) {
      lastError = 'UDP $kStatusPort belegt: $e';
    }
    await _openTx();
    running = true;
    // einmal beim Start: alle Spieleabende anfordern
    _send(pelSigned(secret(), 'PEEVTREQ1|${nowMs()}'));
    _sendStatus();
    _timer = Timer.periodic(const Duration(milliseconds: 500), (_) => _onTick());
  }

  Future<void> _openTx() async {
    try {
      _tx?.close();
    } catch (_) {}
    _tx = null;
    final ip = myIp();
    try {
      _tx = await RawDatagramSocket.bind(ip.isEmpty ? InternetAddress.anyIPv4 : InternetAddress(ip), 0);
    } catch (_) {
      _tx = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    }
    _tx!.broadcastEnabled = true;
  }

  Future<void> restartSender() => _openTx();

  void stop() {
    _timer?.cancel();
    _rx?.close();
    _tx?.close();
    running = false;
  }

  void _send(String text, {bool unicast = true}) {
    final tx = _tx;
    if (tx == null) return;
    final bytes = utf8.encode(text);
    final targets = <String>{'255.255.255.255', broadcast()};
    if (unicast) targets.addAll(unicastTargets());
    targets.remove(myIp());
    for (final t in targets) {
      if (!isValidIpv4(t)) continue;
      try {
        tx.send(bytes, InternetAddress(t), kStatusPort);
      } catch (_) {}
    }
  }

  void _sendStatus() {
    final pkt = buildPestat(
      secret: secret(),
      name: myName(),
      ip: myIp(),
      zt: zeroTierConnected,
      gameTitle: manualGame,
    );
    _send(pkt);
  }

  void _onTick() {
    _tick++;
    if (_tick % 16 == 0) _sendStatus();
    if (_tick % 2 == 0) _sendDueEvents();
    if (_tick % 40 == 0) {
      final now = nowMs();
      final before = managers.length;
      managers.removeWhere((k, m) => now - m.seen > 25000);
      if (managers.length != before) notifyListeners();
    }
    if (_tick % 120 == 0) _purgeEvents();
  }

  void _onDatagram(Datagram d) {
    final txt = utf8.decode(d.data, allowMalformed: true);
    final srcIp = d.address.address;
    final isSelf = localIps().contains(srcIp) || srcIp == myIp();
    if (txt.startsWith('PESTAT1|')) {
      if (isSelf) return;
      final f = txt.split('|');
      if (f.length < 8) return;
      final core = f.sublist(0, f.length - 1).join('|');
      if (!constTimeEquals(pelHmac(secret(), core), f.last)) return;
      onPeerSeen(srcIp, f[1]);
      final mgr = Manager(
        name: cleanName(f[1], 40),
        ip: f[2],
        srcIp: srcIp,
        zt: f[3] == '1',
        version: f[6],
        game: f.length >= 12 ? limitText(f[7], 60) : '',
        gameExe: f.length >= 12 ? f[8] : '',
        joinPort: f.length >= 12 ? (int.tryParse(f[9]) ?? 0) : 0,
        server: f.length >= 12 ? f[10] : '',
        seen: nowMs(),
      );
      // Doppelte (gleicher Name + gemeldete IP unter anderer Quell-IP)
      String? dupKey;
      for (final e in managers.entries) {
        final om = e.value;
        if (e.key != srcIp && om.name.toLowerCase() == mgr.name.toLowerCase() && om.ip.isNotEmpty && om.ip == mgr.ip) {
          dupKey = e.key;
          break;
        }
      }
      if (dupKey != null) {
        final old = managers[dupKey]!;
        if (old.srcIp == mgr.ip && srcIp != mgr.ip) {
          mgr.srcIp = old.srcIp;
          managers[dupKey] = mgr;
          notifyListeners();
          return;
        }
        managers.remove(dupKey);
      }
      managers[srcIp] = mgr;
      notifyListeners();
    } else if (txt.startsWith('PEEVT1|')) {
      final e = parseEventWire(secret(), txt);
      if (e == null) return;
      _heard(e.id);
      _merge(e);
    } else if (txt.startsWith('PEEVTREQ1|')) {
      if (isSelf) return;
      final f = txt.split('|');
      if (f.length != 3) return;
      if (!constTimeEquals(pelHmac(secret(), '${f[0]}|${f[1]}'), f[2])) return;
      final now = nowMs();
      if (now - _lastReq > 10000) {
        _lastReq = now;
        for (final id in events.keys) {
          _lastWire[id] = now;
          _delay[id] = _rnd.nextInt(4000);
        }
      }
    }
  }

  // ------------------------------------------------------------ Spieleabende
  void _heard(String id) {
    _lastWire[id] = nowMs();
    _delay[id] = 60000 + _rnd.nextInt(30000);
  }

  void _merge(PelEvent inc) {
    final now = nowSec();
    if (inc.start + 86400 < now) return;
    if (inc.start > now + 60 * 86400) return;
    final cur = events[inc.id];
    if (cur == null) {
      if (inc.cancelled) {
        if (inc.cancelToken.isEmpty || sha256B64(inc.cancelToken) != inc.cancelHash) return;
      } else if (events.values.where((e) => !e.cancelled).length >= 30) {
        return;
      }
      events[inc.id] = inc;
      if (!inc.cancelled) notices.add('Neuer Spieleabend: ${inc.title} (${formatDateTime(inc.startLocal)})');
      _saveEvents();
      notifyListeners();
      return;
    }
    if (cur.cancelled || !inc.cancelled) return;
    if (inc.cancelToken.isEmpty || sha256B64(inc.cancelToken) != cur.cancelHash) return;
    cur.cancelled = true;
    cur.cancelToken = inc.cancelToken;
    notices.add('Spieleabend abgesagt: ${cur.title}');
    _saveEvents();
    notifyListeners();
  }

  void _sendDueEvents() {
    final now = nowMs();
    final nowS = now ~/ 1000;
    var sent = 0;
    final list = events.values.toList()..sort((a, b) => a.start.compareTo(b.start));
    for (final e in list) {
      if (sent >= 2) break;
      if (e.start + 21600 < nowS) continue;
      final last = _lastWire[e.id] ?? 0;
      final delay = _delay[e.id] ?? 0;
      if (now - last < delay) continue;
      _send(buildEventWire(secret(), e));
      _heard(e.id);
      sent++;
    }
  }

  void _purgeEvents() {
    final now = nowSec();
    final before = events.length;
    events.removeWhere((k, e) => e.start + 86400 < now);
    if (events.length != before) {
      _saveEvents();
      notifyListeners();
    }
  }

  PelEvent createEvent({required String title, required String game, required String note, required DateTime start}) {
    final token = randomHex(32);
    final e = PelEvent(
      id: randomHex(12),
      title: limitText(title, 60),
      game: limitText(game, 60),
      organizer: displayName(myName()),
      note: limitText(note, 160),
      start: start.toUtc().millisecondsSinceEpoch ~/ 1000,
      created: nowSec(),
      cancelHash: sha256B64(token),
    );
    events[e.id] = e;
    ownTokens[e.id] = token;
    _lastWire[e.id] = 0;
    _delay[e.id] = 0;
    _saveEvents();
    notifyListeners();
    return e;
  }

  bool isOwn(String id) => ownTokens.containsKey(id);

  void cancelEvent(String id) {
    final e = events[id];
    final token = ownTokens[id];
    if (e == null || token == null || e.cancelled) return;
    e.cancelled = true;
    e.cancelToken = token;
    _lastWire[id] = 0;
    _delay[id] = 0;
    _saveEvents();
    notifyListeners();
  }

  void _loadEvents() {
    try {
      if (_eventsFile.existsSync()) {
        final list = jsonDecode(_eventsFile.readAsStringSync()) as List<dynamic>;
        for (final x in list) {
          final e = PelEvent.fromJson(x as Map<String, dynamic>);
          events[e.id] = e;
        }
      }
      if (_ownFile.existsSync()) {
        final m = jsonDecode(_ownFile.readAsStringSync()) as Map<String, dynamic>;
        m.forEach((k, v) => ownTokens[k] = v.toString());
      }
    } catch (_) {}
  }

  void _saveEvents() {
    try {
      _eventsFile.writeAsStringSync(jsonEncode(events.values.map((e) => e.toJson()).toList()));
      _ownFile.writeAsStringSync(jsonEncode(ownTokens));
    } catch (_) {}
  }

  List<Manager> get sortedManagers {
    final l = managers.values.toList();
    l.sort((a, b) {
      final ga = a.game.isEmpty ? 1 : 0;
      final gb = b.game.isEmpty ? 1 : 0;
      if (ga != gb) return ga.compareTo(gb);
      return a.name.toLowerCase().compareTo(b.name.toLowerCase());
    });
    return l;
  }

  List<PelEvent> get sortedEvents {
    final l = events.values.toList()..sort((a, b) => a.start.compareTo(b.start));
    return l;
  }

  void refreshNow() {
    _sendStatus();
    notifyListeners();
  }
}
