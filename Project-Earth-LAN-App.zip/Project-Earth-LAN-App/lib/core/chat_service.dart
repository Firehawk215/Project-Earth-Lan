// Text-Chat (TCP/UDP 9874) - kompatibel zu EarthChatNode im Windows-Manager.
// Ein TCP-Verbindung je Teilnehmer-Paar, Zeilen mit LF, UTF-8.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'util.dart';

const int kChatPort = 9874;

class ChatPeer {
  ChatPeer(this.id, this.name, this.ip, this.chan, this.socket, this.outgoing);
  final String id;
  String name;
  final String ip;
  String chan;
  final Socket socket;
  final bool outgoing;
  bool unread = false;
}

enum ChatKind { system, group, private, own }

class ChatLine {
  ChatLine(this.text, this.kind, {this.peerId = ''}) : time = DateTime.now();
  final DateTime time;
  final String text;
  final ChatKind kind;
  final String peerId;
}

class ChatService extends ChangeNotifier {
  ChatService({
    required this.myName,
    required this.myIp,
    required this.broadcast,
    required this.prefix,
    required this.dataDir,
    required this.onPeerIp,
  });

  final String Function() myName;
  final String Function() myIp;
  final String Function() broadcast;
  final int Function() prefix;
  final Directory dataDir;
  final void Function(String ip, String name) onPeerIp;

  final String nodeId = randomHex(12);
  final Map<String, ChatPeer> peers = <String, ChatPeer>{};
  final List<ChatLine> lines = <ChatLine>[];
  final Map<String, int> _lastDial = <String, int>{};
  final Set<String> _known = <String>{};
  String channel = '';
  int unreadTotal = 0;
  bool visible = false;

  ServerSocket? _server;
  RawDatagramSocket? _rx;
  RawDatagramSocket? _tx;
  Timer? _beacon;
  bool _scanning = false;

  String get _name => cleanName(myName(), 32);

  Future<void> start() async {
    final ip = myIp();
    try {
      _server = await ServerSocket.bind(ip.isEmpty ? InternetAddress.anyIPv4 : InternetAddress(ip), kChatPort);
    } catch (_) {
      try {
        _server = await ServerSocket.bind(InternetAddress.anyIPv4, kChatPort);
      } catch (e) {
        _sys('Chat-Port $kChatPort ist belegt: $e');
      }
    }
    _server?.listen((s) => _peerLoop(s, false));
    try {
      _rx = await RawDatagramSocket.bind(InternetAddress.anyIPv4, kChatPort, reuseAddress: true);
      _rx!.broadcastEnabled = true;
      _rx!.listen((ev) {
        if (ev != RawSocketEvent.read) return;
        Datagram? d;
        while ((d = _rx!.receive()) != null) {
          _onBeacon(d!);
        }
      });
    } catch (_) {}
    try {
      _tx = await RawDatagramSocket.bind(ip.isEmpty ? InternetAddress.anyIPv4 : InternetAddress(ip), 0);
    } catch (_) {
      _tx = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    }
    _tx!.broadcastEnabled = true;
    _sendBeacon();
    _beacon = Timer.periodic(const Duration(seconds: 3), (_) => _sendBeacon());
    unawaited(scan());
  }

  Future<void> stop() async {
    _beacon?.cancel();
    await _server?.close();
    _rx?.close();
    _tx?.close();
    for (final p in peers.values.toList()) {
      p.socket.destroy();
    }
    peers.clear();
  }

  void _sendBeacon() {
    final bytes = utf8.encode('PECHAT1B|$nodeId|$_name');
    for (final t in <String>{'255.255.255.255', broadcast()}) {
      try {
        _tx?.send(bytes, InternetAddress(t), kChatPort);
      } catch (_) {}
    }
  }

  void _onBeacon(Datagram d) {
    final f = utf8.decode(d.data, allowMalformed: true).split('|');
    if (f.length < 3 || f[0] != 'PECHAT1B' || f[1] == nodeId) return;
    final ip = d.address.address;
    if (ip == myIp()) return;
    if (peers.values.any((p) => p.ip == ip)) return;
    final now = nowMs();
    if (now - (_lastDial[ip] ?? 0) < 4000) return;
    _lastDial[ip] = now;
    unawaited(connectTo(ip, const Duration(milliseconds: 1500), found: cleanName(f[2], 32)));
  }

  Future<void> connectTo(String ip, Duration timeout, {String found = ''}) async {
    final s = await connectTcp(ip, kChatPort, timeout, sourceIp: myIp().isEmpty ? null : myIp());
    if (s == null) return;
    if (found.isNotEmpty) _sys('Teilnehmer automatisch gefunden: $found ($ip)');
    unawaited(_peerLoop(s, true));
  }

  /// Subnetz nach offenen Chat-Ports absuchen (wie beim Windows-Manager beim Start).
  Future<void> scan() async {
    final ip = myIp();
    if (ip.isEmpty || _scanning) return;
    _scanning = true;
    final hosts = hostsInSubnet(ip, prefix()).where((h) => h != ip).toList();
    var idx = 0;
    Future<void> worker() async {
      while (idx < hosts.length) {
        final h = hosts[idx++];
        if (peers.values.any((p) => p.ip == h)) continue;
        await connectTo(h, const Duration(milliseconds: 600));
      }
    }

    await Future.wait(List<Future<void>>.generate(48, (_) => worker()));
    _scanning = false;
    _sys('Suche nach Port $kChatPort abgeschlossen.');
  }

  Future<void> _peerLoop(Socket s, bool outgoing) async {
    final ip = s.remoteAddress.address;
    try {
      s.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    final reader = SocketReader(s, crIsBreak: true);
    ChatPeer? peer;
    try {
      writeLine(s, 'HELLO|PECHAT1|$nodeId|$_name|${cleanName(channel, 32)}');
      final hello = await reader.readLine(maxBytes: 64000, timeout: const Duration(seconds: 5));
      if (hello == null) throw Exception('kein HELLO');
      final f = _splitN(hello, '|', 5);
      if (f.length < 4 || f[0] != 'HELLO' || f[1] != 'PECHAT1') throw Exception('falsches HELLO');
      if (f[2] == nodeId) throw Exception('selbst');
      peer = ChatPeer(f[2], cleanName(f[3], 32), ip, f.length >= 5 ? cleanName(f[4], 32) : '', s, outgoing);
      if (!_register(peer)) {
        s.destroy();
        return;
      }
      onPeerIp(ip, peer.name);
      while (true) {
        final line = await reader.readLine(maxBytes: 64000);
        if (line == null) break;
        if (line.length > 8000) continue;
        _handle(peer, line);
      }
    } catch (_) {
      // Verbindung beendet
    } finally {
      if (peer != null && identical(peers[peer.id], peer)) {
        peers.remove(peer.id);
        _add('${peer.name} hat die Verbindung getrennt.', ChatKind.system, save: true);
      }
      try {
        s.destroy();
      } catch (_) {}
      notifyListeners();
    }
  }

  bool _register(ChatPeer p) {
    final old = peers[p.id];
    if (old == null) {
      peers[p.id] = p;
      if (_known.add(p.id)) _add('${p.name} (${p.ip}) ist beigetreten.', ChatKind.system, save: true);
      notifyListeners();
      return true;
    }
    final newInit = p.outgoing ? nodeId : p.id;
    final oldInit = old.outgoing ? nodeId : old.id;
    if (newInit.compareTo(oldInit) < 0) {
      peers[p.id] = p;
      try {
        old.socket.destroy();
      } catch (_) {}
      notifyListeners();
      return true;
    }
    return false;
  }

  void _handle(ChatPeer p, String line) {
    if (line.startsWith('MSG|')) {
      _add('${p.name}: ${line.substring(4)}', ChatKind.group, peerId: p.id, save: true);
      _notify();
    } else if (line.startsWith('PM|')) {
      p.unread = true;
      _add('[Privat] ${p.name}: ${line.substring(3)}', ChatKind.private, peerId: p.id, save: true);
      _notify();
    } else if (line.startsWith('NICK|')) {
      final nn = cleanName(line.substring(5), 32);
      if (nn.isNotEmpty) {
        final old = p.name;
        p.name = nn;
        _add('$old heißt jetzt $nn.', ChatKind.system, save: true);
      }
    } else if (line.startsWith('CHAN|')) {
      p.chan = cleanName(line.substring(5), 32);
      notifyListeners();
    }
  }

  static String _cleanLine(String t) => t.replaceAll('\r', ' ').replaceAll('\n', ' ');

  void _sendTo(ChatPeer p, String line) {
    try {
      writeLine(p.socket, line);
    } catch (_) {}
  }

  /// Nachricht senden: an [peerId] privat, sonst an Kanal bzw. alle.
  void send(String text, {String? peerId}) {
    final t = _cleanLine(text.trim());
    if (t.isEmpty) return;
    if (peerId != null && peers.containsKey(peerId)) {
      final p = peers[peerId]!;
      _sendTo(p, 'PM|$t');
      _add('Ich an ${p.name} (privat): $t', ChatKind.own, peerId: peerId, save: true);
    } else if (channel.isNotEmpty) {
      for (final p in peers.values) {
        if (p.chan == channel) _sendTo(p, 'MSG|$t');
      }
      _add("Ich [Kanal '$channel']: $t", ChatKind.own, save: true);
    } else {
      for (final p in peers.values) {
        _sendTo(p, 'MSG|$t');
      }
      _add('Ich: $t', ChatKind.own, save: true);
    }
  }

  void setChannel(String ch) {
    channel = cleanName(ch, 32);
    for (final p in peers.values) {
      _sendTo(p, 'CHAN|$channel');
    }
    _add(channel.isEmpty ? 'Du bist wieder im Gruppenchat.' : "Du bist jetzt im Kanal '$channel'.", ChatKind.system);
  }

  void rename(String n) {
    final nn = cleanName(n, 32);
    if (nn.isEmpty) return;
    for (final p in peers.values) {
      _sendTo(p, 'NICK|$nn');
    }
  }

  Set<String> get channels => <String>{
        for (final p in peers.values)
          if (p.chan.isNotEmpty) p.chan,
        if (channel.isNotEmpty) channel,
      };

  void markRead() {
    unreadTotal = 0;
    notifyListeners();
  }

  void _notify() {
    if (!visible) unreadTotal++;
  }

  void _sys(String t) => _add(t, ChatKind.system);

  void _add(String text, ChatKind kind, {String peerId = '', bool save = false}) {
    final l = ChatLine(text, kind, peerId: peerId);
    lines.add(l);
    if (lines.length > 1000) lines.removeRange(0, lines.length - 1000);
    if (save) _log(l);
    notifyListeners();
  }

  void _log(ChatLine l) {
    try {
      final d = Directory('${dataDir.path}${Platform.pathSeparator}chat');
      if (!d.existsSync()) d.createSync(recursive: true);
      final t = l.time;
      final f = File('${d.path}${Platform.pathSeparator}chat_${t.year}-${two(t.month)}-${two(t.day)}.log');
      f.writeAsStringSync('[${formatTime(t)}] ${l.text}\n', mode: FileMode.append, flush: false);
    } catch (_) {}
  }

  static List<String> _splitN(String s, String sep, int n) {
    final out = <String>[];
    var rest = s;
    while (out.length < n - 1) {
      final i = rest.indexOf(sep);
      if (i < 0) break;
      out.add(rest.substring(0, i));
      rest = rest.substring(i + sep.length);
    }
    out.add(rest);
    return out;
  }
}
