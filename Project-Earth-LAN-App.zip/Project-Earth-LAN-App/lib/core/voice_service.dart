// Voice-Chat (UDP 9873) - kompatibel zu EarthVoiceNode im Windows-Manager.
// Steuerung: "PV1|..." Textpakete. Audio: 0xA1 | NodeId(12 ASCII) | Seq(2, big endian)
// | G.711 u-law, 16 kHz mono, 320 Samples (20 ms) je Paket.
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';

import 'audio_io.dart';
import 'util.dart';

const int kVoicePort = 9873;
const int kFrameSamples = 320;

class VoicePeer {
  VoicePeer(this.id, this.name, this.ip);
  final String id;
  String name;
  String ip;
  String chan = '';
  bool locked = false;
  int lastSeen = 0;
  int lastAudio = 0;
}

class _Jitter {
  final List<Int16List> frames = <Int16List>[];
  bool playing = false;
}

// ---------------------------------------------------------------- u-law
int muLawEncode(int sample) {
  var s = sample;
  final sign = (s >> 8) & 0x80;
  if (sign != 0) s = -s;
  if (s > 32635) s = 32635;
  s += 0x84;
  var exponent = 7;
  for (var mask = 0x4000; (s & mask) == 0 && exponent > 0; mask >>= 1) {
    exponent--;
  }
  final mantissa = (s >> (exponent + 3)) & 0x0F;
  return (~(sign | (exponent << 4) | mantissa)) & 0xFF;
}

int muLawDecode(int b) {
  final u = ~b & 0xFF;
  final sign = u & 0x80;
  final exponent = (u >> 4) & 0x07;
  final mantissa = u & 0x0F;
  var s = ((mantissa << 3) + 0x84) << exponent;
  s -= 0x84;
  return sign != 0 ? -s : s;
}

// ---------------------------------------------------------------- Passwort
/// HashPw: PBKDF2-HMAC-SHA1(pw, "ProjectEarthLanVoice:" + Kanal, 3000, 16 Bytes) als Hex (gross).
String voiceHashPw(String channel, String pw) {
  final key = utf8.encode(pw);
  final salt = utf8.encode('ProjectEarthLanVoice:$channel');
  final hmac = Hmac(sha1, key);
  // ein Block reicht (16 <= 20 Bytes)
  final first = hmac.convert(<int>[...salt, 0, 0, 0, 1]).bytes;
  var u = first;
  final t = List<int>.from(first);
  for (var i = 1; i < 3000; i++) {
    u = hmac.convert(u).bytes;
    for (var j = 0; j < t.length; j++) {
      t[j] ^= u[j];
    }
  }
  return t.sublist(0, 16).map((b) => b.toRadixString(16).padLeft(2, '0')).join().toUpperCase();
}

String _cleanVoiceName(String s) => cleanName(s, 40);

class VoiceService extends ChangeNotifier {
  VoiceService({required this.myName, required this.myIp, required this.broadcast, required this.extraTargets});

  final String Function() myName;
  final String Function() myIp;
  final String Function() broadcast;
  final Iterable<String> Function() extraTargets;

  final String nodeId = randomHex(12);
  final Map<String, VoicePeer> peers = <String, VoicePeer>{};
  final Set<String> members = <String>{};
  final Set<String> _denied = <String>{};
  final Map<String, _Jitter> _jitter = <String, _Jitter>{};
  final Map<String, int> latencies = <String, int>{}; // ip -> ms
  final Map<String, int> _pingSent = <String, int>{};
  final Map<String, int> peerVolume = <String, int>{}; // ip -> 0..200 %
  final List<String> messages = <String>[];

  /// Eingehender Anruf: (peerId, Name) - die Oberflaeche fragt nach.
  void Function(String peerId, String name)? onCall;

  String myChannel = '';
  bool myLocked = false;
  String _myHash = '';
  String _pendingOut = '';
  int _seq = 0;

  bool micMuted = false;
  bool deafened = false;
  bool pttMode = false;
  bool pttHeld = false;
  int threshold = 350;
  int volumePercent = 100;
  int micLevel = 0;
  int _lastVoice = 0;

  RawDatagramSocket? _sock;
  Timer? _beacon;
  Timer? _mixTimer;
  Timer? _uiTimer;
  AudioIo? _audio;
  bool audioOn = false;
  String lastError = '';
  final List<int> _micBuf = <int>[];
  final Stopwatch _clock = Stopwatch();
  int _framesOut = 0;

  String get _name => _cleanVoiceName(myName());

  Future<void> start() async {
    try {
      final s = await RawDatagramSocket.bind(InternetAddress.anyIPv4, kVoicePort);
      _sock = s;
      s.broadcastEnabled = true;
      s.listen((ev) {
        if (ev != RawSocketEvent.read) return;
        Datagram? d;
        while ((d = s.receive()) != null) {
          _onDatagram(d!);
        }
      });
    } catch (e) {
      lastError = 'UDP-Port $kVoicePort konnte nicht geöffnet werden: $e';
      notifyListeners();
      return;
    }
    _beaconTick();
    _beacon = Timer.periodic(const Duration(seconds: 2), (_) => _beaconTick());
    _uiTimer = Timer.periodic(const Duration(milliseconds: 400), (_) => notifyListeners());
  }

  Future<void> stop() async {
    await stopAudio();
    _beacon?.cancel();
    _uiTimer?.cancel();
    _leaveInternal();
    for (final p in peers.values) {
      _sendTo(p.ip, 'PV1|BYE|$nodeId');
    }
    _sendBroadcast('PV1|BYE|$nodeId');
    _sock?.close();
    _sock = null;
  }

  // ------------------------------------------------------------ Netz
  void _sendTo(String ip, String text) => _sendBytes(ip, utf8.encode(text));

  void _sendBytes(String ip, List<int> bytes) {
    try {
      _sock?.send(bytes, InternetAddress(ip), kVoicePort);
    } catch (_) {}
  }

  void _sendBroadcast(String text) {
    final b = utf8.encode(text);
    for (final t in <String>{broadcast(), '255.255.255.255'}) {
      _sendBytes(t, b);
    }
  }

  String _presence() => 'PV1|HI|$nodeId|$_name|$myChannel|${myLocked ? 1 : 0}';

  void _sendPresenceAll() {
    final text = _presence();
    _sendBroadcast(text);
    final ips = <String>{...peers.values.map((p) => p.ip), ...extraTargets()};
    ips.remove(myIp());
    for (final ip in ips) {
      if (isValidIpv4(ip)) _sendTo(ip, text);
    }
  }

  void _beaconTick() {
    _sendPresenceAll();
    // Latenz
    final now = nowMs();
    for (final p in peers.values) {
      final tok = randomHex(8);
      _pingSent['${p.ip}|$tok'] = now;
      _sendTo(p.ip, 'PV1|LPING|$nodeId|$tok');
    }
    _pingSent.removeWhere((k, t) => now - t > 10000);
    // noch nicht verbundene Kanal-Teilnehmer erneut anfragen
    if (myChannel.isNotEmpty) {
      for (final p in peers.values) {
        if (p.chan == myChannel && !members.contains(p.id) && !_denied.contains(p.id)) {
          _sendTo(p.ip, 'PV1|JOIN|$nodeId|$myChannel|$_myHash');
        }
      }
    }
    // alte Teilnehmer entfernen
    final dead = peers.entries.where((e) => now - e.value.lastSeen > 9000).map((e) => e.key).toList();
    for (final d in dead) {
      peers.remove(d);
      members.remove(d);
      _jitter.remove(d);
    }
    notifyListeners();
  }

  VoicePeer _touch(String id, String name, String ip) {
    final p = peers.putIfAbsent(id, () => VoicePeer(id, name.isNotEmpty ? name : id, ip));
    if (name.isNotEmpty) p.name = name;
    p.ip = ip;
    p.lastSeen = nowMs();
    return p;
  }

  void _onDatagram(Datagram d) {
    final data = d.data;
    final ip = d.address.address;
    if (ip == myIp()) return;
    if (data.length > 15 && data[0] == 0xA1) {
      _onAudio(data);
    } else if (data.length > 4 && data[0] == 0x50) {
      _onControl(utf8.decode(data, allowMalformed: true), ip);
    }
  }

  void _onControl(String text, String ip) {
    final f = text.split('|');
    if (f.length < 3 || f[0] != 'PV1') return;
    final type = f[1];
    final id = f[2];
    if (type == 'LPING' && f.length >= 4) {
      _sendTo(ip, 'PV1|LPONG|$nodeId|${f[3]}');
      return;
    }
    if (type == 'LPONG' && f.length >= 4) {
      final sent = _pingSent.remove('$ip|${f[3]}');
      if (sent != null) latencies[ip] = nowMs() - sent;
      return;
    }
    if (id == nodeId || id.length != 12) return;
    switch (type) {
      case 'HI':
        if (f.length < 6) return;
        final isNew = !peers.containsKey(id);
        final p = _touch(id, _cleanVoiceName(f[3]), ip);
        p.chan = f[4];
        p.locked = f[5] == '1';
        if (members.contains(id) && p.chan != myChannel) members.remove(id);
        if (isNew) _sendTo(ip, _presence());
        break;
      case 'JOIN':
        if (f.length < 5) return;
        final jch = f[3];
        final jh = f[4];
        if (myChannel.isNotEmpty && myChannel == jch && (!myLocked || jh == _myHash)) {
          _touch(id, '', ip);
          members.add(id);
          _sendTo(ip, 'PV1|OK|$nodeId|$jch');
        } else {
          _sendTo(ip, 'PV1|NO|$nodeId|$jch');
        }
        break;
      case 'OK':
        if (f.length < 4) return;
        if (myChannel.isNotEmpty && myChannel == f[3]) {
          _touch(id, '', ip);
          members.add(id);
        }
        break;
      case 'NO':
        if (f.length < 4) return;
        if (myChannel.isNotEmpty && myChannel == f[3] && !_denied.contains(id)) {
          _denied.add(id);
          final lost = myChannel;
          if (members.isEmpty) _leaveInternal();
          _msg("Beitritt zu '$lost' abgelehnt (Passwort falsch oder Kanal geschlossen).");
        }
        break;
      case 'LEAVE':
        members.remove(id);
        break;
      case 'BYE':
        peers.remove(id);
        members.remove(id);
        break;
      case 'CALL':
        if (f.length < 4) return;
        final nm = _cleanVoiceName(f[3]);
        _touch(id, nm, ip);
        final cb = onCall;
        if (cb != null) cb(id, nm);
        break;
      case 'DECL':
        final who = peers[id]?.name ?? id;
        if (_pendingOut == id) _pendingOut = '';
        _msg('$who hat den Anruf abgelehnt.');
        break;
      case 'ACC':
        if (f.length < 4) return;
        if (_pendingOut == id) {
          _pendingOut = '';
          _touch(id, '', ip);
          _leaveInternal();
          myChannel = f[3];
          myLocked = true;
          _myHash = randomHex(32);
          members.add(id);
          _sendTo(ip, 'PV1|OK|$nodeId|${f[3]}');
          _msg('Privatgespräch gestartet.');
          _sendPresenceAll();
        }
        break;
    }
    notifyListeners();
  }

  void _msg(String t) {
    messages.add('[${formatTime(DateTime.now())}] $t');
    if (messages.length > 100) messages.removeAt(0);
    notifyListeners();
  }

  // ------------------------------------------------------------ Kanaele
  void _leaveInternal() {
    if (myChannel.isNotEmpty) {
      for (final id in members) {
        final p = peers[id];
        if (p != null) _sendTo(p.ip, 'PV1|LEAVE|$nodeId|$myChannel');
      }
    }
    members.clear();
    _denied.clear();
    myChannel = '';
    myLocked = false;
    _myHash = '';
    _jitter.clear();
  }

  String? createChannel(String name, String password) {
    final n = _cleanVoiceName(name);
    if (n.isEmpty) return 'Bitte einen Kanalnamen eingeben.';
    if (n.startsWith('@')) return 'Kanalnamen dürfen nicht mit @ beginnen.';
    if (peers.values.any((p) => p.chan == n)) return 'Diesen Kanal gibt es schon - bitte beitreten.';
    _leaveInternal();
    myChannel = n;
    myLocked = password.isNotEmpty;
    _myHash = voiceHashPw(n, password);
    _sendPresenceAll();
    _msg("Kanal '$n' erstellt.");
    return null;
  }

  String? joinChannel(String name, String password) {
    final n = _cleanVoiceName(name);
    if (n.isEmpty) return 'Kein Kanal gewählt.';
    if (n.startsWith('@')) return 'Dieser Kanal ist privat.';
    _leaveInternal();
    myChannel = n;
    _myHash = voiceHashPw(n, password);
    var locked = false;
    for (final p in peers.values) {
      if (p.chan == n) {
        _sendTo(p.ip, 'PV1|JOIN|$nodeId|$n|$_myHash');
        if (p.locked) locked = true;
      }
    }
    myLocked = locked;
    _sendPresenceAll();
    _msg("Kanal '$n' beigetreten.");
    return null;
  }

  void leaveChannel() {
    _leaveInternal();
    _sendPresenceAll();
    notifyListeners();
  }

  bool isChannelLocked(String name) => peers.values.any((p) => p.chan == name && p.locked);

  String? call(String peerId) {
    final p = peers[peerId];
    _pendingOut = peerId;
    if (p == null) return 'Teilnehmer nicht gefunden.';
    _sendTo(p.ip, 'PV1|CALL|$nodeId|$_name');
    _msg('Rufe ${p.name} an ...');
    return null;
  }

  void answerCall(String peerId, bool accept) {
    final p = peers[peerId];
    if (p == null) return;
    if (!accept) {
      _sendTo(p.ip, 'PV1|DECL|$nodeId');
      return;
    }
    final pair = nodeId.compareTo(peerId) < 0 ? '@$nodeId~$peerId' : '@$peerId~$nodeId';
    _leaveInternal();
    myChannel = pair;
    myLocked = true;
    _myHash = randomHex(32);
    members.add(peerId);
    _sendTo(p.ip, 'PV1|ACC|$nodeId|$pair');
    _sendPresenceAll();
    _msg('Privatgespräch mit ${p.name}.');
  }

  /// Alle Kanaele: Name -> (Anzahl, Passwort?)
  Map<String, (int, bool)> get channels {
    final m = <String, (int, bool)>{};
    for (final p in peers.values) {
      if (p.chan.isEmpty || p.chan.startsWith('@')) continue;
      final old = m[p.chan];
      m[p.chan] = ((old?.$1 ?? 0) + 1, (old?.$2 ?? false) || p.locked);
    }
    if (myChannel.isNotEmpty && !myChannel.startsWith('@')) {
      final old = m[myChannel];
      m[myChannel] = ((old?.$1 ?? 0) + 1, (old?.$2 ?? false) || myLocked);
    }
    return m;
  }

  bool isTalking(VoicePeer p) => nowMs() - p.lastAudio < 400;
  bool get meTalking => !micMuted && _lastVoice != 0 && nowMs() - _lastVoice <= 300;

  // ------------------------------------------------------------ Audio
  Future<String?> startAudio() async {
    if (audioOn) return null;
    final io = AudioIo.create();
    final err = await io.start(_onPcm);
    if (err != null) {
      lastError = err;
      notifyListeners();
      return err;
    }
    _audio = io;
    audioOn = true;
    lastError = '';
    _clock
      ..reset()
      ..start();
    _framesOut = 0;
    _mixTimer = Timer.periodic(const Duration(milliseconds: 10), (_) => _mixTick());
    notifyListeners();
    return null;
  }

  Future<void> stopAudio() async {
    _mixTimer?.cancel();
    _mixTimer = null;
    audioOn = false;
    await _audio?.stop();
    _audio = null;
    _micBuf.clear();
    notifyListeners();
  }

  void _onPcm(Uint8List pcm) {
    _micBuf.addAll(pcm);
    while (_micBuf.length >= kFrameSamples * 2) {
      final frame = Int16List(kFrameSamples);
      for (var i = 0; i < kFrameSamples; i++) {
        var v = _micBuf[2 * i] | (_micBuf[2 * i + 1] << 8);
        if (v >= 32768) v -= 65536;
        frame[i] = v;
      }
      _micBuf.removeRange(0, kFrameSamples * 2);
      _onMicFrame(frame);
    }
  }

  void _onMicFrame(Int16List f) {
    var sum = 0.0;
    for (final s in f) {
      sum += s * s;
    }
    final rms = sqrt(sum / f.length).toInt();
    micLevel = rms;
    final now = nowMs();
    if (pttMode) {
      if (!micMuted && pttHeld) _lastVoice = now;
    } else {
      if (!micMuted && rms > threshold) _lastVoice = now;
    }
    if (micMuted || _lastVoice == 0 || now - _lastVoice > 300) return;
    final targets = <String>[
      for (final id in members)
        if (peers[id] != null) peers[id]!.ip,
    ];
    if (targets.isEmpty) return;
    _seq = (_seq + 1) & 0xFFFF;
    final pkt = Uint8List(15 + f.length);
    pkt[0] = 0xA1;
    final idb = ascii.encode(nodeId);
    pkt.setRange(1, 13, idb);
    pkt[13] = (_seq >> 8) & 0xFF;
    pkt[14] = _seq & 0xFF;
    for (var i = 0; i < f.length; i++) {
      pkt[15 + i] = muLawEncode(f[i]);
    }
    for (final ip in targets) {
      _sendBytes(ip, pkt);
    }
  }

  void _onAudio(Uint8List d) {
    if (deafened) return;
    final id = String.fromCharCodes(d, 1, 13);
    if (!members.contains(id)) return;
    peers[id]?.lastAudio = nowMs();
    final n = d.length - 15;
    if (n <= 0 || n > 1920) return;
    final fr = Int16List(n);
    for (var i = 0; i < n; i++) {
      fr[i] = muLawDecode(d[15 + i]);
    }
    final j = _jitter.putIfAbsent(id, () => _Jitter());
    j.frames.add(fr);
    while (j.frames.length > 12) {
      j.frames.removeAt(0);
    }
  }

  /// Gibt im 20-ms-Takt gemischte Frames an den Lautsprecher (mit 2 Frames Vorlauf).
  void _mixTick() {
    final io = _audio;
    if (io == null) return;
    final due = _clock.elapsedMilliseconds ~/ 20 + 2;
    var guard = 0;
    while (_framesOut < due && guard < 10) {
      io.play(_pullFrame());
      _framesOut++;
      guard++;
    }
    if (_framesOut < due) _framesOut = due; // nach Haenger nicht nachholen
  }

  Uint8List _pullFrame() {
    final acc = List<int>.filled(kFrameSamples, 0);
    for (final e in _jitter.entries) {
      final j = e.value;
      if (!j.playing) {
        if (j.frames.length >= 3) {
          j.playing = true;
        } else {
          continue;
        }
      }
      if (j.frames.isEmpty) {
        j.playing = false;
        continue;
      }
      final fr = j.frames.removeAt(0);
      final ip = peers[e.key]?.ip ?? '';
      final pv = peerVolume[ip] ?? 100;
      final len = min(fr.length, kFrameSamples);
      for (var i = 0; i < len; i++) {
        acc[i] += fr[i] * pv ~/ 100;
      }
    }
    final out = Uint8List(kFrameSamples * 2);
    if (deafened) return out;
    for (var i = 0; i < kFrameSamples; i++) {
      var v = acc[i] * volumePercent ~/ 100;
      if (v > 32767) v = 32767;
      if (v < -32768) v = -32768;
      out[2 * i] = v & 0xFF;
      out[2 * i + 1] = (v >> 8) & 0xFF;
    }
    return out;
  }
}
