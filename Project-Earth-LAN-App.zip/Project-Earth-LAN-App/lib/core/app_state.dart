// Zentrale: Einstellungen, Netzwerk und alle Dienste.
import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'chat_service.dart';
import 'file_service.dart';
import 'mail_service.dart';
import 'netinfo.dart';
import 'settings.dart';
import 'status_service.dart';
import 'voice_service.dart';

class AppState extends ChangeNotifier {
  final Settings settings = Settings();
  final NetInfo net = NetInfo();
  StatusService? status;
  ChatService? chat;
  FileService? files;
  MailService? mail;
  VoiceService? voice;
  bool started = false;
  String ztText = '';
  final Map<String, String> knownPeers = <String, String>{}; // ip -> name
  Timer? _netTimer;

  Future<void> init() async {
    await settings.load();
    await net.refresh(settings);
    notifyListeners();
    if (settings.hasCode) await startServices();
  }

  Iterable<String> _unicastTargets() => <String>{...knownPeers.keys, ...settings.manualPeers};

  void _notePeer(String ip, String name) {
    if (ip == net.ip) return;
    final isNew = !knownPeers.containsKey(ip);
    knownPeers[ip] = name;
    if (isNew) notifyListeners();
  }

  int generation = 0;

  Future<void> startServices() async {
    if (started) return;
    started = true;
    generation++;
    final dir = settings.dataDir;
    mail = MailService(
      secret: () => settings.effectiveCode,
      myName: () => settings.name,
      myIp: () => net.ip,
      localIps: () => net.localIps,
      dataDir: dir,
    );
    status = StatusService(
      secret: () => settings.effectiveCode,
      myName: () => settings.name,
      myIp: () => net.ip,
      broadcast: () => net.broadcast,
      localIps: () => net.localIps,
      dataDir: dir,
      unicastTargets: _unicastTargets,
      onPeerSeen: (ip, name) {
        mail?.notePeer(ip, name);
        _notePeer(ip, name);
      },
    );
    chat = ChatService(
      myName: () => settings.name,
      myIp: () => net.ip,
      broadcast: () => net.broadcast,
      prefix: () => net.prefix,
      dataDir: dir,
      onPeerIp: _notePeer,
    );
    files = FileService(
      myName: () => settings.name,
      myIp: () => net.ip,
      broadcast: () => net.broadcast,
      downloadDir: () => settings.downloadDir,
      streams: () => settings.streams,
      limitMb: () => settings.limitMb,
    );
    voice = VoiceService(
      myName: () => settings.name,
      myIp: () => net.ip,
      broadcast: () => net.broadcast,
      extraTargets: _unicastTargets,
    );
    status!.zeroTierConnected = net.zeroTierLikely;
    await mail!.start();
    await status!.start();
    await chat!.start();
    await files!.start();
    await voice!.start();
    _netTimer = Timer.periodic(const Duration(seconds: 15), (_) => _checkNet());
    unawaited(refreshZeroTier());
    notifyListeners();
  }

  Future<void> _checkNet() async {
    final oldIp = net.ip;
    await net.refresh(settings);
    status?.zeroTierConnected = net.zeroTierLikely;
    if (net.ip != oldIp) await restartServices();
  }

  Future<void> restartServices() async {
    _netTimer?.cancel();
    status?.stop();
    await chat?.stop();
    await files?.stop();
    await mail?.stop();
    await voice?.stop();
    started = false;
    await net.refresh(settings);
    await startServices();
  }

  Future<void> refreshZeroTier({bool askAdmin = false}) async {
    if (!ZeroTier.isDesktop) return;
    ztText = await ZeroTier.listNetworks(askAdmin: askAdmin);
    notifyListeners();
  }

  /// Alle bekannten Mitspieler (fuer Auswahllisten): ip -> Name
  Map<String, String> get allPeers {
    final m = <String, String>{...knownPeers};
    status?.managers.forEach((k, v) => m[v.bestIp] = v.name);
    chat?.peers.forEach((k, v) => m[v.ip] = v.name);
    files?.peers.forEach((k, v) => m[v.ip] = v.name);
    voice?.peers.forEach((k, v) => m[v.ip] = v.name);
    mail?.onlinePeers.forEach((ip, name) => m[ip] = name);
    for (final ip in settings.manualPeers) {
      m.putIfAbsent(ip, () => ip);
    }
    m.remove(net.ip);
    return m;
  }

  String get platformName {
    if (Platform.isAndroid) return 'Android';
    if (Platform.isMacOS) return 'macOS';
    if (Platform.isLinux) return 'Linux';
    return Platform.operatingSystem;
  }
}
