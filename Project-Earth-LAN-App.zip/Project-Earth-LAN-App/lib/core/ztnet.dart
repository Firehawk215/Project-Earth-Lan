// ZTNET-API (eigene Netzwerke, wie Option 13 im Windows-Manager).
//   GET    /api/v1/network                   eigene Netzwerke
//   POST   /api/v1/network         {name}    Netzwerk erstellen
//   GET    /api/v1/network/<id>/member       Mitglieder
//   POST   /api/v1/network/<id>/member/<mid> {name|description|authorized}
//   DELETE /api/v1/network/<id>/member/<mid> Mitglied entfernen
import 'dart:async';
import 'dart:convert';
import 'dart:io';

class ZtResult {
  ZtResult(this.ok, this.status, this.data, this.error);
  final bool ok;
  final int status;
  final dynamic data;
  final String error;
}

class ZtnetClient {
  ZtnetClient(this.baseUrl, this.token);
  final String baseUrl;
  final String token;

  Future<ZtResult> call(String method, String path, [Map<String, dynamic>? body]) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final base = baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
      final req = await client.openUrl(method, Uri.parse('$base$path')).timeout(const Duration(seconds: 12));
      req.headers.set('x-ztnet-auth', token);
      req.headers.set(HttpHeaders.acceptHeader, 'application/json');
      req.headers.set(HttpHeaders.userAgentHeader, 'ProjectEarthLanManager');
      if (body != null) {
        final bytes = utf8.encode(jsonEncode(body));
        req.headers.contentType = ContentType('application', 'json', charset: 'utf-8');
        req.contentLength = bytes.length;
        req.add(bytes);
      }
      final resp = await req.close().timeout(const Duration(seconds: 12));
      final text = await resp.transform(utf8.decoder).join().timeout(const Duration(seconds: 12));
      dynamic data;
      if (text.isNotEmpty) {
        try {
          data = jsonDecode(text);
        } catch (_) {
          data = text;
        }
      }
      final code = resp.statusCode;
      if (code >= 200 && code < 300) return ZtResult(true, code, data, '');
      var msg = '';
      if (data is Map && data['error'] != null) msg = ' (${data['error']})';
      final err = switch (code) {
        401 => 'Zugriff verweigert - der API-Token ist ungültig oder abgelaufen.',
        403 => 'Keine Berechtigung für diese Aktion.',
        404 => 'Nicht gefunden.',
        405 => 'Diese Aktion unterstützt das Panel nicht.',
        429 => 'Zu viele Anfragen (max. 50 pro Minute) - bitte kurz warten.',
        _ => 'Fehler $code',
      };
      return ZtResult(false, code, data, '$err$msg');
    } catch (e) {
      return ZtResult(false, 0, null,
          'Panel nicht erreichbar ($baseUrl): $e\n\nBist du mit dem Project-Earth-LAN-Netzwerk verbunden (ZeroTier)?');
    } finally {
      client.close(force: true);
    }
  }

  Future<ZtResult> networks() => call('GET', '/api/v1/network');
  Future<ZtResult> createNetwork(String name) => call('POST', '/api/v1/network', <String, dynamic>{'name': name});
  Future<ZtResult> network(String id) => call('GET', '/api/v1/network/$id');
  Future<ZtResult> deleteNetwork(String id) => call('DELETE', '/api/v1/network/$id');
  Future<ZtResult> members(String id) => call('GET', '/api/v1/network/$id/member');
  Future<ZtResult> updateMember(String id, String mid, Map<String, dynamic> body) =>
      call('POST', '/api/v1/network/$id/member/$mid', body);
  Future<ZtResult> removeMember(String id, String mid) => call('DELETE', '/api/v1/network/$id/member/$mid');
}

String ztProp(dynamic o, String name) {
  if (o is Map && o[name] != null) return o[name].toString();
  return '';
}

String ztSeen(dynamic v) {
  if (v == null || v.toString().isEmpty) return '-';
  DateTime? dt;
  final s = v.toString();
  if (RegExp(r'^\d{11,}$').hasMatch(s)) {
    dt = DateTime.fromMillisecondsSinceEpoch(int.parse(s));
  } else {
    dt = DateTime.tryParse(s)?.toLocal();
  }
  if (dt == null) return s;
  final d = DateTime.now().difference(dt);
  if (d.inMinutes < 2) return 'gerade online';
  if (d.inMinutes < 60) return 'vor ${d.inMinutes} Min.';
  if (d.inHours < 48) return 'vor ${d.inHours} Std.';
  return '${dt.day.toString().padLeft(2, '0')}.${dt.month.toString().padLeft(2, '0')}.${dt.year}';
}
