import 'package:flutter/material.dart';

import '../core/voice_service.dart';
import '../main.dart';
import 'theme.dart';

class VoicePage extends StatefulWidget {
  const VoicePage({super.key});
  @override
  State<VoicePage> createState() => _VoicePageState();
}

class _VoicePageState extends State<VoicePage> {
  @override
  Widget build(BuildContext context) {
    final v = app.voice!;
    return ListenableBuilder(
      listenable: v,
      builder: (context, _) {
        final chans = v.channels;
        final inPrivate = v.myChannel.startsWith('@');
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Voice-Chat', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _audioPanel(v),
            Panel(
              child: Row(
                children: [
                  Icon(v.myChannel.isEmpty ? Icons.headset_off : Icons.headset_mic, color: v.myChannel.isEmpty ? kGrey : kGood),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      v.myChannel.isEmpty
                          ? 'In keinem Kanal'
                          : inPrivate
                              ? 'Privatgespräch  ·  ${v.members.length} verbunden'
                              : "Kanal '${v.myChannel}'${v.myLocked ? ' (Passwort)' : ''}  ·  ${v.members.length} verbunden",
                    ),
                  ),
                  if (v.myChannel.isNotEmpty)
                    ElevatedButton(style: dangerButton(), onPressed: v.leaveChannel, child: const Text('Verlassen')),
                ],
              ),
            ),
            Row(
              children: [
                const Expanded(child: SectionTitle('Kanäle')),
                ElevatedButton.icon(onPressed: () => _create(v), icon: const Icon(Icons.add), label: const Text('1. Kanal erstellen')),
              ],
            ),
            Panel(
              padding: EdgeInsets.zero,
              child: chans.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('Noch kein Kanal offen. Erstelle einen oder warte, bis jemand einen öffnet.', style: TextStyle(color: kGrey)),
                    )
                  : Material(
                      color: Colors.transparent,
                      child: Column(
                        children: [
                          for (final e in chans.entries)
                            ListTile(
                              leading: Icon(e.value.$2 ? Icons.lock : Icons.forum, color: e.key == v.myChannel ? kGood : kAccent),
                              title: Text(e.key),
                              subtitle: Text('${e.value.$1} Teilnehmer${e.value.$2 ? '  ·  Passwort' : ''}'),
                              trailing: e.key == v.myChannel
                                  ? const Text('drin', style: TextStyle(color: kGood))
                                  : TextButton(onPressed: () => _join(v, e.key, e.value.$2), child: const Text('Beitreten')),
                            ),
                        ],
                      ),
                    ),
            ),
            const SectionTitle('Teilnehmer im Netz'),
            Panel(
              padding: EdgeInsets.zero,
              child: v.peers.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('Niemand gefunden. Die Windows-Manager müssen Option 10 (Voice) geöffnet haben.', style: TextStyle(color: kGrey)),
                    )
                  : Material(
                      color: Colors.transparent,
                      child: Column(children: [for (final p in v.peers.values) _peerTile(v, p)]),
                    ),
            ),
            const SectionTitle('Meldungen'),
            Panel(
              child: Text(v.messages.isEmpty ? '-' : v.messages.reversed.take(12).join('\n'),
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: kGrey)),
            ),
          ],
        );
      },
    );
  }

  Widget _audioPanel(VoiceService v) {
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              ElevatedButton.icon(
                style: v.audioOn ? null : accentButton(),
                icon: Icon(v.audioOn ? Icons.stop : Icons.mic),
                label: Text(v.audioOn ? 'Audio aus' : 'Audio starten'),
                onPressed: () async {
                  if (v.audioOn) {
                    await v.stopAudio();
                  } else {
                    final err = await v.startAudio();
                    if (err != null && mounted) toast(context, err);
                  }
                },
              ),
              FilterChip(
                label: const Text('Mikro stumm'),
                selected: v.micMuted,
                onSelected: (b) => setState(() => v.micMuted = b),
              ),
              FilterChip(
                label: const Text('Ton aus'),
                selected: v.deafened,
                onSelected: (b) => setState(() => v.deafened = b),
              ),
              FilterChip(
                label: const Text('Push-to-Talk'),
                selected: v.pttMode,
                onSelected: (b) => setState(() => v.pttMode = b),
              ),
            ],
          ),
          if (v.lastError.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(v.lastError, style: const TextStyle(color: kBad))),
          const SizedBox(height: 8),
          if (v.pttMode)
            Listener(
              onPointerDown: (_) => setState(() => v.pttHeld = true),
              onPointerUp: (_) => setState(() => v.pttHeld = false),
              onPointerCancel: (_) => setState(() => v.pttHeld = false),
              child: Container(
                height: 56,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: v.pttHeld ? kGood.withValues(alpha: 0.35) : kButton,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(v.pttHeld ? 'Sprechen ...' : 'Gedrückt halten zum Sprechen', style: const TextStyle(fontSize: 16)),
              ),
            )
          else
            Row(
              children: [
                const Text('Empfindlichkeit'),
                Expanded(
                  child: Slider(
                    value: v.threshold.toDouble().clamp(50.0, 3000.0),
                    min: 50,
                    max: 3000,
                    onChanged: (x) => setState(() => v.threshold = x.round()),
                  ),
                ),
              ],
            ),
          Row(
            children: [
              Icon(Icons.graphic_eq, color: v.meTalking ? kGood : kGrey),
              const SizedBox(width: 8),
              Expanded(
                child: LinearProgressIndicator(
                  value: (v.micLevel / 3000).clamp(0.0, 1.0),
                  color: v.micLevel > v.threshold ? kGood : kGrey,
                  backgroundColor: kInput,
                ),
              ),
            ],
          ),
          Row(
            children: [
              const Text('Lautstärke'),
              Expanded(
                child: Slider(
                  value: v.volumePercent.toDouble(),
                  min: 0,
                  max: 200,
                  divisions: 20,
                  label: '${v.volumePercent} %',
                  onChanged: (x) => setState(() => v.volumePercent = x.round()),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _peerTile(VoiceService v, VoicePeer p) {
    final member = v.members.contains(p.id);
    final talking = member && v.isTalking(p);
    final lat = v.latencies[p.ip];
    final vol = v.peerVolume[p.ip] ?? 100;
    return ExpansionTile(
      leading: Icon(talking ? Icons.record_voice_over : Icons.person, color: talking ? kGood : (member ? kAccent : kGrey)),
      title: Text(p.name),
      subtitle: Text([
        p.ip,
        if (p.chan.isNotEmpty) (p.chan.startsWith('@') ? 'im Privatgespräch' : "Kanal '${p.chan}'"),
        if (member) 'verbunden',
        if (lat != null) '$lat ms',
      ].join('  ·  ')),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              const Text('Lautstärke'),
              Expanded(
                child: Slider(
                  value: vol.toDouble(),
                  min: 0,
                  max: 200,
                  divisions: 20,
                  label: '$vol %',
                  onChanged: (x) => setState(() => v.peerVolume[p.ip] = x.round()),
                ),
              ),
              TextButton(
                onPressed: () {
                  final err = v.call(p.id);
                  if (err != null) toast(context, err);
                },
                child: const Text('2. Privat sprechen'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _create(VoiceService v) async {
    final name = TextEditingController();
    final pw = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Kanal erstellen'),
        content: SizedBox(
          width: 380,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: name, decoration: deco('Name'), maxLength: 40, autofocus: true),
              TextField(controller: pw, decoration: deco('Passwort (optional)'), obscureText: true),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
          ElevatedButton(style: accentButton(), onPressed: () => Navigator.pop(ctx, true), child: const Text('Erstellen')),
        ],
      ),
    );
    if (ok != true) return;
    final err = v.createChannel(name.text, pw.text);
    if (!mounted) return;
    if (err != null) {
      toast(context, err);
    } else if (!v.audioOn) {
      final e2 = await v.startAudio();
      if (e2 != null && mounted) toast(context, e2);
    }
  }

  Future<void> _join(VoiceService v, String name, bool locked) async {
    var pw = '';
    if (locked) {
      final r = await askText(context, "Passwort für '$name'");
      if (r == null) return;
      pw = r;
    }
    final err = v.joinChannel(name, pw);
    if (!mounted) return;
    if (err != null) {
      toast(context, err);
    } else if (!v.audioOn) {
      final e2 = await v.startAudio();
      if (e2 != null && mounted) toast(context, e2);
    }
  }
}
