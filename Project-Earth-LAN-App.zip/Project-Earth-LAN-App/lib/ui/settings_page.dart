import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../core/settings.dart';
import '../core/util.dart';
import '../main.dart';
import 'theme.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final s = app.settings;
  late final TextEditingController _name = TextEditingController(text: s.name);
  late final TextEditingController _code = TextEditingController();
  late final TextEditingController _prefix = TextEditingController(text: s.prefix == 0 ? '' : '${s.prefix}');
  late final TextEditingController _dir = TextEditingController(text: s.downloadDir);
  late final TextEditingController _peers = TextEditingController(text: s.manualPeers.join(', '));
  late String _adapter = s.adapterIp;
  late int _streams = s.streams;
  late final TextEditingController _limit = TextEditingController(text: s.limitMb == 0 ? '' : '${s.limitMb}');

  @override
  Widget build(BuildContext context) {
    final ifs = app.net.interfaces;
    final adapterItems = <DropdownMenuItem<String>>[
      const DropdownMenuItem(value: '', child: Text('Automatisch (ZeroTier bevorzugt)')),
      for (final i in {for (final x in ifs) x.ip: x}.values) DropdownMenuItem(value: i.ip, child: Text('${i.name}  -  ${i.ip}${i.looksZeroTier ? '  (ZeroTier)' : ''}')),
    ];
    if (!adapterItems.any((e) => e.value == _adapter)) _adapter = '';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Einstellungen', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SectionTitle('Du'),
        TextField(controller: _name, decoration: deco('Anzeigename (max. 32 Zeichen)'), maxLength: 32),
        TextField(
          controller: _code,
          obscureText: true,
          decoration: deco(s.networkCode.isNotEmpty
              ? 'Netzwerk-Code ändern (gespeichert)'
              : (kBuildNetworkCode.isNotEmpty ? 'Netzwerk-Code (im Build enthalten)' : 'Netzwerk-Code')),
        ),
        const SectionTitle('Netzwerk'),
        DropdownButtonFormField<String>(
          initialValue: _adapter,
          isExpanded: true,
          decoration: deco('Netzwerkadapter'),
          items: adapterItems,
          onChanged: (v) => setState(() => _adapter = v ?? ''),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _prefix,
          keyboardType: TextInputType.number,
          decoration: deco('Subnetz-Präfix (leer = automatisch, aktuell /${app.net.prefix})', hint: 'z. B. 24'),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _peers,
          decoration: deco('Feste Mitspieler-IPs (optional, mit Komma)', hint: '10.147.17.20, 10.147.17.21'),
        ),
        const Padding(
          padding: EdgeInsets.only(top: 4),
          child: Text(
            'Hilft, wenn Broadcasts nicht ankommen (z. B. über das ZeroTier-VPN auf Android): '
            'der Live-Status wird dann zusätzlich direkt an diese IPs geschickt.',
            style: TextStyle(color: kGrey, fontSize: 12),
          ),
        ),
        const SectionTitle('Dateien'),
        Row(
          children: [
            Expanded(child: TextField(controller: _dir, decoration: deco('Download-Ordner'))),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: () async {
                final d = await FilePicker.platform.getDirectoryPath();
                if (d != null) setState(() => _dir.text = d);
              },
              child: const Text('Wählen'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            const Text('Parallele Verbindungen:'),
            Expanded(
              child: Slider(
                value: _streams.toDouble(),
                min: 1,
                max: 8,
                divisions: 7,
                label: '$_streams',
                onChanged: (v) => setState(() => _streams = v.round()),
              ),
            ),
            Text('$_streams'),
          ],
        ),
        TextField(controller: _limit, keyboardType: TextInputType.number, decoration: deco('Tempolimit beim Senden in MB/s (leer = aus)')),
        const SizedBox(height: 16),
        ElevatedButton(style: accentButton(), onPressed: _save, child: const Text('Speichern & Dienste neu starten')),
        const SectionTitle('Info'),
        Panel(
          child: Text(
            'Project Earth LAN Manager $kPelVersion für ${app.platformName}\n'
            'Eigene IP: ${app.net.ip.isEmpty ? '-' : '${app.net.ip}/${app.net.prefix}'}  ·  Broadcast: ${app.net.broadcast}\n'
            'Ports: 9928 Live-Status · 9874 Chat · 9876 Dateien · 9929 Postfach\n'
            'Daten: ${s.dataDir.path}',
            style: const TextStyle(color: kGrey),
          ),
        ),
      ],
    );
  }

  Future<void> _save() async {
    s.name = _name.text.trim().isEmpty ? s.name : displayName(_name.text);
    final code = _code.text.trim();
    if (code.isNotEmpty) {
      if (code.length < 8 || code.contains(RegExp(r'[\s"$`|]'))) {
        toast(context, 'Netzwerk-Code ungültig (mind. 8 Zeichen, keine Leerzeichen).');
        return;
      }
      s.networkCode = code;
    }
    s.adapterIp = _adapter;
    final p = int.tryParse(_prefix.text.trim()) ?? 0;
    s.prefix = (p >= 8 && p <= 30) ? p : 0;
    s.downloadDir = _dir.text.trim().isEmpty ? s.downloadDir : _dir.text.trim();
    s.streams = _streams;
    s.limitMb = (int.tryParse(_limit.text.trim()) ?? 0).clamp(0, 10000);
    s.manualPeers = _peers.text.split(RegExp(r'[,;\s]+')).map((e) => e.trim()).where(isValidIpv4).toList();
    await s.save();
    _code.clear();
    await app.restartServices();
    if (mounted) {
      toast(context, 'Gespeichert.');
      setState(() {});
    }
  }
}
