import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/netinfo.dart';
import '../core/settings.dart';
import '../core/status_service.dart';
import '../core/util.dart';
import '../main.dart';
import 'theme.dart';

class LivePage extends StatefulWidget {
  const LivePage({super.key});
  @override
  State<LivePage> createState() => _LivePageState();
}

class _LivePageState extends State<LivePage> {
  final TextEditingController _game = TextEditingController();
  int _shownNotices = 0;

  @override
  Widget build(BuildContext context) {
    final st = app.status!;
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[st, app]),
      builder: (context, _) {
        _showNotices(st);
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Live-Status', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _ownCard(st),
            const SectionTitle('Wer spielt gerade was'),
            _managers(st),
            Row(
              children: [
                const Expanded(child: SectionTitle('Spieleabende')),
                ElevatedButton.icon(onPressed: () => _newEvent(st), icon: const Icon(Icons.add), label: const Text('Planen')),
              ],
            ),
            _events(st),
            const SectionTitle('ZeroTier'),
            _zeroTier(),
          ],
        );
      },
    );
  }

  void _showNotices(StatusService st) {
    if (st.notices.length <= _shownNotices) return;
    final msgs = st.notices.sublist(_shownNotices);
    _shownNotices = st.notices.length;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      for (final m in msgs) {
        toast(context, m);
      }
    });
  }

  Widget _ownCard(StatusService st) {
    final n = app.net;
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.circle, size: 12, color: n.zeroTierLikely ? kGood : kWarn),
              const SizedBox(width: 8),
              Expanded(
                child: Text('${app.settings.name} (du)',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF87CEFA))),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            n.ip.isEmpty
                ? 'Keine Netzwerkverbindung gefunden.'
                : 'IP ${n.ip}/${n.prefix}  -  ${n.zeroTierLikely ? 'ZeroTier verbunden' : 'kein ZeroTier-Adapter erkannt (in den Einstellungen wählen)'}',
            style: const TextStyle(color: kGrey),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _game,
                  decoration: deco('Ich spiele gerade (optional)', hint: 'z. B. F.E.A.R. Combat'),
                  onSubmitted: (_) => _setGame(st),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: () => _setGame(st), child: const Text('Melden')),
            ],
          ),
          if (st.lastError.isNotEmpty) Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(st.lastError, style: const TextStyle(color: kBad)),
          ),
        ],
      ),
    );
  }

  void _setGame(StatusService st) {
    st.manualGame = _game.text.trim();
    st.refreshNow();
    toast(context, st.manualGame.isEmpty ? 'Du spielst nichts.' : 'Gemeldet: ${st.manualGame}');
  }

  Widget _managers(StatusService st) {
    final list = st.sortedManagers;
    if (list.isEmpty) {
      return const Panel(
        child: Text('Andere Manager im Netz: keine gefunden.\n'
            'Die Windows-Manager melden sich alle 8 Sekunden. Falls hier nach einer Minute niemand steht: '
            'ZeroTier verbunden? Gleicher Netzwerk-Code? Richtiger Adapter in den Einstellungen?',
            style: TextStyle(color: kGrey)),
      );
    }
    return Panel(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          for (final m in list)
            ListTile(
              dense: true,
              leading: Icon(m.game.isEmpty ? Icons.person : Icons.sports_esports, color: m.game.isEmpty ? kGrey : kGood),
              title: Text(m.name + (m.zt ? '' : '  (ohne ZT)'), style: TextStyle(color: m.game.isEmpty ? Colors.white : kGood)),
              subtitle: Text('${m.game.isEmpty ? '-' : m.game}   ·   ${m.address}'),
              trailing: IconButton(
                tooltip: 'Adresse kopieren',
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: m.address));
                  toast(context, 'Kopiert: ${m.address}');
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _events(StatusService st) {
    final list = st.sortedEvents;
    if (list.isEmpty) {
      return const Panel(child: Text('Kein Spieleabend geplant.', style: TextStyle(color: kGrey)));
    }
    return Panel(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          for (final e in list)
            ListTile(
              leading: Icon(e.cancelled ? Icons.event_busy : Icons.event, color: e.cancelled ? kBad : kAccent),
              title: Text(e.title + (e.cancelled ? '  (ABGESAGT)' : ''),
                  style: TextStyle(decoration: e.cancelled ? TextDecoration.lineThrough : null)),
              subtitle: Text([
                formatDateTime(e.startLocal),
                if (e.game.isNotEmpty) e.game,
                'von ${e.organizer}',
                if (e.note.isNotEmpty) e.note,
              ].join('  ·  ')),
              trailing: st.isOwn(e.id) && !e.cancelled
                  ? TextButton(
                      onPressed: () async {
                        if (await askYesNo(context, 'Absagen?', '"${e.title}" für alle absagen?')) st.cancelEvent(e.id);
                      },
                      child: const Text('Absagen'),
                    )
                  : null,
            ),
        ],
      ),
    );
  }

  Future<void> _newEvent(StatusService st) async {
    final title = TextEditingController();
    final game = TextEditingController();
    final note = TextEditingController();
    var date = DateTime.now().add(const Duration(days: 1));
    var time = const TimeOfDay(hour: 20, minute: 0);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Spieleabend planen'),
          content: SizedBox(
            width: 420,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: title, decoration: deco('Titel'), maxLength: 60),
                TextField(controller: game, decoration: deco('Spiel'), maxLength: 60),
                TextField(controller: note, decoration: deco('Hinweis'), maxLength: 160),
                Row(
                  children: [
                    Expanded(
                      child: TextButton.icon(
                        icon: const Icon(Icons.calendar_today),
                        label: Text('${two(date.day)}.${two(date.month)}.${date.year}'),
                        onPressed: () async {
                          final d = await showDatePicker(
                            context: ctx,
                            initialDate: date,
                            firstDate: DateTime.now(),
                            lastDate: DateTime.now().add(const Duration(days: 59)),
                          );
                          if (d != null) setD(() => date = d);
                        },
                      ),
                    ),
                    Expanded(
                      child: TextButton.icon(
                        icon: const Icon(Icons.schedule),
                        label: Text('${two(time.hour)}:${two(time.minute)}'),
                        onPressed: () async {
                          final t = await showTimePicker(context: ctx, initialTime: time);
                          if (t != null) setD(() => time = t);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
            ElevatedButton(style: accentButton(), onPressed: () => Navigator.pop(ctx, true), child: const Text('Ankündigen')),
          ],
        ),
      ),
    );
    if (ok != true || title.text.trim().isEmpty) return;
    final start = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    st.createEvent(title: title.text, game: game.text, note: note.text, start: start);
    if (mounted) toast(context, 'Spieleabend angekündigt - alle Manager im Netz bekommen ihn.');
  }

  Widget _zeroTier() {
    if (!ZeroTier.isDesktop) {
      return Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Auf Android läuft ZeroTier als eigene App (VPN). Dort dem Netzwerk beitreten:'),
            const SizedBox(height: 6),
            SelectableText(kPelNetworkId, style: const TextStyle(fontFamily: 'monospace', fontSize: 16)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Clipboard.setData(const ClipboardData(text: kPelNetworkId));
                    toast(context, 'Netzwerk-ID kopiert');
                  },
                  child: const Text('ID kopieren'),
                ),
                ElevatedButton(
                  onPressed: () => launchUrl(Uri.parse('https://play.google.com/store/apps/details?id=com.zerotier.one'),
                      mode: LaunchMode.externalApplication),
                  child: const Text('ZeroTier-App holen'),
                ),
              ],
            ),
          ],
        ),
      );
    }
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(app.ztText.isEmpty ? 'Status unbekannt.' : app.ztText,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: kGrey)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton(
                style: accentButton(),
                onPressed: () async {
                  final r = await ZeroTier.join(kPelNetworkId);
                  if (!mounted) return;
                  toast(context, r.isEmpty ? 'Beitritt angefragt.' : r);
                  await app.refreshZeroTier();
                },
                child: const Text('Project Earth LAN beitreten'),
              ),
              ElevatedButton(onPressed: () => app.refreshZeroTier(askAdmin: true), child: const Text('Aktualisieren')),
              ElevatedButton(
                onPressed: () => launchUrl(Uri.parse('https://www.zerotier.com/download/'), mode: LaunchMode.externalApplication),
                child: const Text('ZeroTier installieren'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
