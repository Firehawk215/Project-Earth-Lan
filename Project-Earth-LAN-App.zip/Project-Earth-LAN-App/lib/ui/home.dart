import 'package:flutter/material.dart';

import '../core/file_service.dart';
import '../core/util.dart';
import '../main.dart';
import 'chat_page.dart';
import 'files_page.dart';
import 'live_page.dart';
import 'mail_page.dart';
import 'settings_page.dart';
import 'theme.dart';
import 'voice_page.dart';
import 'ztnet_page.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  static const _labels = <String>['Live', 'Chat', 'Voice', 'Dateien', 'Postfach', 'Netzwerke', 'Einstellungen'];
  static const _icons = <IconData>[Icons.sports_esports, Icons.chat, Icons.headset_mic, Icons.folder_shared, Icons.mail, Icons.hub, Icons.settings];

  void _hookVoice() {
    final v = app.voice;
    if (v == null || v.onCall != null) return;
    v.onCall = (String peerId, String name) async {
      final ctx = navKey.currentContext;
      if (ctx == null) return;
      final yes = await askYesNo(ctx, 'Anruf', '$name möchte privat mit dir sprechen.', yes: 'Annehmen', no: 'Ablehnen');
      v.answerCall(peerId, yes);
      if (yes && !v.audioOn) await v.startAudio();
    };
  }

  void _hook() {
    _hookVoice();
    final fs = app.files;
    if (fs == null || fs.askAccept != null) return;
    fs.askAccept = (IncomingOffer o) async {
      final ctx = navKey.currentContext;
      if (ctx == null) return false;
      return askYesNo(
        ctx,
        'Dateien empfangen?',
        '${o.peerName} (${o.peerIp}) möchte dir ${o.fileCount} Datei(en) senden (${formatBytes(o.total)}).\n\nGespeichert wird in:\n${o.targetDir}\n\nAnnehmen?',
        yes: 'Annehmen',
        no: 'Ablehnen',
      );
    };
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        if (!app.settings.hasCode || !app.started) return const SetupPage();
        _hook();
        return ListenableBuilder(
          listenable: Listenable.merge(<Listenable?>[app.chat, app.mail]),
          builder: (context, _) => _shell(context),
        );
      },
    );
  }

  Widget _shell(BuildContext context) {
        final pages = <Widget>[
          const LivePage(),
          const ChatPage(),
          const VoicePage(),
          const FilesPage(),
          const MailPage(),
          const ZtnetPage(),
          const SettingsPage(),
        ];
        final wide = MediaQuery.of(context).size.width >= 760;
        app.chat?.visible = _index == 1;
        final body = SafeArea(
          child: KeyedSubtree(
            key: ValueKey<int>(app.generation),
            child: IndexedStack(index: _index, children: pages),
          ),
        );
        if (wide) {
          return Scaffold(
            body: Row(
              children: [
                NavigationRail(
                  backgroundColor: kPanel,
                  selectedIndex: _index,
                  labelType: NavigationRailLabelType.all,
                  onDestinationSelected: _select,
                  leading: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Icon(Icons.public, color: kAccent, size: 32),
                  ),
                  destinations: [
                    for (var i = 0; i < _labels.length; i++)
                      NavigationRailDestination(icon: _badgeIcon(i), label: Text(_labels[i])),
                  ],
                ),
                Expanded(child: body),
              ],
            ),
          );
        }
        return Scaffold(
          body: body,
          bottomNavigationBar: NavigationBar(
            backgroundColor: kPanel,
            selectedIndex: _index,
            onDestinationSelected: _select,
            labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
            destinations: [
              for (var i = 0; i < _labels.length; i++) NavigationDestination(icon: _badgeIcon(i), label: _labels[i]),
            ],
          ),
        );
  }

  void _select(int i) {
    setState(() => _index = i);
    if (i == 1) app.chat?.markRead();
  }

  Widget _badgeIcon(int i) {
    var n = 0;
    if (i == 1) n = app.chat?.unreadTotal ?? 0;
    if (i == 4) n = app.mail?.unread ?? 0;
    final icon = Icon(_icons[i]);
    if (n <= 0) return icon;
    return Badge(label: Text('$n'), child: icon);
  }
}

/// Erster Start: Name und Netzwerk-Code.
class SetupPage extends StatefulWidget {
  const SetupPage({super.key});
  @override
  State<SetupPage> createState() => _SetupPageState();
}

class _SetupPageState extends State<SetupPage> {
  late final TextEditingController _name = TextEditingController(text: app.settings.name);
  final TextEditingController _code = TextEditingController();
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final needCode = !app.settings.hasCode;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.all(20),
              shrinkWrap: true,
              children: [
                const Icon(Icons.public, color: kAccent, size: 64),
                const SizedBox(height: 8),
                const Text('Project Earth LAN Manager',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                Text('für ${app.platformName}', textAlign: TextAlign.center, style: const TextStyle(color: kGrey)),
                const SizedBox(height: 24),
                if (!needCode && !app.started) const Center(child: CircularProgressIndicator()),
                if (needCode) ...[
                  TextField(controller: _name, decoration: deco('Dein Anzeigename')),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _code,
                    decoration: deco('Netzwerk-Code', hint: 'derselbe Code wie in den Windows-Managern'),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Den Netzwerk-Code bekommst du vom Betreiber des Netzwerks. Ohne passenden Code sehen dich die Windows-Manager nicht.',
                    style: TextStyle(color: kGrey, fontSize: 13),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    style: accentButton(),
                    onPressed: _busy ? null : _go,
                    child: Text(_busy ? 'Starte ...' : 'Los geht\'s'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _go() async {
    final code = _code.text.trim();
    if (code.length < 8 || code.contains(RegExp(r'[\s"$`|]'))) {
      toast(context, 'Der Code muss mindestens 8 Zeichen lang sein (keine Leerzeichen).');
      return;
    }
    setState(() => _busy = true);
    app.settings.name = _name.text.trim().isEmpty ? app.settings.name : _name.text.trim();
    app.settings.networkCode = code;
    await app.settings.save();
    await app.startServices();
  }
}
