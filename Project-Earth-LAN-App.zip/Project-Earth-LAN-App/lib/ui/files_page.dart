import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../core/file_service.dart';
import '../core/util.dart';
import '../main.dart';
import 'theme.dart';

class FilesPage extends StatefulWidget {
  const FilesPage({super.key});
  @override
  State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  String? _target;

  @override
  Widget build(BuildContext context) {
    final fs = app.files!;
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[fs, app]),
      builder: (context, _) {
        final peers = app.allPeers;
        if (_target != null && !peers.containsKey(_target)) peers[_target!] = _target!;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Dateien senden & empfangen', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _target, // bewusst "value": wird auch per "IP eingeben" gesetzt
                          isExpanded: true,
                          decoration: deco('Empfänger'),
                          items: [
                            for (final e in peers.entries)
                              DropdownMenuItem(value: e.key, child: Text(e.value == e.key ? e.key : '${e.value}  (${e.key})')),
                          ],
                          onChanged: (v) => setState(() => _target = v),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(onPressed: _manualIp, child: const Text('IP eingeben')),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ElevatedButton.icon(
                        style: accentButton(),
                        icon: const Icon(Icons.upload_file),
                        label: const Text('1. Datei(en) senden'),
                        onPressed: _target == null ? null : () => _pickFiles(fs),
                      ),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.drive_folder_upload),
                        label: const Text('Ordner senden'),
                        onPressed: _target == null ? null : () => _pickFolder(fs),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text('Empfangene Dateien landen in:\n${app.settings.downloadDir}', style: const TextStyle(color: kGrey)),
                ],
              ),
            ),
            Row(
              children: [
                const Expanded(child: SectionTitle('Übertragungen')),
                TextButton(onPressed: fs.clearFinished, child: const Text('Erledigte entfernen')),
              ],
            ),
            if (fs.transfers.isEmpty) const Panel(child: Text('Noch keine Übertragungen.', style: TextStyle(color: kGrey))),
            for (final t in fs.transfers) _transfer(fs, t),
            const SectionTitle('Datei-Manager im Netz'),
            Panel(
              child: fs.peers.isEmpty
                  ? const Text('Keiner gefunden (Windows: Option 10 muss offen sein).', style: TextStyle(color: kGrey))
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [for (final p in fs.peers.values) Text('${p.name}  (${p.ip})')],
                    ),
            ),
            const SectionTitle('Protokoll'),
            Panel(
              child: Text(fs.log.isEmpty ? '-' : fs.log.reversed.take(30).join('\n'),
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: kGrey)),
            ),
          ],
        );
      },
    );
  }

  Widget _transfer(FileService fs, Transfer t) {
    final color = t.failed ? kBad : (t.finished ? kGood : Colors.white);
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(t.incoming ? Icons.download : Icons.upload, color: color),
              const SizedBox(width: 8),
              Expanded(
                child: Text('${t.title}  ${t.incoming ? 'von' : 'an'} ${t.peerName.isEmpty ? t.peerIp : '${t.peerName} (${t.peerIp})'}',
                    overflow: TextOverflow.ellipsis),
              ),
              if (!t.finished && !t.failed)
                TextButton(onPressed: () => fs.cancelTransfer(t), child: const Text('Abbrechen')),
              if (!t.incoming && t.failed && !t.cancel)
                TextButton(
                  onPressed: () => fs.sendPaths(t.peerIp, t.files.map((f) => f.localPath).toSet().toList(), peerName: t.peerName),
                  child: const Text('Erneut senden'),
                ),
            ],
          ),
          const SizedBox(height: 6),
          LinearProgressIndicator(value: t.progress, color: color, backgroundColor: kInput),
          const SizedBox(height: 4),
          Text('${t.status}   ${formatBytes(t.doneBytes)} / ${formatBytes(t.total)}', style: TextStyle(color: color, fontSize: 12)),
        ],
      ),
    );
  }

  Future<void> _manualIp() async {
    final ip = await askText(context, 'IP-Adresse des Empfängers', hint: 'z. B. 10.147.17.20');
    if (ip == null) return;
    final v = ip.trim();
    if (!isValidIpv4(v)) {
      if (mounted) toast(context, 'Keine gültige IPv4-Adresse.');
      return;
    }
    setState(() => _target = v);
    final ok = await app.files!.probe(v);
    if (mounted) toast(context, ok ? 'Datei-Manager unter $v gefunden.' : 'Unter $v antwortet (noch) kein Datei-Manager - Senden geht trotzdem, sobald er läuft.');
  }

  String _peerName(String ip) => app.allPeers[ip] ?? '';

  Future<void> _pickFiles(FileService fs) async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true, withData: false);
    if (r == null) return;
    final paths = r.files.map((f) => f.path).whereType<String>().toList();
    if (paths.isEmpty) return;
    await fs.sendPaths(_target!, paths, peerName: _peerName(_target!));
  }

  Future<void> _pickFolder(FileService fs) async {
    final dir = await FilePicker.platform.getDirectoryPath();
    if (dir == null) return;
    await fs.sendPaths(_target!, <String>[dir], peerName: _peerName(_target!));
  }
}
