import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/netinfo.dart';
import '../core/ztnet.dart';
import '../main.dart';
import 'theme.dart';

/// Option 13: eigene Netzwerke im ZTNET-Panel erstellen und verwalten.
class ZtnetPage extends StatefulWidget {
  const ZtnetPage({super.key});
  @override
  State<ZtnetPage> createState() => _ZtnetPageState();
}

class _ZtnetPageState extends State<ZtnetPage> {
  late final TextEditingController _url = TextEditingController(text: app.settings.ztnetUrl);
  final TextEditingController _token = TextEditingController();
  List<dynamic> _nets = <dynamic>[];
  String _msg = '';
  bool _busy = false;
  bool _loggedIn = false;

  ZtnetClient get _client => ZtnetClient(app.settings.ztnetUrl, app.settings.ztnetToken);

  @override
  void initState() {
    super.initState();
    if (app.settings.ztnetToken.isNotEmpty) unawaited(_load());
  }

  Future<void> _load() async {
    setState(() => _busy = true);
    final r = await _client.networks();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _loggedIn = r.ok;
      _msg = r.ok ? '' : r.error;
      _nets = r.ok && r.data is List ? (r.data as List<dynamic>).where((n) => ztProp(n, 'deleted') != 'true').toList() : <dynamic>[];
    });
  }

  Future<void> _login() async {
    app.settings.ztnetUrl = _url.text.trim().isEmpty ? app.settings.ztnetUrl : _url.text.trim();
    final t = _token.text.trim();
    if (t.isNotEmpty) app.settings.ztnetToken = t;
    if (app.settings.ztnetToken.isEmpty) {
      setState(() => _msg = 'Bitte zuerst den API-Token eintragen.');
      return;
    }
    await _load();
    if (_loggedIn || _msg.startsWith('Panel nicht erreichbar')) {
      await app.settings.save();
      _token.clear();
    }
  }

  Future<void> _logout() async {
    app.settings.ztnetToken = '';
    await app.settings.save();
    setState(() {
      _loggedIn = false;
      _nets = <dynamic>[];
      _msg = 'Token gelöscht.';
    });
  }

  void _open(String path) {
    final base = app.settings.ztnetUrl.endsWith('/') ? app.settings.ztnetUrl.substring(0, app.settings.ztnetUrl.length - 1) : app.settings.ztnetUrl;
    launchUrl(Uri.parse('$base$path'), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final saved = app.settings.ztnetToken;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Eigene Netzwerke (ZTNET)', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(controller: _url, decoration: deco('Panel-Adresse')),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () => _open('/auth/register'),
                child: const Text('1. Account erstellen (im Browser)'),
              ),
              const SizedBox(height: 14),
              const Text(
                'Für Button 2 brauchst du deinen eigenen API-Token aus der Weboberfläche: '
                'nach der Account-Erstellung unter Benutzereinstellungen → Account → API-Token.',
                style: TextStyle(color: kGrey),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _token,
                obscureText: true,
                decoration: deco(saved.isEmpty
                    ? 'API-Token'
                    : 'Gespeichert (....${saved.length > 4 ? saved.substring(saved.length - 4) : saved}) - wird automatisch verwendet'),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ElevatedButton(style: accentButton(), onPressed: _busy ? null : _login, child: const Text('Login')),
                  ElevatedButton(onPressed: saved.isEmpty ? null : _logout, child: const Text('Token löschen')),
                  ElevatedButton(onPressed: () => _open('/user-settings/?tab=account'), child: const Text('Token-Seite öffnen')),
                ],
              ),
              if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_msg, style: const TextStyle(color: kBad))),
            ],
          ),
        ),
        Row(
          children: [
            const Expanded(child: SectionTitle('2. Eigene Netzwerke erstellen & verwalten')),
            if (_busy) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
            IconButton(onPressed: _loggedIn ? _load : null, icon: const Icon(Icons.refresh)),
            ElevatedButton.icon(
              onPressed: _loggedIn ? _create : null,
              icon: const Icon(Icons.add),
              label: const Text('Netzwerk erstellen'),
            ),
          ],
        ),
        if (!_loggedIn)
          const Panel(child: Text('Erst mit deinem API-Token einloggen.', style: TextStyle(color: kGrey)))
        else if (_nets.isEmpty)
          const Panel(child: Text('Noch keine eigenen Netzwerke.', style: TextStyle(color: kGrey)))
        else
          Panel(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                for (final n in _nets)
                  ListTile(
                    leading: const Icon(Icons.hub, color: kAccent),
                    title: Text(ztProp(n, 'name').isEmpty ? '(ohne Namen)' : ztProp(n, 'name')),
                    subtitle: Text('${_nid(n)}${ztProp(n, 'memberCount').isEmpty ? '' : '  ·  ${ztProp(n, 'memberCount')} Mitglieder'}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await Navigator.of(context).push(MaterialPageRoute<void>(
                        builder: (_) => ZtNetworkPage(client: _client, id: _nid(n), name: ztProp(n, 'name'), onOpen: _open),
                      ));
                      unawaited(_load());
                    },
                  ),
              ],
            ),
          ),
      ],
    );
  }

  static String _nid(dynamic n) => ztProp(n, 'nwid').isNotEmpty ? ztProp(n, 'nwid') : ztProp(n, 'id');

  Future<void> _create() async {
    final name = await askText(context, 'Neues Netzwerk', hint: 'Name des Netzwerks');
    if (name == null || name.trim().isEmpty) return;
    setState(() => _busy = true);
    final r = await _client.createNetwork(name.trim());
    if (!mounted) return;
    setState(() => _busy = false);
    toast(context, r.ok ? 'Netzwerk "$name" erstellt.' : r.error);
    await _load();
  }
}

/// Verwaltung eines Netzwerks mit Mitgliederliste.
class ZtNetworkPage extends StatefulWidget {
  const ZtNetworkPage({super.key, required this.client, required this.id, required this.name, required this.onOpen});
  final ZtnetClient client;
  final String id;
  final String name;
  final void Function(String path) onOpen;
  @override
  State<ZtNetworkPage> createState() => _ZtNetworkPageState();
}

class _ZtNetworkPageState extends State<ZtNetworkPage> {
  List<dynamic> _members = <dynamic>[];
  String _msg = '';
  bool _busy = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (_busy) return;
    setState(() => _busy = true);
    final r = await widget.client.members(widget.id);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _msg = r.ok ? '' : r.error;
      if (r.ok) {
        final d = r.data;
        final list = d is List ? d : (d is Map && d['members'] is List ? d['members'] as List<dynamic> : <dynamic>[]);
        _members = list.where((m) => ztProp(m, 'deleted') != 'true').toList();
      }
    });
  }

  Future<void> _update(dynamic m, Map<String, dynamic> body, String ok) async {
    final r = await widget.client.updateMember(widget.id, ztProp(m, 'id'), body);
    if (!mounted) return;
    toast(context, r.ok ? ok : r.error);
    await _load();
  }

  Future<void> _removeNetwork() async {
    if (!await askYesNo(context, 'Netzwerk entfernen?', 'Netzwerk "${widget.name}" (${widget.id}) wirklich entfernen?')) return;
    final r = await widget.client.deleteNetwork(widget.id);
    if (!mounted) return;
    if (r.ok) {
      toast(context, 'Netzwerk entfernt.');
      Navigator.of(context).pop();
      return;
    }
    if (r.status == 404 || r.status == 405) {
      toast(context, 'Das Panel erlaubt das Löschen nicht über die API - die Netzwerk-Seite im Browser wird geöffnet.');
      widget.onOpen('/network/${widget.id}');
    } else {
      toast(context, r.error);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.name.isEmpty ? widget.id : widget.name), backgroundColor: kBack),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SelectableText('Netzwerk-ID: ${widget.id}', style: const TextStyle(fontFamily: 'monospace', fontSize: 16)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: widget.id));
                        toast(context, 'ID kopiert');
                      },
                      child: const Text('ID kopieren'),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        final r = await ZeroTier.join(widget.id);
                        if (mounted) toast(context, r.isEmpty ? 'Beitritt angefragt.' : r);
                      },
                      child: const Text('Mit diesem Gerät beitreten'),
                    ),
                    ElevatedButton(onPressed: () => widget.onOpen('/network/${widget.id}'), child: const Text('Einstellungen im Webpanel')),
                    ElevatedButton(onPressed: _load, child: const Text('Aktualisieren')),
                    ElevatedButton(style: dangerButton(), onPressed: _removeNetwork, child: const Text('Netzwerk entfernen')),
                  ],
                ),
              ],
            ),
          ),
          if (_msg.isNotEmpty) Text(_msg, style: const TextStyle(color: kBad)),
          SectionTitle('Mitglieder (${_members.length})'),
          if (_members.isEmpty) const Panel(child: Text('Noch keine Mitglieder.', style: TextStyle(color: kGrey))),
          for (final m in _members) _member(m),
        ],
      ),
    );
  }

  Widget _member(dynamic m) {
    final auth = ztProp(m, 'authorized') == 'true';
    final ips = (m is Map && m['ipAssignments'] is List) ? (m['ipAssignments'] as List<dynamic>).join(', ') : '';
    final name = ztProp(m, 'name');
    final desc = ztProp(m, 'description');
    final seen = ztSeen(m is Map ? (m['lastSeen'] ?? m['lastOnline']) : null);
    return Panel(
      padding: EdgeInsets.zero,
      child: ListTile(
        leading: Icon(auth ? Icons.verified_user : Icons.gpp_maybe, color: auth ? kGood : kWarn),
        title: Text(name.isEmpty ? ztProp(m, 'id') : '$name  (${ztProp(m, 'id')})'),
        subtitle: Text([
          auth ? 'freigeschaltet' : 'wartet auf Freischaltung',
          if (ips.isNotEmpty) ips,
          seen,
          if (desc.isNotEmpty) desc,
        ].join('  ·  ')),
        trailing: PopupMenuButton<String>(
          onSelected: (a) async {
            switch (a) {
              case 'auth':
                await _update(m, <String, dynamic>{'authorized': !auth}, auth ? 'Gesperrt.' : 'Freigeschaltet.');
                break;
              case 'name':
                final newName = await askText(context, 'Name', initial: name);
                if (newName != null) await _update(m, <String, dynamic>{'name': newName.trim()}, 'Umbenannt.');
                break;
              case 'desc':
                final newDesc = await askText(context, 'Beschreibung', initial: desc);
                if (newDesc != null) await _update(m, <String, dynamic>{'description': newDesc.trim()}, 'Gespeichert.');
                break;
              case 'del':
                if (!mounted) return;
                if (await askYesNo(context, 'Entfernen?', 'Mitglied ${ztProp(m, 'id')} aus dem Netzwerk entfernen?')) {
                  final res = await widget.client.removeMember(widget.id, ztProp(m, 'id'));
                  if (!mounted) return;
                  toast(context, res.ok ? 'Entfernt.' : res.error);
                  await _load();
                }
                break;
            }
          },
          itemBuilder: (_) => <PopupMenuEntry<String>>[
            PopupMenuItem(value: 'auth', child: Text(auth ? 'Sperren' : 'Freischalten')),
            const PopupMenuItem(value: 'name', child: Text('Umbenennen')),
            const PopupMenuItem(value: 'desc', child: Text('Beschreibung')),
            const PopupMenuItem(value: 'del', child: Text('Aus Netzwerk entfernen')),
          ],
        ),
      ),
    );
  }
}
