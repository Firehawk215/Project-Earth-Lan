// Dunkles Design wie der Windows-Manager (Hintergrund 25/25/25, weisse Schrift,
// Akzent Windows-Blau).
import 'package:flutter/material.dart';

const Color kBack = Color(0xFF191919);
const Color kPanel = Color(0xFF232323);
const Color kButton = Color(0xFF2D2D2D);
const Color kInput = Color(0xFF1E1E1E);
const Color kAccent = Color(0xFF0078D7);
const Color kGood = Color(0xFF90EE90);
const Color kWarn = Color(0xFFFFC85A);
const Color kBad = Color(0xFFFF6B4A);
const Color kGrey = Color(0xFFAAAAAA);
const Color kPrivate = Color(0xFFD7A6FF);

ThemeData pelTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: kAccent, brightness: Brightness.dark).copyWith(
    primary: kAccent,
    onPrimary: Colors.white,
    surface: kPanel,
    onSurface: Colors.white,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: kBack,
    canvasColor: kBack,
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: kButton,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    ),
  );
}

/// Einheitliches Eingabefeld-Aussehen.
InputDecoration deco(String label, {String? hint}) => InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: kInput,
      border: const OutlineInputBorder(),
      isDense: true,
    );

class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(12)});
  final Widget child;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: padding,
        decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(6)),
        child: child,
      );
}

ButtonStyle accentButton() => ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.white);
ButtonStyle dangerButton() => ElevatedButton.styleFrom(backgroundColor: const Color(0xFFAA2323), foregroundColor: Colors.white);

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 6),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      );
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}

Future<String?> askText(BuildContext context, String title, {String initial = '', String hint = '', bool multiline = false}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: c,
        autofocus: true,
        maxLines: multiline ? 5 : 1,
        decoration: InputDecoration(hintText: hint),
        onSubmitted: multiline ? null : (v) => Navigator.pop(ctx, v),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Abbrechen')),
        ElevatedButton(style: accentButton(), onPressed: () => Navigator.pop(ctx, c.text), child: const Text('OK')),
      ],
    ),
  );
}

Future<bool> askYesNo(BuildContext context, String title, String text, {String yes = 'Ja', String no = 'Nein'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(text),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(no)),
        ElevatedButton(style: accentButton(), onPressed: () => Navigator.pop(ctx, true), child: Text(yes)),
      ],
    ),
  );
  return r ?? false;
}
