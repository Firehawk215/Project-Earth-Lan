import 'package:flutter/material.dart';

import '../core/mail_service.dart';
import '../core/util.dart';
import '../main.dart';
import 'theme.dart';

class MailPage extends StatefulWidget {
  const MailPage({super.key});
  @override
  State<MailPage> createState() => _MailPageState();
}

class _MailPageState extends State<MailPage> {
  String _folder = 'Eingang';
  static const _folders = <String>['Eingang', 'Ausgang', 'Gesendet'];

  @override
  Widget build(BuildContext context) {
    final mail = app.mail!;
    return ListenableBuilder(
      listenable: mail,
      builder: (context, _) {
        final msgs = mail.list(_folder);
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Expanded(child: Text('Postfach', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
                  ElevatedButton.icon(
                    style: accentButton(),
                    icon: const Icon(Icons.edit),
                    label: const Text('Neue Nachricht'),
                    onPressed: mail.keyReady ? () => _compose(mail) : null,
                  ),
                ],
              ),
              if (mail.status.isNotEmpty)
                Padding(padding: const EdgeInsets.only(top: 6), child: Text(mail.status, style: const TextStyle(color: kWarn))),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: [
                  for (final f in _folders)
                    ButtonSegment<String>(
                      value: f,
                      label: Text(f == 'Eingang' && mail.unread > 0 ? 'Eingang (${mail.unread})' : f),
                    ),
                ],
                selected: <String>{_folder},
                onSelectionChanged: (s) => setState(() => _folder = s.first),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: msgs.isEmpty
                    ? const Center(child: Text('Keine Nachrichten.', style: TextStyle(color: kGrey)))
                    : ListView.builder(
                        itemCount: msgs.length,
                        itemBuilder: (_, i) => _tile(mail, msgs[i]),
                      ),
              ),
              Text('Online für das Postfach: ${mail.onlinePeers.length}  ·  Nachrichten an Offline-Spieler werden '
                  'verschlüsselt über andere Manager weitergeleitet (bis 14 Tage).',
                  style: const TextStyle(color: kGrey, fontSize: 12)),
            ],
          ),
        );
      },
    );
  }

  Widget _tile(MailService mail, MailMsg m) {
    final inbox = m.folder == 'Eingang';
    final who = inbox ? '${m.fromName} (${m.fromIp})' : 'an ${m.toName.isEmpty ? m.toIp : '${m.toName} (${m.toIp})'}';
    var info = formatDateTime(m.created);
    if (inbox && !m.verified) info += '  (unbestätigt)';
    if (m.folder == 'Ausgang') {
      info += m.lastError.isEmpty ? '  · wird zugestellt ...' : '  · ${m.lastError} (Versuch ${m.attempts})';
      if (m.relayed) info += '  · weitergeleitet über ${m.relayedTo}';
    }
    return Panel(
      padding: EdgeInsets.zero,
      child: ListTile(
        leading: Icon(inbox ? (m.read ? Icons.drafts : Icons.mail) : Icons.outgoing_mail, color: inbox && !m.read ? kAccent : kGrey),
        title: Text(m.subject.isEmpty ? '(kein Betreff)' : m.subject,
            style: TextStyle(fontWeight: inbox && !m.read ? FontWeight.bold : FontWeight.normal)),
        subtitle: Text('$who\n$info'),
        isThreeLine: true,
        onTap: () => _open(mail, m),
      ),
    );
  }

  Future<void> _open(MailService mail, MailMsg m) async {
    if (m.folder == 'Eingang' && !m.read) mail.markRead(m, true);
    final action = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(m.subject.isEmpty ? '(kein Betreff)' : m.subject),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(m.folder == 'Eingang' ? 'Von: ${m.fromName} (${m.fromIp})' : 'An: ${m.toName} (${m.toIp})',
                    style: const TextStyle(color: kGrey)),
                Text('${formatDateTime(m.created)}${m.via.isNotEmpty ? '  ·  ${m.via}' : ''}', style: const TextStyle(color: kGrey)),
                const Divider(),
                SelectableText(m.body),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'del'), child: Text(m.folder == 'Ausgang' ? 'Senden abbrechen' : 'Löschen')),
          if (m.folder == 'Eingang') TextButton(onPressed: () => Navigator.pop(ctx, 'unread'), child: const Text('Ungelesen')),
          if (m.folder == 'Eingang')
            ElevatedButton(style: accentButton(), onPressed: () => Navigator.pop(ctx, 'reply'), child: const Text('Antworten')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Schließen')),
        ],
      ),
    );
    if (action == 'del') mail.deleteMsg(m);
    if (action == 'unread') mail.markRead(m, false);
    if (action == 'reply') {
      final subj = RegExp(r'^(AW|Re):', caseSensitive: false).hasMatch(m.subject) ? m.subject : 'AW: ${m.subject}';
      final quoted = m.body.split('\n').map((l) => '> $l').join('\n');
      final body = '\n\n--- ${m.fromName} schrieb am ${formatDateTime(m.created)}: ---\n$quoted';
      await _compose(mail, toIp: m.fromIp, toName: m.fromName, subject: subj, body: body);
    }
  }

  Future<void> _compose(MailService mail, {String toIp = '', String toName = '', String subject = '', String body = ''}) async {
    final peers = app.allPeers;
    final to = TextEditingController(text: toIp);
    final subj = TextEditingController(text: subject.length > kMaxSubject ? subject.substring(0, kMaxSubject) : subject);
    final text = TextEditingController(text: body.length > kMaxBody ? body.substring(0, kMaxBody) : body);
    var name = toName;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Neue Nachricht'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(child: TextField(controller: to, decoration: deco('An (IP-Adresse)'))),
                      PopupMenuButton<String>(
                        tooltip: 'Mitspieler wählen',
                        icon: const Icon(Icons.people),
                        onSelected: (ip) => setD(() {
                          to.text = ip;
                          name = peers[ip] ?? '';
                        }),
                        itemBuilder: (_) => <PopupMenuEntry<String>>[
                          for (final e in peers.entries) PopupMenuItem(value: e.key, child: Text('${e.value}  (${e.key})')),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  TextField(controller: subj, decoration: deco('Betreff'), maxLength: kMaxSubject),
                  TextField(controller: text, decoration: deco('Nachricht'), maxLines: 8, maxLength: kMaxBody),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Abbrechen')),
            ElevatedButton(style: accentButton(), onPressed: () => Navigator.pop(ctx, true), child: const Text('Senden')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final ip = RegExp(r'\d{1,3}(\.\d{1,3}){3}').firstMatch(to.text)?.group(0) ?? '';
    if (name.isEmpty) name = peers[ip] ?? '';
    final err = mail.send(toIp: ip, toName: name, subject: subj.text, body: text.text);
    if (!mounted) return;
    toast(context, err ?? 'Nachricht liegt im Ausgang und wird zugestellt.');
  }
}
