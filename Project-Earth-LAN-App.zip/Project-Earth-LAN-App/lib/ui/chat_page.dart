import 'package:flutter/material.dart';

import '../core/chat_service.dart';
import '../core/util.dart';
import '../main.dart';
import 'theme.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();
  String? _selected; // Peer-Id fuer Privatnachricht
  int _lastCount = 0;

  @override
  Widget build(BuildContext context) {
    final chat = app.chat!;
    return ListenableBuilder(
      listenable: chat,
      builder: (context, _) {
        if (_selected != null && !chat.peers.containsKey(_selected)) _selected = null;
        if (chat.lines.length != _lastCount) {
          _lastCount = chat.lines.length;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
          });
        }
        final wide = MediaQuery.of(context).size.width >= 900;
        final messages = _messages(chat);
        final peers = _peers(chat);
        return Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Row(
                children: [
                  const Expanded(child: Text('Text-Chat', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
                  Text('${chat.peers.length} verbunden', style: const TextStyle(color: kGrey)),
                  const SizedBox(width: 8),
                  PopupMenuButton<String>(
                    tooltip: 'Kanal',
                    icon: const Icon(Icons.forum),
                    onSelected: (v) => _channel(chat, v),
                    itemBuilder: (_) => <PopupMenuEntry<String>>[
                      const PopupMenuItem(value: '', child: Text('Alle (Gruppenchat)')),
                      for (final c in chat.channels) PopupMenuItem(value: c, child: Text('Kanal: $c')),
                      const PopupMenuItem(value: '+', child: Text('Kanal erstellen / betreten ...')),
                    ],
                  ),
                  IconButton(tooltip: 'Netz nach Teilnehmern absuchen', icon: const Icon(Icons.radar), onPressed: chat.scan),
                ],
              ),
              if (chat.channel.isNotEmpty)
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text("Kanal: '${chat.channel}'", style: const TextStyle(color: kAccent)),
                ),
              const SizedBox(height: 6),
              Expanded(
                child: wide
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [Expanded(child: messages), const SizedBox(width: 8), SizedBox(width: 240, child: peers)],
                      )
                    : Column(children: [SizedBox(height: 110, child: peers), const SizedBox(height: 6), Expanded(child: messages)]),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _input,
                      maxLength: 2000,
                      decoration: deco(_selected == null
                              ? (chat.channel.isEmpty ? 'Nachricht an alle' : "Nachricht an Kanal '${chat.channel}'")
                              : 'Privat an ${chat.peers[_selected]?.name ?? ''}')
                          .copyWith(counterText: ''),
                      onSubmitted: (_) => _send(chat),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(style: accentButton(), onPressed: () => _send(chat), child: const Text('Senden')),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _messages(ChatService chat) {
    return Container(
      decoration: BoxDecoration(color: kInput, borderRadius: BorderRadius.circular(6)),
      child: ListView.builder(
        controller: _scroll,
        padding: const EdgeInsets.all(8),
        itemCount: chat.lines.length,
        itemBuilder: (_, i) {
          final l = chat.lines[i];
          final color = switch (l.kind) {
            ChatKind.system => kGrey,
            ChatKind.private => kPrivate,
            ChatKind.own => const Color(0xFF87CEFA),
            ChatKind.group => Colors.white,
          };
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: SelectableText('[${formatTime(l.time)}] ${l.text}', style: TextStyle(color: color)),
          );
        },
      ),
    );
  }

  Widget _peers(ChatService chat) {
    final list = chat.peers.values.toList()..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return Container(
      decoration: BoxDecoration(color: kPanel, borderRadius: BorderRadius.circular(6)),
      child: Material(
        color: Colors.transparent,
        child: list.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(10),
              child: Text('Noch niemand verbunden. Die Windows-Manager müssen Option 10 geöffnet haben.',
                  style: TextStyle(color: kGrey)),
            )
          : ListView(
              children: [
                for (final p in list)
                  ListTile(
                    dense: true,
                    selected: _selected == p.id,
                    selectedTileColor: kAccent.withValues(alpha: 0.25),
                    leading: Icon(Icons.person, color: p.unread ? kPrivate : kGood),
                    title: Text(p.name),
                    subtitle: Text(p.unread ? 'neue Nachricht' : (p.chan.isEmpty ? p.ip : '${p.ip} · ${p.chan}')),
                    onTap: () => setState(() {
                      _selected = _selected == p.id ? null : p.id;
                      p.unread = false;
                    }),
                  ),
              ],
            ),
      ),
    );
  }

  void _send(ChatService chat) {
    final t = _input.text.trim();
    if (t.isEmpty) return;
    chat.send(t, peerId: _selected);
    _input.clear();
  }

  Future<void> _channel(ChatService chat, String v) async {
    if (v == '+') {
      final n = await askText(context, 'Kanal', hint: 'Name des Kanals');
      if (n == null || n.trim().isEmpty) return;
      chat.setChannel(n.trim());
    } else {
      chat.setChannel(v);
    }
  }
}
