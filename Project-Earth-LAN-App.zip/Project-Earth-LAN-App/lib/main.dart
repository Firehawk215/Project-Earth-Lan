import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/app_state.dart';
import 'ui/home.dart';
import 'ui/theme.dart';

final AppState app = AppState();
final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isAndroid) {
    // Ohne MulticastLock nimmt Android keine Broadcasts (Live-Status, Beacons) an.
    try {
      await const MethodChannel('projectearthlan/net').invokeMethod<void>('multicastLock');
    } catch (_) {}
  }
  try {
    await app.init();
  } catch (e) {
    debugPrint('Start: $e');
  }
  runApp(const PelApp());
}

class PelApp extends StatelessWidget {
  const PelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Project Earth LAN Manager',
      debugShowCheckedModeBanner: false,
      navigatorKey: navKey,
      theme: pelTheme(),
      home: const HomeShell(),
    );
  }
}
