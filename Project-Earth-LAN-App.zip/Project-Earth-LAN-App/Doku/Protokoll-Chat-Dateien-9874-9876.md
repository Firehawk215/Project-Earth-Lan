# Project Earth LAN Manager – Option 10 "Kommunikationszentrale": wire-protocol spec

Source analysed: `/home/claude/cur.ps1` (16 834 lines). All line numbers refer to that file.
Everything below was read from the code and, where marked **[captured]**, confirmed by running
the original embedded C# (extracted verbatim, compiled with `Add-Type` under PowerShell 7 on
Linux) against Python socket peers on 127.0.0.x. Captures are reproduced byte-exactly in
section 8.

Scope: Text chat (TCP/UDP 9874), file transfer (TCP/UDP 9876), channel-sync/"social" service
(TCP/UDP 9776), peer discovery, display name, ban list, friend list. Voice (UDP 9873) and
Option 9 (TCP/UDP 9872) are covered briefly in appendices A and B.

---------------------------------------------------------------------------------------------

## 0. Things to know first

1. **No authentication, no signing, no encryption.** None of the Option 10 protocols (9874,
   9876, 9776, 9873) use `$script:PelNetworkSecret` or any HMAC, TLS or encryption. The
   network secret (L41-76, `Get-PelHmacBase64`) is used only by other subsystems (status,
   planner, mailbox broadcasts on 9928/9929 etc., L1656-1660, L3094-3183, L16443).
   You don't need the test secret `TestCode12345678` for these protocols. It appears below
   only as a password input for the channel-password KDF vectors.
2. **All protocols are text, UTF-8, `|`-separated.** TCP protocols are line-based: the
   terminator is a single LF (`0x0A`). The 9776 snapshot uses TAB (`0x09`) inside lines.
   Windows peers never send CR. UTF-8 is written **without a BOM** (`new UTF8Encoding(false)`
   or `Encoding.UTF8.GetBytes`, which produces no preamble).
3. **Identity:** each service instance creates its own random `NodeId` =
   `Guid.NewGuid().ToString("N").Substring(0,12)`: 12 lowercase hex chars, new on every
   start (chat L11114, file L9972, social L14092, voice L9025). A NodeId isn't stable
   across restarts, and the chat, file, social and voice services of the same PC have
   **different** NodeIds. The only stable key is the **IP address**. Friends, bans and
   volumes are all keyed by IP.
4. **Name sanitising (`CleanName`)** differs per service. Each version replaces `\r` and `\n`
   with a space and `|` with `/`, then does `Trim()`, then truncates to a maximum of **N UTF-16 code
   units** (not bytes, not grapheme clusters). N = chat 32 (L11117-11123), file 60
   (L9975-9981), voice 40 (L9028-9034), social 40 (L14098-14104).
   Renaming in the UI (L12840-12851) calls `ChatNode.SetName(n)`, which applies CleanName(32).
   It sets `FileNode.NodeName` and `VoiceNode.NodeName` to `$clean` = `$n -replace '[|\r\n]','/'`,
   truncated to 32 chars with no trim. Note that CR/LF become `/` here, not a space.
   The social node's name is **not** updated until the service restarts.
5. **Bind addresses:** TCP listeners bind to the **selected adapter IPv4** (`$st.Adapter.Ip`).
   UDP beacon receivers bind to `0.0.0.0:<port>` with `SO_REUSEADDR`. Beacon senders use a
   separate UDP socket bound to `<adapterIp>:0`. Every UDP socket that receives gets
   `IOControl(SIO_UDP_CONNRESET = 0x9800000C (-1744830452), {0,0,0,0})` so ICMP
   port-unreachable does not break `Receive` (Windows-only; ignore on other OSes).
6. **Windows Firewall:** inbound rules are created with `-RemoteAddress LocalSubnet`
   (L11933-11964). A Windows peer therefore only accepts inbound TCP/UDP on 9874/9876/9776/9873
   from hosts **in the same IP subnet as one of its interfaces**. In practice that's the same
   ZeroTier network. The rules are removed again when the window closes (L13308-13311).
7. **Integers** are always decimal ASCII (`long.ToString()`, invariant digits, no
   separators, no leading `+`). Parsing uses `int.TryParse` / `long.TryParse` (current
   culture, but digits only in practice).

---------------------------------------------------------------------------------------------

## 1. Adapter selection, display name, config files

### 1.1 Which adapter/IP is used (L325-417, L13362-13377, L13271-13283)
* The central choice is stored in `C:\Project-Earth-Lan\selected_adapter.json` (L332). It's written by
  `Save-PelSelectedAdapter` (L410-417) as PS 5.1 `ConvertTo-Json` of `{Name, Description, Ip, Mask}`,
  UTF-8 with BOM.
* `Get-PelSelectedAdapter` (L398-408) uses that entry only if an adapter with the same IP is
  currently up. If there isn't one, `Get-PelAutoAdapter` (L368-372) picks the adapter with the
  lowest IPv4 interface metric. Candidates are up, non-loopback, non-tunnel adapters with an IPv4
  address that isn't `169.254.*` (L334-362). If `IPv4Mask` is null, the mask defaults to
  `255.255.255.0` (L344-345).
* Chat, file and social services all use `$st.Adapter.Ip` as BindIp and `$st.Adapter.Mask` as Mask.
* Every 20 timer ticks (20 × 250 ms = 5 s), the window re-reads the central choice. If the IP
  changed, it restarts chat and file (`Start-CcAllNodes`, L13275-13283, L12834-12838). Note:
  `Start-CcSocial` returns early if a social node already exists (L12327), so the social node
  keeps its old IP. This is a bug; don't copy it.

### 1.2 Display name (`%APPDATA%\ProjectEarthLan\chat.json`)
* Paths: L11623-11627. `dataDir = %APPDATA%\ProjectEarthLan`. The files are `chat.json`,
  `fileshare.json` and `voice.json`, and the history folder is `chat\`.
* Default nick is `$env:USERNAME` (L11587). On start, the window loads `chat.json` (L13317-13323):
  a non-empty `Nick` wins, and `Sound` (bool) drives the "Ton / Blinken" checkbox. If the nick is
  still empty, it falls back to `$env:COMPUTERNAME` (L13345).
* The file is written by `Save-CcConfig` (L11966-11973) with PS 5.1:
  `@{ Nick = ...; Sound = <bool> } | ConvertTo-Json | Set-Content -Encoding UTF8`.
  It's **UTF-8 with BOM** and CRLF. The PS 5.1 layout looks like
  `{\r\n    "Sound":  true,\r\n    "Nick":  "Name"\r\n}`: 4-space indent, two spaces after the
  colon, and hashtable key order not guaranteed. A reader must tolerate a BOM, any key order and
  any whitespace.
* `fileshare.json`: `{ DownloadDir: string, Streams: int 1..8, LimitMB: int 0..10000 }`
  (L11970, L13324-13331). The default download dir is `%USERPROFILE%\Downloads\ProjectEarthLAN`
  (L11603).
* `voice.json`: `{ InName, OutName }` holds the audio device names (L11971).
* The same nick feeds all four services: chat L12017, file L12162, social L12331, voice L12346.

### 1.3 Ban list `C:\Project-Earth-Lan\ip_bans.json`
Written by `BanManager.Save` (L13612-13640) with `File.WriteAllText(..., Encoding.UTF8)`, so it is
**UTF-8 with BOM** and has exactly this shape:
```
[\n
  {"Ip":"1.2.3.4","Reason":"...","BannedByIp":"10.0.0.2","TimestampUtc":1700000000000,"Deleted":false,"UpdatedUtc":1700000000000},\n
  {...}\n
]\n
```
* Times are Unix epoch **milliseconds**, UTC (`EarthTime.NowUtcMs`, L13567-13571).
* An unban keeps the entry and sets `"Deleted":true` plus a new `UpdatedUtc` (L13668-13681).
* JSON escaping (`EarthJson.Esc`, L13464-13477): `"` becomes `\"` and `\` becomes `\\`, LF becomes
  `\n`, CR is dropped, other control characters below 0x20 become a space, and there are no
  `\uXXXX` escapes.
* **How the chat, file and voice nodes read it** (duplicated code: chat L11058-11087,
  file L9919-9948, voice L8955-8984):
  * The file is re-read at most every 4000 ms (Environment.TickCount), with the regex
    `"Ip"\s*:\s*"([^"]*)"[^}]*?"Deleted"\s*:\s*(true|false)`.
  * The banned set is every Ip whose `Deleted` is `false`.
  * `"Ip"` must come **before** `"Deleted"` inside the same `{}`. A Dart writer must keep that
    field order.
* The social node uses `BanManager.IsBanned`, which loads a real parse at construction and when the
  timer detects an mtime change (L13149-13162).
* Where a ban takes effect:
  * Chat: incoming beacons (L11216) and every TCP connection, in both directions, right after
    connect and before any byte is sent (L11313).
  * File: incoming beacons (L10138). For incoming TCP, the first line is read, then the connection
    is closed without a reply if the source IP is banned (L10286-10287). Outgoing sends aren't blocked.
  * Social: beacons, PING, POKE (L14148), incoming TCP (L14318) and outgoing sync (L14418).
  * Voice: every datagram (L9346).
* Bans are **local only**. They're never sent on the wire (see 5.4).

### 1.4 Friend list `C:\Project-Earth-Lan\Friendlist.json`
Written by `FriendAndChannelManager.Save` (L13831-13868), UTF-8 with BOM. **[captured]**
```
{
  "Friends": [
    {"Ip":"10.0.0.5","Name":"Kumpel","Notes":"n","Deleted":false,"UpdatedUtc":1790195534381}
  ],
  "Channels": [
    {"Id":"74ccc70d7e4a","Name":"Lobby","OwnerIp":"127.0.0.1","PasswordHash":"","Salt":"LYgQ7aFdhUWgl2e8/jbuHA==","CreatedUtc":1790195534329,"Deleted":false,"UpdatedUtc":1790195534329},
    ...
  ],
  "GlobalAdmins": [
    {"Ip":"..."}
  ]
}
```
When a list is empty it is written as `[\n\n  ]`. The loader (L13779-13829) splits the text at the
positions of `"Friends"`, `"Channels"` and `"GlobalAdmins"`, so the sections must appear in that
order.

**Effect of friends on the protocols: none.** Friends:
* are never transmitted (5.4);
* only colour peers LimeGreen in the lists (L12076, L12467);
* drive the "Nur Freunde" filter, which is purely a display filter on the peer list
  (L12046-12056, L12429-12443). Messages from non-friends are still shown and logged.

"Add friend" uses the peer's IP and name (L11808-11814).

### 1.5 Per-peer volume `C:\Project-Earth-Lan\PeerVolumes.json`
A JSON object `{ "<ip>": <percent 0..200>, ... }` (L11831-11849). Voice only (L9686-9711).

---------------------------------------------------------------------------------------------

## 2. Text chat – port 9874 (C# `EarthChatNode`, L10968-11570; UI L11975-12136, L12859-12962, L13164-13206)

### 2.1 Transport
| Item | Value |
|---|---|
| TCP listener | `<adapterIp>:9874` (L11146) |
| UDP beacon receive | `0.0.0.0:9874`, SO_REUSEADDR (L11182-11185) |
| UDP beacon send | socket bound `<adapterIp>:0`, `EnableBroadcast` (L11252-11253) |
| Beacon destinations | `255.255.255.255:9874` **and**, when Mask is set, the subnet broadcast `(ip | ~mask):9874` (L11248-11259) |
| Beacon period | every 3.0 s (30 × 100 ms sleep, L11271) |
| TCP options | NoDelay, SO_KEEPALIVE (L11315-11316) |
| Topology | full mesh: one persistent TCP connection per peer pair, used in both directions |

### 2.2 Discovery
1. **Beacon** (UDP payload, no terminator), UTF-8 (L11266):
   `PECHAT1B|<nodeId>|<name>`. `<name>` is the *current* chat name (CleanName 32).
   Receiver (L11200-11243):
   * ignore if the source IP is banned;
   * split on `|`; ignore if there are fewer than 3 fields, if `f[0] != "PECHAT1B"` or if
     `f[1] == ownNodeId`;
   * ignore if the source IP equals own BindIp, or if a registered peer already has that IP;
   * rate-limit to one dial per IP per 4000 ms;
   * otherwise TCP-connect to `srcIp:9874` with a 1500 ms timeout and log
     `SYS|Teilnehmer automatisch gefunden: <name> (<ip>)`.
2. **Subnet scan on start** (L12026, L11532-11565):
   * The range is `EarthChatNet.HostRange(ip, mask, 1022)` (L11023-11041). That's all hosts
     `net+1 .. bcast-1`, but if there are more than 1022 hosts (for example on a /16), only the own /24
     is scanned: `a.b.c.1 .. a.b.c.254`.
   * It connects with 48 parallel workers and a 600 ms timeout each, skipping own IP and connected IPs.
   * When finished it emits `SYS|Scan nach Port 9874 abgeschlossen.`
3. **Manual** `ConnectTo(ip)` uses a 2000 ms timeout (L11518-11530). It isn't wired into the
   Option 10 UI, which relies on beacon and scan only.

Both sides typically dial each other at about the same time. Duplicate connections are resolved
in `Register` (2.4).

### 2.3 Framing
* Lines are UTF-8, terminated by `\n`. The writer is `StreamWriter(ns, new UTF8Encoding(false))`
  with `NewLine="\n"` and AutoFlush on (L11317-11319). Each `Send` writes exactly one line.
* The reader is `StreamReader(ns, Encoding.UTF8)` (L11320). `ReadLine` treats **`\n`, `\r` and
  `\r\n`** each as a terminator, and it strips a leading UTF-8 BOM if one appears at stream start.
  So a Dart sender must never put a raw CR inside a line. Outgoing text is already sanitised by
  `CleanLine` (CR and LF each become one space, L11125-11129). A Dart receiver should also treat a
  lone CR as a line break, to behave identically.
* Lines longer than 8000 **chars** after the handshake are silently dropped (L11389).
* Unknown commands are silently ignored (L11387-11412).

### 2.4 Handshake and connection lifecycle (`PeerLoop`, L11309-11346)
Both the accepting and the connecting side run the same code:
1. If the remote IP is banned, close immediately without sending anything.
2. **Immediately send** `HELLO|PECHAT1|<ownNodeId>|<ownName>|<ownChannel>\n` (L11321). Both sides
   send this at the same time; there's no client/server order. `<ownChannel>` is an empty string
   when in "Alle (Gruppenchat)", so the line ends with `|` and then `\n` **[captured]**.
3. Read one line with a 5000 ms receive timeout. Parse it with `Split('|', 5)`, which gives at
   most 5 fields, so a channel field could in theory contain `|`.
   * Require at least 4 fields, `f[0]=="HELLO"` and `f[1]=="PECHAT1"`.
   * `peer.Id=f[2]`, `peer.Name=CleanName(f[3])`, `peer.Chan = f.Length>=5 ? CleanName(f[4]) : ""`.
   * If `peer.Id == ownNodeId`, close (self-connection).
4. `Register` (L11348-11370), keyed by peer NodeId:
   * If no connection to that Id exists, register it and emit `PEER+|id|name|ip`.
   * If one exists, compute the *initiator id* of each connection:
     `initiator = (outgoing ? ownNodeId : peerNodeId)`.
   * If the **new** connection's initiator is **ordinal-less** (`string.CompareOrdinal < 0`) than the
     existing one's, the new connection replaces the old one (old socket closed, `PEER+` emitted
     again). Otherwise the new connection is closed.
   * Result: both ends keep the connection initiated by the smaller NodeId (ordinal ASCII compare of
     the 12-hex strings).
5. Receive timeout goes back to infinite and lines are processed until EOF or error.
6. On exit, `Unregister`: only if this connection object is still the registered one, emit
   `PEER-|id|name|ip`. Then close.

**Presence = the TCP connection.** There's no heartbeat, no online/away state, no typing indicator
and no read receipt. The UI shows every registered peer as `online`, or `neue Nachricht` if a PM
is unread (L12057-12059).

### 2.5 Commands after the handshake (sent over the pairwise connection)
| Line | Sent by | Meaning / receiver action |
|---|---|---|
| `MSG|<text>` | `Broadcast(text)` (L11428-11433): sent to **every** connected peer. `SendToChannel(ch,text)` (L11438-11447): sent only to peers whose last-announced `Chan == ch` (exact, case-sensitive). | Event `CHAT|<peerId>|<peerName>|<text>`. The rest of the line after `MSG|` is taken verbatim, including any further `|`. |
| `PM|<text>` | `SendPrivate(peerId,text)` (L11449-11456): that one peer only | Event `PM|<peerId>|<peerName>|<text>` |
| `NICK|<name>` | `SetName` (L11458-11464): all peers | `nn=CleanName(rest)`. If it isn't empty, set `peer.Name=nn` and emit `NICK|id|old|new`. |
| `CHAN|<channel>` | `SetChannel` (L11420-11425): all peers. `""` means leave the channel. | `peer.Chan = CleanName(rest)` (no event) |

`<text>` = `CleanLine(text)`: CR→" ", LF→" " (so `"\r\n"` becomes **two** spaces **[captured]**). `|`
is **not** escaped in text. The UI trims the input and has `MaxLength = 2000` (L12606, L12874).

**Not on the wire:** there's no timestamp, no message id, no sender IP and no channel name in
`MSG`/`PM`. The receiver uses its own clock and derives sender name and IP from the connection.
There's no dedupe beyond "one connection per peer", and no acknowledgement.

Channel semantics:
* Channels are **advisory**. The sender decides the recipients from the peers' announced `Chan`.
* The receiver does **not** check whether it's in the same channel. A channel message is displayed
  exactly like a group message (`Name: text`).
* If the UI is in a channel and no peer is selected, it uses `SendToChannel(myChan, text)`
  (L12886-12890). It uses `Broadcast` only when not in a channel (L12891-12894).
* Joining a password channel checks the password **locally** against the synced PBKDF2 hash
  (L12950-12957, 5.6). Nothing about the password goes on the chat wire.
* `CHAN` values are CleanName(32), but permanent-channel names in Friendlist.json are only
  `Trim()`ed (L12910-12917). Keep channel names ≤ 32 chars and without `|`, CR or LF, or they won't
  match.

### 2.6 UI behaviour (for parity)
* Private message: if a peer is selected in the list, the message is sent with `SendPrivate`
  (L12877-12884).
* Event handling (L13164-13198) produces these log texts:
  * `PEER+`: `"<name> (<ip>) ist beigetreten."`, only on the first `PEER+` for that NodeId
    (`ChatKnown`, L13176-13179);
  * `PEER-`: `"<name> hat die Verbindung getrennt."`;
  * `NICK`: `"<old> heißt jetzt <new>."`;
  * `CHAT`: `"<name>: <text>"`, colour white, then a notification;
  * `PM`: `"[Privat] <name>: <text>"`, violet. It marks the peer unread unless that peer is
    currently selected.
* Own lines: `"Ich: <text>"`, `"Ich [Kanal '<ch>']: <text>"`, `"Ich an <name> (privat): <text>"`
  (L12881, L12889, L12893).
* Notification (`Send-CcChatNotify`, L11990-11999):
  * If the chat panel isn't visible, increment the counter shown as `Chat (N neu)`.
  * If "Ton / Blinken" is on and the window isn't the active form with the chat panel showing,
    play `SystemSounds.Asterisk` and flash the taskbar with `FlashWindowEx(flags=0xF, count=3)`
    (L10983-11008).

### 2.7 History log `%APPDATA%\ProjectEarthLan\chat\chat_YYYY-MM-DD.log`
* `Get-CcHistFile` (L11978) takes the date from the **local** date at the moment each line is
  written.
* `Add-CcChat` (L11980-11988) appends `"[" + HH:mm:ss (local, 24h) + "] " + text` via PS 5.1
  `Add-Content -Encoding UTF8`: a BOM is written when the file is created, and each line ends
  with CRLF.
* Logged: PEER+, PEER-, NICK, CHAT, PM, and own sent messages (the `$save` default is `$true`).
* Not logged (`$save=$false`): SYS lines, channel create/join/leave notices, "not delivered"
  notices, and the rename notice.
* On window open, the last 30 lines of **today's** file are shown between `--- Verlauf (heute) ---`
  and `--- Ende Verlauf ---` (L13349-13360).
* Example line: `[14:03:27] Alice: Hallo zusammen`.

---------------------------------------------------------------------------------------------

## 3. File transfer – port 9876 (C# `EarthFileNode`, L9756-10964; UI L12138-12301, L12964-13032, L13208-13236)

### 3.1 Transport and discovery
| Item | Value |
|---|---|
| TCP listener | `<adapterIp>:9876` (L10050) |
| UDP beacon rx | `0.0.0.0:9876`, SO_REUSEADDR (L10060-10063) |
| UDP beacon tx | `<adapterIp>:0` → `255.255.255.255:9876` and `(ip|~mask):9876`, every 3.0 s (L10147-10178) |
| Beacon payload | `PEFS1|<nodeId>|<name>` (L10170). `<name>` is `NodeName` (CleanName 60 at construction). |
| Beacon rx rules | Not banned, ≥3 fields, `f[0]=="PEFS1"`, `f[1]!=ownId`. Then `UpsertPeer(id, CleanName(f[2]), srcIp)` (L10122-10145). A new id logs `SYS|Manager gefunden: <name> (<ip>)`. |
| Peer expiry | 12 000 ms since the last beacon, unless added manually (L10225-10251) |
| Connections | **Short-lived TCP connections**: one "control" connection per offer, plus 1..8 parallel "data" connections |

**Manual peer / probe** (`AddManualPeer`, L10180-10208):
* Connect with a 2500 ms timeout and a 3000 ms receive timeout, then send `PING|<ownId>|<ownName>\n`.
* The reply is `PONG|<theirId>|<theirName>\n` (L10288). The peer is stored as Manual, so it never
  expires. The connection is then closed.
* The PING receiver does **not** record the pinger as a peer.

**Server side dispatch** (`HandleConn`, L10273-10294):
* Socket options: NoDelay, ReceiveTimeout 30 000 ms, SendTimeout 30 000 ms, ReceiveBufferSize 1 MiB.
* Read the first line. If the source IP is banned, close silently.
* Dispatch on `f[0]`: `PING`, `OFFER` or `DATA`. Anything else closes the connection.
* Line reader (`EarthReader`, L9770-9828): byte-wise; `\n` terminates, `\r` is dropped anywhere,
  decoded as UTF-8, maximum 8 000 000 bytes per line (otherwise an exception closes the connection).

### 3.2 Identifiers and units
* `xferId` = `Guid.NewGuid().ToString("N").Substring(0,16)`: 16 lowercase hex (L10638). The
  receiver accepts ids 1..64 chars long (L10416).
* `token` = `Guid.NewGuid().ToString("N")`: 32 lowercase hex, created by the receiver (L10457).
* `chunkSize` = the sender always uses **2 097 152** (2 MiB, L10642). The receiver accepts any
  value from 65 536 to 16 777 216 (L10416).
* `chunks(size) = ceil(size / chunkSize)`, so a 0-byte file has **0 chunks**.
  `chunkLen(ci) = min(chunkSize, size - ci*chunkSize)` (L9998-10002).
* `mtimeTicks` = `FileInfo.LastWriteTimeUtc.Ticks`: .NET ticks (100 ns units since
  0001-01-01 00:00:00 UTC). Convert with
  `ticks = unixMillis*10000 + 621355968000000000`
  **[captured: unix 1700000000 s → 638355968000000000]**.
* The hash is SHA-256 of the chunk payload, as **lowercase** hex (64 chars) (L9989-9996). The
  receiver compares it case-insensitively.
* The relative path `rel` uses `/` separators. For a selected folder, the folder's own name is the
  first component (`Ordner/a.txt`, `Ordner/sub/b.bin`) (L10603-10629).
  * Empty directories aren't transferred.
  * Reparse-point (symlink/junction) directories are skipped.
  * Unreadable entries are skipped silently.

### 3.3 Control connection: OFFER → ACCEPT/DENY
Sender (`Handshake`, L10710-10760) connects with a 3000 ms timeout, NoDelay, ReceiveTimeout
**90 000 ms**, SendTimeout 30 000 ms, and writes everything in one `Write`:
```
OFFER|<xferId>|<senderNodeId>|<senderName>|<fileCount>|<totalBytes>|<chunkSize>\n
F|<rel>|<size>|<mtimeTicks>\n          (one per file, fileCount times, in index order 0..n-1)
END\n
```
Receiver (`HandleOffer`, L10407-10509) validates the offer. If a check fails, it either closes the
connection silently or replies with a DENY line:

| Check | Result |
|---|---|
| < 7 fields in the OFFER line | close silently |
| fc/total/cs not integers | close silently |
| fc∉[0,200000], total<0, cs∉[65536,16777216], or id length ∉[1,64] | close silently |
| an F line with <4 fields, not starting `F`, non-integer size/mtime, or size<0 | close silently |
| `SafeRel(rel)` is null, or the path is a duplicate (case-insensitive) | `DENY|Ungueltiger oder doppelter Dateipfad im Angebot\n`, close |
| a file has more than 10 000 000 chunks | `DENY|Datei zu gross\n`, close |
| the line after the F lines isn't exactly `END` | close silently |
| fc = 0 | throws (the code indexes `files[0]`), connection closes silently. Never send an empty offer. |

`SafeRel` (L10004-10026) does the following:
* replace `\` with `/` and split on `/`;
* reject the whole path if any component is empty, `.`, `..`, contains any of
  `Path.GetInvalidFileNameChars()`, or ends with `.` or space;
* reject reserved device names, where the stem is the part before the **first** dot, compared
  case-insensitively: CON PRN AUX NUL COM1-9 LPT1-9.

On Windows the invalid characters are `"` `<` `>` `|` `:` `*` `?` `\` `/` and 0x00-0x1F. **A Dart
sender must therefore never offer names containing `\ : * ? " < > |` or control characters**,
names ending in dot or space, or reserved stems. Any of these makes the Windows receiver DENY the
whole offer. `|` would also corrupt the field split. Since the F line is split on `|` without a
limit, `rel` can't contain `|`.

**Resume path, no prompt** (L10443-10446, L10496-10508): if a transfer with the same `xferId`
already exists on the receiver, and it's incoming, not finished and accepted, the receiver replies
at once with the same token and the current bitmaps.

**New offer:**
1. Register the transfer and emit `OFFER|id|senderName|srcIp|fc|total`.
2. The UI shows a modal Yes/No dialog: `"<name> (<ip>) möchte dir <n> Datei(en) senden (<size>). Gespeichert wird in: <dir>. Annehmen?"` (L13221-13229).
3. The receiver waits up to **60 000 ms** (L10462). On timeout or No, it replies
   `DENY|Nicht angenommen\n`.
4. On Yes, for each file it runs `PrepareRecvFile` (3.6), then replies in **one write**:
```
ACCEPT|<token32hex>\n
H|<fileIndex>|<bitmap>\n        (one per file, index order; bitmap = one char per chunk, '1' = already have, '0' = need)
GO\n
```
   For a 0-byte file the bitmap is the empty string (`H|3|`).
5. If a directory couldn't be created, it replies
   `DENY|Zielordner nicht beschreibbar: <msg with | → />\n`.
6. The receiver then closes the control connection.

Sender handling of the reply:
* A line starting `DENY` fails the transfer with status "Abgelehnt", no retry (L10674-10679).
* Otherwise the first line must split to `ACCEPT|token`.
* Then it reads `H|idx|bits` lines until `GO`. Missing `H` lines or short bitmaps count as "need"
  (L10738-10751).
* Other lines before `GO` are ignored.

### 3.4 Data connections
* `TransferData` (L10762-10793) builds a FIFO job queue of every chunk marked `0`. The order is
  file-major, chunk-ascending.
* If nothing is missing, the transfer is done and **no data connection is opened**.
* It starts `streams = clamp(Streams, 1, 8)` threads (UI "Parallele Verbindungen", default 4).
  Each thread opens its own TCP connection **lazily**, only when it dequeues its first job. So with
  2 missing chunks and 4 streams, only 2 connections open **[captured]**.

Per connection (`DataSender`, L10795-10886):
* Connect with a 3000 ms timeout. Options: NoDelay, Receive/SendTimeout 30 000 ms, SendBufferSize 1 MiB.
```
→ DATA|<xferId>|<token>\n
← READY\n                     (or NO\n → sender aborts the whole transfer: "Vom Empfaenger abgebrochen")
repeat per job:
→ C|<fileIndex>|<chunkIndex>|<len>|<sha256hex>\n<len raw bytes>
← OK|<fileIndex>|<chunkIndex>\n     (chunk accepted, or already present)
   or BAD|<fileIndex>|<chunkIndex>\n  (hash mismatch; nothing written)
→ BYE\n                       (when the queue is empty, or on thread exit, if the connection is alive)
```
* The header and payload go out as two `Write` calls with no delimiter after the payload. The next
  header follows directly after the ack.
* The sender waits for the ack before sending the next chunk: one chunk in flight per connection.
* Chunks arrive in any order across connections.

Receiver (`HandleData`, L10511-10562):
* Reply `NO` if the xfer is unknown, outgoing, has the wrong token, is cancelled, or isn't accepted.
* Otherwise `READY`, then loop reading headers.
* Break and close **without reply** on: EOF, `BYE`, a non-`C` line, <5 fields, non-integer fields,
  a file or chunk index out of range, or `len != chunkLen(size, ci, chunkSize)`.
* If the hash is good and the chunk is new: seek to `ci*chunkSize`, write, set the bit, and count
  down. If the file is complete, finalize it (3.6).
* Always reply `OK` on a good hash, even for duplicates.

Sender retry logic:
* On `BAD` (or any non-`OK` ack) the job is re-queued with `retry+1`, and the thread sleeps
  `min(8000, 300 * 2^min(failures,5))` ms. `failures` counts only exceptions, so a plain BAD sleeps
  300 ms.
* On an exception (timeout, reset, file changed size) the connection is closed and re-opened for
  the next job.
* A thread exits if `retry > 8` for a job, `failures > 30`, or abort.
* The transfer succeeds when every job is acked `OK`.

### 3.5 Retries, resume and cancellation
* `SendWorker` (L10660-10708) makes up to **6 attempts**. Each attempt re-runs the OFFER handshake
  with the **same xferId**, so the receiver takes the no-prompt resume path, and 4000 ms passes
  between attempts. Status texts: "Warte auf Zustimmung ...", "Verbindung wird wiederhergestellt (n) ...",
  "Unterbrochen - versuche Fortsetzen ...", "Unterbrochen - erneut senden setzt fort".
* **Cross-session resume.** A new `SendPaths` gets a new xferId and so needs a new accept prompt.
  The receiver then resumes from `<final>.part` and `<final>.part.map` if the map header matches.
* **Receiver cancel** (`CancelTransfer`, L10934-10949) saves the maps, closes the files and marks
  the transfer failed. Open data loops exit because they check `!x.Cancel`. The next sender
  reconnect gets `NO`, so the sender reports "Vom Empfaenger abgebrochen".
* **Sender cancel** stops the threads, which send `BYE`. The receiver keeps its `.part` and map
  (status becomes "Wartet auf Sender (Fortsetzen moeglich)" after 10 s without progress, L10917).
* There is **no explicit end-of-transfer message** and **no whole-file hash**. Integrity is the
  per-chunk SHA-256 only.

### 3.6 Where and how files are written (receiver)
* The destination root is `DownloadDir` at offer time (default `%USERPROFILE%\Downloads\ProjectEarthLAN`).
* `FinalPath = Path.Combine(DownloadDir, rel)` with OS separators. Sub-directories are created.
* `PrepareRecvFile` (L10296-10338):
  1. If `FinalPath` exists with the **same size** and `|mtime difference| < 20 000 000 ticks (2 s)`,
     the file counts as already received: all bits are `1` and nothing is written.
  2. Otherwise it resumes if `FinalPath+".part"` and `FinalPath+".part.map"` both exist and the map
     is valid (see below). If not, it deletes the stale `.part`.
  3. It opens `.part` (OpenOrCreate, ReadWrite, share Read). A 0-chunk file is finalized immediately.
* **Map file** `<final>.part.map` is written with `File.WriteAllText` (UTF-8, **no BOM**), every
  3 s while dirty, and on cancel or stop (L10564-10585, L10225-10251):
  `"<size>|<mtimeTicks>|<chunkSize>\n<bits>"`, with no trailing newline. `bits` is one `0`/`1` per chunk.
  It's valid only if line 1 matches exactly and `len(bits) == chunks` (L10319-10324).
* `FinalizeFile` (L10353-10398):
  1. `SetLength(size)`, flush, close.
  2. **Name collision:** if `FinalPath` exists, then
     * if it has the same size and mtime within 2 s, the `.part` is deleted and the existing file is kept;
     * otherwise the target becomes `UniqueName`: `"<name> (1)<ext>"`, `" (2)"`, … up to 9999
       (L10340-10351). The extension is the last `.` suffix.
  3. `File.Move(.part → target)`, then `SetLastWriteTimeUtc(target, mtimeTicks)`, then delete the map.
     **[captured: the existing `Ordner/hallo.txt` stayed, the new file landed as
     `Ordner/hallo (1).txt` with mtime = offered ticks]**
  4. When every file is done, emit `DONE|<xferId>|<title>` and log `Fertig: <title>`. The title is
     the single `rel`, or `"<n> Dateien"`.

### 3.7 Speed limit
`EarthThrottle` (L9891-9914) is a token bucket shared by **all** outgoing streams and transfers of
the node:
* rate = `LimitMB × 1 048 576` bytes/s (L12166, L12989); 0 means unlimited;
* bucket capacity = 1 s of rate;
* it's called before each chunk send with the chunk length; sleep ≤ 2000 ms per call.

The receiver has no limit.

---------------------------------------------------------------------------------------------

## 4. Discovery summary used by Option 10

| Service | UDP beacon | Period | Dial/peer rule | Expiry |
|---|---|---|---|---|
| Chat 9874 | `PECHAT1B|id|name` | 3 s | beacon → TCP connect (1.5 s, ≤1 per IP per 4 s) + subnet TCP scan at start | TCP connection lifetime |
| File 9876 | `PEFS1|id|name` | 3 s | beacon → list entry only; TCP only on send | 12 s |
| Social 9776 | `PESOC1B|id|name` | 5 s | beacon → peer entry **and immediate TCP SYNC** | 15 s |
| Voice 9873 | `PV1|HI|id|name|chan|locked` | 2 s | beacon + unicast to known and manual IPs | 9 s |

All beacons are raw UTF-8 datagrams with no terminator and no signature.
* Chat, file and social beacons go from `<adapterIp>:ephemeral` to `255.255.255.255` and the
  adapter's subnet broadcast.
* Voice sends on **every** up, non-loopback, non-tunnel, non-169.254 IPv4 interface to that
  interface's broadcast and to 255.255.255.255 (L9154-9221).

The UI's "online users" lists are:
* chat: the registered TCP peers (`GetPeers`: `id|name|ip|chan`, L11471-11479);
* file: the beacon-derived peer table (`id|name|ip|secondsSinceSeen`, L10210-10223);
* voice: its own table.

The lists aren't merged across services. The header shows `Chat: <n> | Datei-Manager: <n>` (L13269).

---------------------------------------------------------------------------------------------

## 5. "Social" / channel sync – port 9776 (C# `EarthSocialNode` + managers, L13394-14483; UI L12316-12340)

The code calls this "Freunde und dauerhafte Kanäle" (L4622), but **in this version only the
permanent channels are synchronised**. There are no friend requests, no presence and no chat on
this port.

### 5.1 Transport
| Item | Value |
|---|---|
| TCP listener | `<adapterIp>:9776` (L14110) |
| UDP rx | `0.0.0.0:9776`, SO_REUSEADDR (L14117-14120). It also **sends** PONG replies from this socket. |
| Beacon tx | `<adapterIp>:0` → `255.255.255.255:9776` + subnet broadcast, every **5.0 s** (L14183-14214) |
| Ping tx | separate socket `<adapterIp>:0`, every 3.0 s, unicast to each known peer (L14216-14237) |

It's started at window open (`Start-CcAllNodes`) and again by Start-CcVoice (L12345).

### 5.2 UDP messages (raw datagrams, UTF-8, no terminator), receive handler L14137-14181
| Payload | Handling |
|---|---|
| `PESOC1B|<nodeId>|<name>` | If ≥3 fields and id ≠ own: `UpsertPeer` (name CleanName 40, `SYS|Teilnehmer gefunden: <name> (<ip>)` for a new id), prune peers idle for more than 15 s, then **`RequestSync(srcIp)`**. That's one TCP sync per received beacon: about every 5 s per peer, and twice if both broadcasts arrive. |
| `PING|<token>` | Reply `PONG|<token>` (exactly the bytes after `PING|`) to the **source endpoint** (ip:port) from the 9776 socket. |
| `PONG|<token>` | Latency = now − sent time for key `ip|token`. **Note:** Windows peers send PING from an ephemeral-port socket that never reads, and the PONG goes back to that ephemeral port. So Windows↔Windows latency is never measured. A Dart peer must still answer PING→PONG to the source endpoint. |
| `POKE|<nodeId>|<name>` | If ≥3 fields and id ≠ own: `PokeManager.OnPokeReceived` queues `POKE|name`, or `BLOCKED|name` if DoNotDisturb (L14020-14054). **Option 10 never drains this queue**, and its "Anstupsen" menu calls `SendPoke` on the chat, file or voice node (L11820-11826, L11863-11868), which don't have that method, so the exception is swallowed. **Pokes are effectively never sent or shown.** Wire format for a sender, per `SendPoke` (L14462-14473): `POKE|<socialNodeId>|<CleanName(myName)>` unicast from an ephemeral socket to `peerIp:9776`. The client-side cooldown is 5000 ms per peer (L14026-14041). |

The token in PING is `Guid.NewGuid().ToString("N").Substring(0,8)`.

### 5.3 TCP sync (full snapshot exchange, last-write-wins)
The client (`RequestSync`, L14412-14437) connects with a 2500 ms timeout and 15 000 ms
receive/send timeouts.
```
C→S  SYNC1|<clientNodeId>\n
S→C  <snapshot of server>          (one Write)
C→S  <snapshot of client>          (one Write) , then client closes
```
The server (`HandleConn`, L14313-14330):
* reads one line (byte-wise, max 4 000 000 bytes, CR dropped);
* requires the prefix `SYNC1|`, and ignores the id;
* sends its snapshot;
* then `ReadAll`: blocks on the first `Read` (up to 15 s), keeps reading while
  `DataAvailable`, then parses. **Send the whole client snapshot in one write/segment**, or the
  server may parse a truncated snapshot;
* closes.

The client reads the server snapshot byte by byte until the last ≤5 bytes contain `END\n`
(L14439-14460).

**Snapshot format** (`SendSnapshot`, L14350-14364), UTF-8, LF line ends:
```
BANS\n
FRIENDS\n
CHANNELS\n
<id>\t<name>\t<ownerIp>\t<passwordHash>\t<salt>\t<createdUtcMs>\t<deleted 0|1>\t<updatedUtcMs>\n   (0..n lines)
END\n
```
* Every channel is sent, **including tombstones** (`deleted=1`).
* A TAB in the name becomes a space. Other fields aren't escaped, so a name must not contain LF.
* `id` is 12 lowercase hex (`Guid N`[0..12], L13936).
* `passwordHash` is empty for an open channel, else Base64 (5.6).
* `salt` is Base64 of 16 random bytes (always present).
* Times are Unix ms UTC.

**Parsing** (`ApplyIncoming`, L14366-14410):
* Split on `\n` and trim a trailing `\r`.
* Lines equal to `BANS`, `FRIENDS`, `CHANNELS` or `END` switch the section. Empty lines are skipped.
* A CHANNELS line needs ≥8 TAB fields. A line that fails to parse is skipped.
* BANS lines (≥6 fields: `ip\treason\tbannedBy\ttsMs\tdeleted\tupdatedMs`) and FRIENDS lines
  (≥5 fields: `ip\tname\tnotes\tdeleted\tupdatedMs`) are parsed but then **discarded** (L14404-14407).
  Current Windows builds always send those sections empty.

**Merge** (L13986-14006): for each incoming channel with a non-empty id, replace the local entry if
there's none or `incoming.UpdatedUtc > local.UpdatedUtc` (strictly greater). If anything changed,
save Friendlist.json and emit `SYS|Kanal-Abgleich empfangen und übernommen.`

There's **no authorization on the wire**. Deletion is enforced only locally in the UI: only
`OwnerIp == ownIp` or an IP in the local `GlobalAdmins` may call `DeleteChannel` (L13952-13964).
A received tombstone with a newer `UpdatedUtc` is always accepted.

### 5.4 What is and isn't synced
| Data | Synced? |
|---|---|
| Permanent channels (chat and voice share the same list, L12095-12097, L12434-12436) | yes, 9776 |
| Friends | **no**: personal, local only (comment L14352-14354) |
| Bans | **no**: local only |
| Global admins | no |
| Friend requests / presence | don't exist |

### 5.5 How channels are used
* "Kanal erstellen" in chat or voice creates a permanent entry (`CreateChannel(name, ownIp, pw)`,
  L13934-13950) and immediately joins it:
  * chat: `SetChannel(name)` → `CHAN|name`;
  * voice: `VoiceNode.CreateChannel`.
* Channel lists show permanent channels even when empty, plus temporary channels that exist only
  because some peer announced them (L12091-12136, L12432-12517).

### 5.6 Channel password hash (permanent channels)
`PasswordHash = Base64( PBKDF2-HMAC-SHA1(password UTF-8, salt = Base64Decode(Salt), iterations = 20000, dkLen = 32) )`
(L13925-13932). It's the empty string when there's no password.

The check is done locally by the joining client (`CheckChannelPassword`, L13966-13973) against the
synced hash. An empty stored hash means open.

Test vector **[computed with the original C# and cross-checked with Python hashlib]**:
password `TestCode12345678`, salt `AAECAwQFBgcICQoLDA0ODw==` (bytes 00..0f) →
`fuW8O5hWIXGEdhKv9wcXwnk908vzJM7I9XgV5f4lWLk=`.

---------------------------------------------------------------------------------------------

## 6. Interop checklist for the Dart implementation
1. Bind the TCP listeners on the chosen interface IPv4. Bind the UDP receivers on `0.0.0.0` with
   reuseAddress. Send beacons both to `255.255.255.255` and to the subnet broadcast.
2. Generate fresh 12-hex NodeIds per service. Use them in the chat duplicate-connection rule
   (ordinal compare).
3. Chat: send your HELLO immediately on connect (don't wait for theirs). Include the 5th field,
   even if empty. Answer within 5 s. Never emit CR. Keep lines ≤ 8000 UTF-16 units.
4. File: always offer at least 1 file. Sanitise names to the Windows rules. Use chunk size 2 MiB,
   or anything from 64 KiB to 16 MiB. Report mtime in .NET ticks. Send lowercase SHA-256. Keep one
   chunk in flight per connection and wait for `OK|`/`BAD|`. Send `BYE` before closing. Allow
   90 s+ for the ACCEPT, since a human is clicking a dialog. Reuse the same xferId when
   re-offering after a network error, to get the no-prompt resume.
5. File receiver: reply to each offer in one write. Reply `OK` for duplicate chunks. Keep `.part`
   and `.part.map` in the same format for cross-implementation resume. Check the 2 s mtime
   tolerance and use the `name (n).ext` collision rule.
6. Social: answer `SYNC1` with a full snapshot in one write. Send your own snapshot in one write
   after reading theirs. Only merge the CHANNELS section, and apply LWW on `UpdatedUtc`. Answer
   `PING|t` with `PONG|t` to the source ip:port.
7. Ban file: keep the `"Ip"` key before `"Deleted"` in each object. Windows peers regex-scan it.

---------------------------------------------------------------------------------------------

## 7. Line-reference index
| Topic | Lines |
|---|---|
| Port table in help text | 4622-4627 |
| Network secret / HMAC (not used by Option 10) | 41-76 |
| Adapter list / auto / selected | 325-417 |
| Voice C# (`EarthVoiceNet`, audio, `EarthVoiceNode`) | 8597-9752 |
| File C# (`EarthReader` … `EarthFileNode`) | 9756-10964 |
| Chat C# (`EarthChatNet`, `EarthChatPeer`, `EarthChatNode`) | 10968-11570 |
| `Invoke-CommCenter` (Option 10 UI) | 11575-13386 |
| Firewall rules | 11933-11964 |
| Config save/load | 11966-11973, 13317-13347 |
| History log | 11978-11988, 13349-13360 |
| Chat send button logic | 12873-12899 |
| Chat channel buttons | 12907-12962 |
| File send / target / cancel | 12964-13032 |
| Timer / event dispatch | 13141-13284 |
| Social C# (paths, JSON, BanManager, FriendAndChannelManager, PokeManager, EarthSocialNode) | 13394-14483 |

---------------------------------------------------------------------------------------------

## 8. Captured test vectors (real bytes from the original C#)

Method: the C# blocks were extracted verbatim (chat L10971-11566, file L9759-10960, social
L13397-14479, voice L8600-9748) and compiled with `Add-Type` in pwsh 7.4.6. The only change was a
prepended `#pragma warning disable` for obsolete-API warnings. The C# node was bound to 127.0.0.1
and Python peers were bound to 127.0.0.2/127.0.0.3. NodeIds are random per run. Scripts:
`scratchpad/t/{load,run_chat,run_file,run_soc,run_voice}.ps1` and `peer_*.py`.
Hex is space-separated.

### 8.1 Chat (node name `Tester äö`, NodeId `35bb593cc0ab`)
Beacon (UDP to 127.255.255.255:9874, 33 bytes):
```
50 45 43 48 41 54 31 42 7c 33 35 62 62 35 39 33 63 63 30 61 62 7c 54 65 73 74 65 72 20 c3 a4 c3 b6
"PECHAT1B|35bb593cc0ab|Tester \xc3\xa4\xc3\xb6"
```
HELLO sent by the node on both an accepted and an outgoing connection (40 bytes, empty channel):
```
48 45 4c 4c 4f 7c 50 45 43 48 41 54 31 7c 33 35 62 62 35 39 33 63 63 30 61 62 7c 54 65 73 74 65 72 20 c3 a4 c3 b6 7c 0a
"HELLO|PECHAT1|35bb593cc0ab|Tester \xc3\xa4\xc3\xb6|\n"
```
Peer HELLO accepted by the node (with channel): `HELLO|PECHAT1|pyin00000002|InPeer|Lobby\n`
`Broadcast("Hallo Welt ä€ 😀\r\nZeile2 | Pipe")` → sent to each peer (41 bytes):
```
4d 53 47 7c 48 61 6c 6c 6f 20 57 65 6c 74 20 c3 a4 e2 82 ac 20 f0 9f 98 80 20 20 5a 65 69 6c 65 32 20 7c 20 50 69 70 65 0a
"MSG|Hallo Welt \xc3\xa4\xe2\x82\xac \xf0\x9f\x98\x80  Zeile2 | Pipe\n"
```
Other lines:
* `SetChannel('Lobby')` → `43 48 41 4e 7c 4c 6f 62 62 79 0a` = `CHAN|Lobby\n`
* `SendPrivate(id,'geheim')` → `50 4d 7c 67 65 68 65 69 6d 0a` = `PM|geheim\n`
* `SetName('Neuer|Name')` → `4e 49 43 4b 7c 4e 65 75 65 72 2f 4e 61 6d 65 0a` = `NICK|Neuer/Name\n`

Node events for lines received from the Python peer:
```
PEER+|pyin00000002|InPeer|127.0.0.1
CHAT|pyin00000002|InPeer|Hallo von Python ä€      (from "MSG|Hallo von Python \xc3\xa4\xe2\x82\xac\n")
PM|pyin00000002|InPeer|psst privat               (from "PM|psst privat\n")
NICK|pyin00000002|InPeer|Neu/Name                (from "NICK|Neu|Name\n")  -- '|' → '/'
PEER+|pyout0000001|PyServer|127.0.0.2
PEER-|pyin00000002|Neu/Name|127.0.0.1
```

### 8.2 File transfer, node → peer (2 200 000-byte file `big.bin`, mtime unix 1700000000)
Control connection, node → peer:
```
4f 46 46 45 52 7c 66 64 62 37 62 39 33 38 30 33 39 30 34 30 37 38 7c 30 66 36 63 32 36 30 34 37 31 36 37 7c 54 65 73 74 65 72 20 c3 a4 c3 b6 7c 31 7c 32 32 30 30 30 30 30 7c 32 30 39 37 31 35 32 0a
"OFFER|fdb7b93803904078|0f6c26047167|Tester \xc3\xa4\xc3\xb6|1|2200000|2097152\n"
46 7c 62 69 67 2e 62 69 6e 7c 32 32 30 30 30 30 30 7c 36 33 38 33 35 35 39 36 38 30 30 30 30 30 30 30 30 30 0a
"F|big.bin|2200000|638355968000000000\n"
45 4e 44 0a   "END\n"
```
Peer → node (a Python reply the node accepted):
`ACCEPT|tok0123456789abcdef0123456789ab\nH|0|00\nGO\n`

Two data connections opened in parallel, one per missing chunk:
```
→ DATA|fdb7b93803904078|tok0123456789abcdef0123456789ab\n
← READY\n
→ C|0|0|2097152|1e075c8d478ad21844e33e830a695ef03a4d2488b69ee275bd8947618bb1be1e\n + 2097152 bytes (00 01 02 03 … i%251)
← OK|0|0\n
→ BYE\n
(second connection)
→ C|0|1|102848|789271b64bba7badf4405eb0d64ef511fbcfe8a6c7d38d1aa7879af14abbc268\n + 102848 bytes (2f 30 31 32 …)
← OK|0|1\n
→ BYE\n
```
The chunk header bytes for chunk 0 (79 bytes):
```
43 7c 30 7c 30 7c 32 30 39 37 31 35 32 7c 31 65 30 37 35 63 38 64 34 37 38 61 64 32 31 38 34 34 65 33 33 65 38 33 30 61 36 39 35 65 66 30 33 61 34 64 32 34 38 38 62 36 39 65 65 32 37 35 62 64 38 39 34 37 36 31 38 62 62 31 62 65 31 65 0a
```
Re-offering the same file with a reply of `H|0|10` made the node send only `C|0|1|102848|…`, which
shows resume by bitmap.

A folder offer with 2 files:
`OFFER|38c045094269449e|0f6c26047167|Tester äö|2|9|2097152\nF|Ordner/a.txt|6|639257922652538709\nF|Ordner/sub/b.bin|3|639257922652539071\nEND\n`.
When answered with `DENY|Nicht angenommen\n`, the transfer status became "Abgelehnt" with no retry.

### 8.3 File transfer, peer → node (receiver behaviour)
Probe:
* `PING|pyfile000001|PySender\n` → `PONG|0f6c26047167|Tester \xc3\xa4\xc3\xb6\n`
  (`50 4f 4e 47 7c 30 66 36 63 32 36 30 34 37 31 36 37 7c 54 65 73 74 65 72 20 c3 a4 c3 b6 0a`)

Offer (chunk size 64 KiB):
`OFFER|pyxfer00000001|pyfile000001|PySender|2|70003|65536\nF|Ordner/hallo.txt|70000|638400000000000000\nF|x.bin|3|638400000000000000\nEND\n`
* Node event `OFFER|pyxfer00000001|PySender|127.0.0.1|2|70003`, auto-answered with Yes.
* Reply (56 bytes):
```
41 43 43 45 50 54 7c 62 36 36 64 31 33 64 63 66 31 65 36 34 37 37 32 39 30 65 33 64 65 62 38 36 39 35 34 31 63 35 66 0a 48 7c 30 7c 30 30 0a 48 7c 31 7c 30 0a 47 4f 0a
"ACCEPT|b66d13dcf1e6477290e3deb869541c5f\nH|0|00\nH|1|0\nGO\n"
```
Data connection:
```
→ DATA|pyxfer00000001|b66d13dcf1e6477290e3deb869541c5f\n        ← READY\n
→ C|0|0|65536|000…000 (64 zeros)\n + 65536 bytes                ← BAD|0|0\n
→ C|0|0|65536|d790e413479d16f4eab89ec0d18e3565e0982bd4788c26736a76d20ea781c901\n + data   ← OK|0|0\n
→ C|0|1|4464|ae0aa68185d6ddb3d03a8a9a71923d4d2079d45fa370ec5e8ea4edf25e5e7e69\n + data    ← OK|0|1\n
→ C|1|0|3|ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad\n + "abc"      ← OK|1|0\n
→ BYE\n
```
The event `DONE|pyxfer00000001|2 Dateien` followed.
* A DATA request with a wrong token gets `NO\n` (`4e 4f 0a`).
* Files on disk: `dl/x.bin` (3 bytes) and `dl/Ordner/hallo (1).txt` (70000 bytes). The pre-existing
  different `dl/Ordner/hallo.txt` was kept. Both new files have mtime 1704403200 = ticks
  638400000000000000.

### 8.4 Social 9776 (NodeId `dfa05d92d7dd`)
Beacon: `50 45 53 4f 43 31 42 7c 64 66 61 30 35 64 39 32 64 37 64 64 7c 54 65 73 74 65 72 20 c3 a4 c3 b6` = `PESOC1B|dfa05d92d7dd|Tester äö`

The node as sync client sends `SYNC1|dfa05d92d7dd\n` (`53 59 4e 43 31 7c 64 66 61 30 35 64 39 32 64 37 64 64 0a`).

The Python server's snapshot:
```
BANS\n1.2.3.4\tspam\t10.0.0.9\t1700000000000\t0\t1700000000000\nFRIENDS\n5.6.7.8\tFreund\tnotiz\t0\t1700000000000\nCHANNELS\nabcdef012345\tPy Kanal\t127.0.0.2\t\tAAECAwQFBgcICQoLDA0ODw==\t1700000000000\t0\t1700000000000\nEND\n
```
The node then sent its own snapshot (329 bytes). The BANS and FRIENDS it received were ignored, and
the channel was merged:
```
BANS\nFRIENDS\nCHANNELS\n
74ccc70d7e4a\tLobby\t127.0.0.1\t\tLYgQ7aFdhUWgl2e8/jbuHA==\t1790195534329\t0\t1790195534329\n
fa6be961709a\tGeheim\t127.0.0.1\t1Ry8W8AzTvaxwDzAe6jqraisNq3XuiVWaU1syHS7/+M=\t8Myu3a+6RuJwBCp3VJ4z1Q==\t1790195534378\t0\t1790195534378\n
abcdef012345\tPy Kanal\t127.0.0.2\t\tAAECAwQFBgcICQoLDA0ODw==\t1700000000000\t0\t1700000000000\n
END\n
```
(Hex of the start: `42 41 4e 53 0a 46 52 49 45 4e 44 53 0a 43 48 41 4e 4e 45 4c 53 0a 37 34 63 63 …`)

"Geheim" has password `TestCode12345678`: `PBKDF2-SHA1(pw, b64dec("8Myu3a+6RuJwBCp3VJ4z1Q=="), 20000, 32)`
gives `1Ry8W8AzTvaxwDzAe6jqraisNq3XuiVWaU1syHS7/+M=`.

As server, the node answered `SYNC1|pysoc0000001\n` with the same 329-byte snapshot, then accepted
`BANS\nFRIENDS\nCHANNELS\nfedcba987654\tKanal Zwei\t127.0.0.3\t\tAAAAAAAAAAAAAAAAAAAAAA==\t1700000001000\t0\t1700000001000\nEND\n`,
and that channel appeared in its list.

UDP:
* `PING|a1b2c3d4` → `PONG|a1b2c3d4`, sent from port 9776 to the sender's port.
* `SendPoke('127.0.0.2','Mein|Name')` → `POKE|dfa05d92d7dd|Mein/Name`.
* The received `POKE|pysoc0000001|Py Poker` → PokeManager event `POKE|Py Poker`.

### 8.5 KDF vectors
| Function | Input | Output |
|---|---|---|
| Permanent channel hash (5.6) | pw `TestCode12345678`, salt `AAECAwQFBgcICQoLDA0ODw==` | `fuW8O5hWIXGEdhKv9wcXwnk908vzJM7I9XgV5f4lWLk=` |
| Voice `HashPw` (A.3) | channel `Lobby`, pw `TestCode12345678` | `9E1111EDEB87084C6D899A09B361A89B` |
| Voice `HashPw` | channel `Lobby`, pw `` | `EB8522D21CB8AC33DB355139D0B2563B` |

All three were reproduced with Python `hashlib.pbkdf2_hmac('sha1', …)`.

---------------------------------------------------------------------------------------------

## Appendix A – Voice, UDP 9873 (short summary; C# L8597-9752)
* **Socket:** one UDP socket bound to `0.0.0.0:9873` (no SO_REUSEADDR). It sends and receives
  everything. Receive buffer 256 KiB.
* **Datagram types.** First byte `0xA1` with length > 15 is audio. First byte `'P'` with length > 4
  is control text (UTF-8, `|`-separated) (L9347-9348).
* **Presence**, every 2 s:
  * payload `PV1|HI|<id12>|<name≤40>|<channel>|<locked 0|1>` (L9193-9199);
  * sent to every interface's subnet broadcast and to 255.255.255.255 (from per-interface sockets),
    and unicast from the main socket to known and manual peer IPs (L9201-9221);
  * peers are pruned after 9 s (L9273-9289);
  * a new peer receives an immediate unicast HI back (L9415).
  * **[captured]** `PV1|HI|bb722f76e23e|Tester äö|Lobby|1`
* **Control messages.** `id` must be exactly 12 chars and not your own (L9401). Handler L9377-9511:
  * `PV1|JOIN|id|chan|hash` → reply `PV1|OK|id|chan` if `myChannel==chan` and the channel is not
    locked or the hash matches, otherwise `PV1|NO|id|chan`.
  * `PV1|OK|id|chan` adds the sender to members. `PV1|NO|id|chan` means denied.
  * `PV1|LEAVE|id|chan` and `PV1|BYE|id` (on stop) remove the peer.
  * Private call: `PV1|CALL|id|name`. The callee answers `PV1|ACC|id|@<minId>~<maxId>` (ordinal
    order of the two NodeIds) or `PV1|DECL|id`. The caller then answers `PV1|OK|id|<pair>`.
  * Latency: `PV1|LPING|id|tok8` → `PV1|LPONG|id|tok8`, every 2 s.
  * While in a channel, `JOIN` is re-sent every 2 s to peers in the same channel that aren't members
    yet (L9254-9271).
* **Channel password:** `hash = HEX_UPPER( PBKDF2-HMAC-SHA1(pw, UTF8("ProjectEarthLanVoice:" + channel), 3000, 16) )`
  (L9036-9042). Sent in JOIN. An open channel still sends the hash of the empty password, which is
  ignored when the channel isn't locked. Channel names starting with `@` are private.
* **Audio packet** (L9670-9680): `[0]=0xA1`, `[1..12]` = the sender's 12-char NodeId in ASCII,
  `[13..14]` = seq uint16 **big-endian**, incremented per packet from 1 with wraparound, then
  `[15..]` = G.711 **µ-law** samples, one byte each.
  * The encoder is the classic bias-0x84 µ-law with clip 32635, bytes inverted (L9044-9066).
  * Audio format: PCM 16-bit mono **16 000 Hz**, 320 samples = **20 ms** per packet, so the packet is
    335 bytes (L8736-8750).
  * It's sent unicast to each channel member's `ip:9873` only. The receiver accepts it only from
    current members, and only with 1..1920 samples. seq is **not** used by the receiver.
  * Jitter buffer: playback starts at 3 frames, at most 12 frames are kept, and streams are mixed
    with per-IP volume.
* **Transmit gating:** send only if not muted and either PTT (key held) or frame RMS > threshold
  (default 350), with a 300 ms hangover (L9641-9657).

## Appendix B – Option 9, port 9872 (one-paragraph summary)
Option 9 ("Server-Manager & Server Browser", `EarthLanNode` L7129-7560, UI L7570-8560) is a
separate mesh built exactly like the 9874 chat.
* The UDP beacon `PELAN1B|<id12>|<name>` goes to 255.255.255.255 and the subnet broadcast every 3 s
  (L7463-7472). It triggers a TCP connect.
* Each TCP connection starts with `HELLO|PELAN1|<id>|<name>\n`. There's no channel field; it's split
  into 4 fields (L7242-7246). Duplicates are resolved the same way.
* After the handshake, the only lines are `MSG|<text>` (group chat) and `SRV|<line>`
  (L7309-7319, L7476-7502). `SRV|<line>` shares up to 100 of the local game-server list lines
  (<1500 chars each), and is re-sent to each new peer and on every list change.
* Plain UTF-8 LF lines, no signing. The firewall rule is limited to the local subnet (L7677-7684).
