# Project Earth LAN Manager: Postfach (mailbox) protocol spec

Source: `/home/claude/cur.ps1` (version string `2026.09.23`, line 31). Every `Lnnnn` below is a line in that file.
The C# block is the here-string `$script:PelMailCode` (L2585–L3688). The classes are `EarthMailMsg`, `EarthMailStore`, `EarthMailCrypto` and `EarthMailNode`.

Test vectors and scripts are in `/tmp/claude-0/-home-claude/3a845a87-8c13-5824-8248-7ffc01cd2d48/scratchpad/tv/`:

| File | Purpose |
|---|---|
| `mail.cs` | The C# extracted verbatim from L2586–L3687 |
| `gen.ps1` | Generates `vectors.json`. It runs the original C# under pwsh 7 on Linux; DPAPI is not needed. |
| `vectors.json` | All vectors, reproduced in Appendix A |
| `sender_priv.xml`, `recipient_priv.xml` | Test RSA keys ("Alex-PC" sender, "Bob" recipient) |
| `verify.py` | A second, independent implementation using Python `cryptography`, standing in for Dart. It checks every vector (all PASS) and seals a message in the opposite direction, written to `reverse.json`. |
| `reverse.ps1` | Starts the original C# `EarthMailNode` on real TCP (127.0.0.2:9929) and sends it the Python-sealed message plus the MSG, KEY and garbage lines. Results: `OK`, `Verified=True`, `OK`, `DUP`, `KEY|...`, `ERR|format`. |

> **Important correction to the task description:** the Postfach protocol uses **no JSON anywhere**.
> - On the wire, messages are `|`-separated text lines with an HMAC suffix.
> - Payload fields are Base64-encoded UTF-8.
> - The encrypted inner plaintext, and every file on disk, use a `PEMSG1` "Key=Value" line format.
> - The mailbox has no attachments.

---

## 0. Architecture overview

- A peer's identity is its **IPv4 address**, normally its ZeroTier IP. There are no user IDs and no key fingerprints.
- Two transports are involved:
  - **UDP 9928 (`$script:PelStatusPort`, L83)**: the "Live-Status" broadcast `PESTAT1`. The mailbox uses it only for presence ("who is online"). It is sent by the Control Center (the dashboard), not by the mail code.
  - **TCP 9929 (`$script:PelMailPort`, L2579)**: the mail service. Each request uses one connection, carries one request line and gets one reply line (L3326).
- Every request line, the KEY reply and every PESTAT1 datagram carry an HMAC-SHA256 made with the shared network secret `$script:PelNetworkSecret` (L48). Simple replies (`OK`, `DUP`, `NOTME`, `ERR|…`) are **not** signed.
- There are two delivery paths:
  1. **Direct** (`MSG`): plaintext inside the TCP stream (ZeroTier provides link encryption). The receiver trusts the TCP source IP as the sender, so the message is always `Verified=1`.
  2. **Store-and-forward relay** (`RELAY`, then `SEALED`): runs if the recipient is offline.
     - The sender seals the message with RSA-2048-OAEP(SHA-1) plus AES-256-CBC plus HMAC-SHA256 (encrypt-then-MAC) for the recipient.
     - The sender signs it with RSA-PKCS#1 v1.5 SHA-256.
     - The sender hands copies to up to 3 other online managers ("holders"). A holder keeps its copy for at most 14 days and pushes it to the recipient when the recipient shows up.
- Public keys are fetched over TCP (`KEY` request) and stored per IP (TOFU, re-fetched after 24 h).
- Only one service runs per PC. It is guarded by the named mutex `Global\ProjectEarthLan_Postfach` (L3734) and lives in either the Control Center (L16494) or the Option 11 window (L15104, L15871). Option windows are separate processes (L15925ff).

---

## 1. Key material

### 1.1 Algorithm (L2941–L2975, L3697–L3725)
- **RSA 2048-bit**, created with `new RSACryptoServiceProvider(2048)` (L2958). The public exponent is 65537 (`AQAB`). `PersistKeyInCsp=false`, wrapped in try (L2952).
- Each installation has **one key pair**. It is used both for decrypting sealed messages (OAEP) and for signing (PKCS#1 v1.5 SHA-256).
- There is no ECDH and no key rotation. A new key is generated only if the key file is missing or unreadable, or the decrypted value doesn't contain `<D>` (L3713).

### 1.2 Key format: .NET `RSA.ToXmlString`
The same format is used on disk and on the wire (in the wire case, wrapped in Base64 again).

- **Public key** (`ToXmlString(false)`, L2960). No whitespace, no XML declaration. Element order is fixed:
  ```
  <RSAKeyValue><Modulus>B64</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>
  ```
- **Private key** (`ToXmlString(true)`, L2961). Element order:
  ```
  <RSAKeyValue><Modulus/><Exponent/><P/><Q/><DP/><DQ/><InverseQ/><D/></RSAKeyValue>
  ```
- Every value is a standard Base64 string (with padding) of an **unsigned big-endian** integer.
- .NET exports fixed-width values: Modulus = 256 bytes, D = 256 bytes, P, Q, DP, DQ and InverseQ = 128 bytes each. Leading zero bytes are kept.
- **Dart rules:**
  - When emitting a public key, write the Modulus as exactly 256 bytes with **no extra 0x00 sign byte**, and the Exponent as `AQAB` (3 bytes).
  - Windows peers load the key with `FromXmlString` into CAPI `RSACryptoServiceProvider`. A 257-byte modulus or a private key with non-fixed-width parts can fail there.
  - When parsing, use a tolerant regex such as `<Tag>([^<]*)</Tag>`.
- Peers accept a received public key only if it contains `<Modulus>` and does **not** contain `<D>` (L3666).

### 1.3 Own private key on disk: `C:\Project-Earth-Lan\keys\postfach_schluessel.dat` (L2580, L3699–L3725)
- The file is written by `Write-PelTextFileAtomic` (L936): UTF-8 without BOM, written to `<path>.tmp` first and then moved into place with `File.Replace`/`Move`.
- Content is a single line with one of two forms:
  - `DPAPI:` + Base64( `ProtectedData.Protect(UTF8(privateXml), entropy=null, DataProtectionScope.CurrentUser)` ) (L3719–L3720)
  - `PLAIN:` + privateXml. This is the fallback when DPAPI throws (L3721).
- On read, the file is `Trim()`med and the prefix is checked (L3703–L3710). If anything fails, a new key pair is generated and the file is overwritten.
- **DPAPI is Windows-only.** The DPAPI blob cannot be reproduced or tested on Linux, and it was bypassed in the test vectors.
  - This file is purely local and never goes on the wire, so interop does not depend on it.
  - A Dart app on Android, Linux or macOS should store its private XML (or its own format) in platform secure storage.
  - A Dart app on Windows can read and write the `DPAPI:` form through `CryptProtectData`/`CryptUnprotectData` via FFI (package `win32`), or write `PLAIN:`. The PowerShell code accepts both forms.
- The public key is always derived again from the private key (`PublicFromPrivate`, L2965, L3724).

### 1.4 Peer public keys: `C:\Project-Earth-Lan\Postfach\Schluessel\<ip>.key` (L2923–L2938)
- The filename is the IP with `:` replaced by `_`, then `.key`. The content is the public XML, UTF-8 without BOM.
- Key age is the file's LastWriteTime (L2930).
- **Key exchange is pull-only; keys are never announced.**
  - `FetchMissingKeys` (L3671–L3686) runs every 20 work ticks, roughly 20 s (L3549).
  - It covers every peer currently online (seen in PESTAT1 within 45 s) whose key file is missing or **older than 24 h**. Per IP it tries at most once every 5 min (L3681).
  - It sends a `KEY` request (§3.4) and **overwrites** the stored key with whatever comes back. There is no comparison with the previous key and no pinning, so trust rests only on the HMAC and the IP.
- **There is no fingerprint or ID derivation.** The only binding is IP ↔ key file.

---

## 2. Message encryption (relay path only): `EarthMailCrypto`

### 2.1 Signature (L2977–L2991, L3506–L3509, L3624)
```
SignText = Id + "|" + FromIp + "|" + ToIp + "|" + CreatedUtc(decimal) + "|" + Subject + "|" + Body
```
- The string is built from the raw field values. `Body` can contain `\n`. No escaping is applied.
- Signature = `Base64( RSA_PKCS1v15_Sign(SHA-256, UTF8(SignText)) )`, using `RSACryptoServiceProvider.SignData(bytes, "SHA256")`.
- The signature travels **inside** the sealed plaintext, in the field `Blob=` of the inner PEMSG1 record (L3624).
- The receiver checks it with the key stored for `inner.FromIp` (L3498–L3499). Result:
  - `Verified=1` if the key is known and the signature is valid.
  - `Verified=0` otherwise. The message is still accepted and stored.

### 2.2 Seal (L3001–L3040)

**Inputs:** `recipientPublicXml` and `plain`, a string (the PEMSG1 text of the inner message, §2.4).

1. Generate random values with `RandomNumberGenerator`: `aesKey` (32 bytes), `macKey` (32 bytes) and `iv` (16 bytes).
2. `wrapped = RSA-OAEP-Encrypt(recipientPub, aesKey ‖ macKey)`. The 64-byte plaintext uses `RSACryptoServiceProvider.Encrypt(data, fOAEP:true)`, which is **OAEP with SHA-1 and MGF1-SHA-1, empty label**. For a 2048-bit key, `wrapped` is 256 bytes.
3. `cipher = AES-256-CBC-Encrypt(aesKey, iv, PKCS7-pad(UTF8(plain)))`.
4. `mac = HMAC-SHA256(macKey, iv ‖ cipher)`. The MAC covers the IV and the ciphertext. It does not cover the header or `wrapped`.
5. Blob bytes:

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | version = `0x01` |
| 1 | 2 | `wl` = length of `wrapped`, **big-endian** uint16 (`0x0100` = 256) |
| 3 | wl | `wrapped` (RSA-OAEP ciphertext) |
| 3+wl | 16 | `iv` |
| 19+wl | 32 | `mac` (HMAC-SHA256) |
| 51+wl | rest | `cipher` (AES-CBC; length is a multiple of 16, at least 16) |

6. The result is `Convert.ToBase64String(blob)`: standard alphabet, padded, no line breaks.

### 2.3 Open (L3042–L3079)
1. Base64-decode the blob.
2. Require `b[0]==1` and `len >= 3 + wl + 16 + 32 + 16`.
3. RSA-OAEP(SHA-1) decrypt `wrapped`. The result must be exactly 64 bytes.
4. Verify the HMAC over `iv‖cipher` (constant-time compare). Do this **before** decrypting.
5. AES-256-CBC decrypt, remove PKCS7 padding, UTF-8 decode.

Any exception returns null, which the receiver reports as `ERR|decrypt`.

### 2.4 Sealed plaintext: the inner message
The inner message is `EarthMailStore.ToText(inner)` (L2714–L2739), where `inner` is a fresh `EarthMailMsg` (L3618–L3625). Only these fields are set:
- `Id`, `FromName`, `FromIp`, `ToIp`, `CreatedUtc`, `Subject`, `Body`
- `Blob` = the signature from §2.1

All other fields keep their defaults: `ToName` is empty and every number/bool is 0. Example (the test vector):
```
PEMSG1\n
Id=0123456789abcdef0123456789abcdef\n
FromName=Alex-PC\n
FromIp=10.147.20.5\n
ToName=\n
ToIp=10.147.20.9\n
Subject=Hallo Test\n
CreatedUtc=1790000000000\n
ReceivedUtc=0\n
DeliveredUtc=0\n
Read=0\n
Via=\n
Verified=0\n
Attempts=0\n
NextTryUtc=0\n
LastError=\n
Relayed=0\n
RelayedTo=\n
ExpiresUtc=0\n
Blob=<signature base64>\n
Body=Hallo Test\nZeile 2 mit Umlaut: äöü ß \\ Backslash\n
```
The `\n` inside `Body=` above is the two characters backslash and `n`; the real line breaks are the `\n` at line ends. See the PEMSG1 rules in §5.2. For interop, a Dart sender should emit exactly this key order and these defaults. The receiver only needs `Id`, `FromName`, `FromIp`, `ToIp`, `CreatedUtc`, `Subject`, `Body` and `Blob`, and parsing does not depend on order.

Receiver checks on the inner message (L3476–L3504):
- `inner.Id == outer id` and `inner.ToIp == outer toIp`. Otherwise the reply is `ERR|inner`.
- If `inner.FromIp` is not a valid canonical IPv4 address, or is banned, the message is **silently dropped**: the id is added to seen and the reply is `OK`.
- Sanitising:
  - `FromName = OneLine(…,40)`
  - `Subject = OneLine(…,100)`
  - `Body = Clean(…,4000)`
  - `CreatedUtc` is replaced by `now` if it is ≤ 0 or ≥ now + 24 h

### 2.5 .NET API → Dart (pointycastle) mapping

| .NET (used where) | Dart / pointycastle |
|---|---|
| `RSACryptoServiceProvider(2048)` keygen (L2958) | `RSAKeyGenerator()..init(ParametersWithRandom(RSAKeyGeneratorParameters(BigInt.from(65537), 2048, 64), secureRandom))` |
| `ToXmlString` / `FromXmlString` | Custom code: base64 of unsigned big-endian bytes, fixed widths (§1.2). The .NET names map as `P`→p, `Q`→q, `DP`→d mod (p-1), `DQ`→d mod (q-1), `InverseQ`→q⁻¹ mod p, `D`→private exponent. |
| `Encrypt(keys, true)` / `Decrypt(…, true)` (L3011, L3056) | `OAEPEncoding(RSAEngine())`. The default is SHA-1 with MGF1-SHA-1 and an empty label, which matches .NET. Use `init(true, PublicKeyParameter<RSAPublicKey>(pub))` to encrypt. |
| `SignData(bytes,"SHA256")` / `VerifyData` (L2980, L2988) | `RSASigner(SHA256Digest(), '0609608648016503040201')`, which is PKCS#1 v1.5 with the DigestInfo prefix, or `Signer('SHA-256/RSA')` |
| `Aes` CBC + PKCS7, 256-bit key (L3013–L3021) | `PaddedBlockCipherImpl(PKCS7Padding(), CBCBlockCipher(AESEngine()))`, initialised with `PaddedBlockCipherParameters(ParametersWithIV(KeyParameter(k), iv), null)` |
| `HMACSHA256` (L3024, L3160) | `HMac(SHA256Digest(), 64)..init(KeyParameter(key))`, or `package:crypto` `Hmac(sha256, key)` |
| `RandomNumberGenerator` (L3006) | `FortunaRandom` seeded from `Random.secure()`, or `Random.secure()` directly |
| `Convert.ToBase64String` | `base64.encode` (standard alphabet, padded) |
| `Encoding.UTF8` | `utf8.encode` / `utf8.decode(allowMalformed: true)` |
| `Guid.NewGuid().ToString("N")` (L2656) | 32 lowercase hex chars from 16 random bytes. Receivers only check `^[0-9a-f]{32}$`. |

---

## 3. Transport

### 3.1 HMAC-signed lines (L3158–L3181, also L55–L76)
```
Hmac(text) = Base64( HMAC-SHA256( key = UTF8(Secret), msg = UTF8(text) ) )   // 44 chars, ends with '='
Signed(core) = core + "|" + Hmac(core)
```
- `Secret` is `$script:PelNetworkSecret`. The compiled builds replace the placeholder at L48; the test vectors use `TestCode12345678`.
- To check a line, split at the **last** `|` into `core` and `sig`. Compare `sig` with `Hmac(core)` byte-for-byte as ASCII in constant time (L3169–L3178). Then `fields = core.Split('|')`, keeping empty fields, which matches Dart `split('|')`.
- There is no timestamp, nonce or replay protection at the HMAC level. The only replay defence is id dedupe.
- Test values:
  - `Hmac("") = 09RBrLqcgGmItiYPFJ4GUXjSCQzoed0DzT90rS4wEe0=`
  - `Hmac("abc") = 3edUm4o1RCgvgUDKFNXetHnWZvwQlIPIMS6DOkakFZo=`

### 3.2 Presence: UDP 9928 `PESTAT1` announcements
The mailbox has **no UDP packet of its own**. It reuses the Control Center's Live-Status broadcast.

**Sender** (Control Center; L16566–L16568, L16622–L16640, L16432–L16438, L16334):
- The heartbeat timer fires every 500 ms (`$statPoll.Interval = 500`). A packet goes out when `tick % 16 == 0`, i.e. **every 8 s**.
- It is sent to **255.255.255.255:9928** (`IPAddress.Broadcast`) from an unbound `UdpClient` with `EnableBroadcast`.
- Payload is UTF-8 with **no newline**:
  ```
  core = "PESTAT1|" + Name + "|" + OwnZtIp + "|" + ZtConnected(0/1) + "|" + FriendsOnline(int) + "|" + FriendsTotal(int) + "|" + Version + "|" + GameTitle + "|" + GameExe + "|" + JoinPort(int) + "|" + Server
  packet = core + "|" + Hmac(core)
  ```
- Field notes:
  - `Name` comes from `Get-PelDisplayName` (L962–L976): the Nick from `%APPDATA%\ProjectEarthLan\chat.json`, else COMPUTERNAME, with `|`, CR and LF replaced by spaces, trimmed, max 32 chars.
  - `OwnZtIp` is empty if ZeroTier is not connected.
  - Game fields use `|`→`/` and the title is limited to 48 chars. With no game they are `""`, `""`, `0`, `""`.
- Example (secret `TestCode12345678`):
  ```
  PESTAT1|Alex-PC|10.147.20.5|1|2|5|2026.09.23|||0||hDsuSJDDJl8LBYh+TGPrb32bLalf3DjMZn12MVe6ITs=
  ```
  Hex: `504553544154317c416c65782d50437c31302e3134372e32302e357c317c327c357c323032362e30392e32337c7c7c307c7c68447375534a44444a6c384c4259682b54475072623332624c616c6633446a4d5a6e31324d5665364954733d`
- Example with a UTF-8 name:
  ```
  PESTAT1|Jörg|10.147.20.7|1|0|3|2026.09.23|Minecraft|javaw.exe|25565||VJCwoa69tw0dY07vV65WG9bsgX3IPZMKAZpdM19LcoQ=
  ```

**Receivers:**
- **Control Center** (L16648–L16662):
  - Ignores packets whose source IP is one of its own IPs.
  - Requires ≥ 8 `|` parts including the signature and a valid HMAC.
  - Then calls `NotePeer(srcIp, f[1])`. The source IP of the UDP datagram is used, **not** the IP field in the packet.
- **Option 11 host** (C# `StatusLoop`, L3289–L3307; only when `ListenStatus`, i.e. hosted by Option 11, L3748):
  - Binds UDP `0.0.0.0:9928` with ReuseAddress.
  - Requires the prefix `PESTAT1|`, a valid HMAC and ≥ 7 core fields.
  - Then calls `NotePeer(ep.Address, f[1])`.

**`NotePeer(ip, name)`** (L3255–L3268):
- Ignores invalid IPs and local IPs.
- Stores `lastSeen = now` and `name = OneLine(name, 40)`.
- "Came online" means the peer was not seen for > 60 s. In that case the IP is **kicked**: pending Ausgang and Weiterleitung items for that IP are retried on the next work tick (~1 s) regardless of backoff (L3534–L3547).
- A received direct `MSG` with a non-empty FromName also calls `NotePeer` (L3435).

**Online** means seen within the last **45 s** (`GetOnlinePeers`, L3270–L3280). Entries are `"ip|name"`.

**What a Dart peer must do to count as "online":**
- Broadcast a valid PESTAT1 at least every ~8 s, at most 45 s apart.
- Use at least the first 7 core fields plus the signature. For Control Center compatibility, send all 11 core fields.
- Listen on UDP 9928 to learn who is online.

### 3.3 TCP framing (L3326–L3400)
- The client connects to `ip:9929`: connect timeout 2500 ms, send and receive timeouts 8000 ms (L3349–L3366).
- The client sends **one line**: `UTF8(text) + 0x0A`. The server replies with **one line** `UTF8(reply) + 0x0A` and closes the connection.
- There is no length prefix and no byte-order concern. The only framing is `\n`.
- `ReadLine`:
  - Reads byte by byte until LF.
  - Drops every CR (0x0D).
  - Gives up at more than **70000 bytes**: the server then closes without replying.
  - Returns null on EOF with no bytes.
- **Server gate** (L3383–L3400): `::ffff:` is stripped from the remote IP. If the IP is **banned** (see §5.6) or exceeds the **rate limit of 40 connections per IP per 60 s** (L3240–L3252), the socket is closed **without a reply**. The client sees null, which it treats as offline.
- A client that gets no or invalid reply lines treats the peer as offline.
- The listener binds `0.0.0.0:9929` (L3093, L3125). The Windows firewall rule allows TCP 9929 inbound only from `RemoteAddress LocalSubnet` (L3753–L3754). UDP 9928 has the same rule (L16346).

### 3.4 Request/response types (`Process`, L3403–L3474)
Every request must start with `PEMAIL1|`, carry a valid HMAC and have at least 3 fields. Otherwise the reply is `ERR|format`. `f[1]` is the kind.

**A. KEY: fetch public key** (L3409–L3413, client L3659–L3669)
- Request: `Signed("PEMAIL1|KEY|" + 8 random hex)`. The nonce is `Guid N`[0..8] and is not checked.
- Reply: `Signed("KEY|" + Base64(UTF8(PublicKeyXml)))`, or `ERR|nokey`.
- The client requires the prefix `KEY|`, a valid HMAC and ≥ 2 fields. It checks that the XML contains `<Modulus>` and not `<D>`, then saves it to `Schluessel\<ip>.key`.

**B. MSG: direct delivery** (L3414–L3438; built by `BuildMsgLine` L3555–L3558)
```
PEMAIL1|MSG|<id>|B64(FromName)|<ToIp>|<CreatedUtc>|B64(Subject)|B64(Body)|<hmac>
```
- `B64` is Base64 of UTF-8 (L3183). **ToName is not sent. FromIp is not sent**: the receiver uses the TCP source IP.
- Requires ≥ 8 core fields.
- Receiver steps, in order:
  1. id matches `^[0-9a-f]{32}$`, else `ERR|id`
  2. ToIp is a local IP of the receiver, else `NOTME`
  3. id already seen, then `DUP`
  4. Store in Eingang with `Via="direkt"` and `Verified=1`; on failure `ERR|save`
  5. AddSeen, then `OK`
- Base64 decode failures produce `""`. Sanitising: `FromName=OneLine(…,40)`, `Subject=OneLine(…,100)`, `Body=Clean(…,4000)`. The CreatedUtc sanity check is the same as in §2.4.

**C. RELAY: sender hands a sealed copy to a holder** (L3439–L3464; built L3628–L3629)
```
PEMAIL1|RELAY|<id>|<ToIp>|<CreatedUtc>|<ExpiresUtc>|<blobB64>|<hmac>
```
- The sender sets `ExpiresUtc = now + 14*86400000`.
- Requires ≥ 7 core fields, a valid id and a valid IP (else `ERR|id`), and `blob.Length ≤ 30000` chars (else `ERR|size`).
- If ToIp is one of the holder's own IPs, the holder opens it itself as SEALED with an empty holder name.
- If `Weiterleitung\<id>.msg` already exists, the reply is `OK` (idempotent).
- If ≥ 300 relay files exist, the reply is `ERR|full`.
- Otherwise the holder saves a relay record with these fields, then replies `OK`:
  - `FromIp` = remote IP
  - `CreatedUtc` = f[4], or now if ≤ 0
  - `ReceivedUtc` = now
  - `ExpiresUtc` = f[5] if `now < f5 < now+14d`, else `now+14d`
  - `Blob` = the blob
  - `NextTryUtc` = now + 3000
- The holder **cannot read the content**.

**D. SEALED: holder (or sender) delivers a sealed copy to the recipient** (L3465–L3472; built L3647)
```
PEMAIL1|SEALED|<id>|<ToIp>|<blobB64>|B64(HolderName)|<hmac>
```
- Requires ≥ 5 core fields. `HolderName` (f[5]) is optional.
- Steps: id valid (else `ERR|id`); ToIp local (else `NOTME`); then `OpenSealed` (L3476–L3504), which returns:
  - `DUP` if the id was already seen
  - `ERR|nokey` if the receiver has no private key
  - `ERR|decrypt` if opening fails
  - `ERR|inner` if the inner Id or ToIp don't match
  - `OK` if stored in Eingang with `Via = "weitergeleitet über <holder> (<remoteIp>)"`, or `"weitergeleitet über <remoteIp>"` when no holder name is known. The holder name falls back to the name learned from PESTAT1. `Verified` comes from §2.1.

**Replies:** `OK`, `DUP`, `NOTME`, `ERR|format`, `ERR|id`, `ERR|size`, `ERR|full`, `ERR|save`, `ERR|nokey`, `ERR|decrypt`, `ERR|inner`, `ERR|kind`. They are unsigned, a single line ending in `\n`. Only the KEY reply is signed.

### 3.5 Sender state machine (`WorkLoop`/`WorkOnce`/`DeliverOutgoing`, L3511–L3600)
- The work loop runs `WorkOnce` about **every 1 s**: it sleeps 10 × 100 ms (L3519–L3528).
- **Ausgang:** every message with `NextTryUtc ≤ now`, or whose ToIp was kicked, gets a delivery attempt. `New-PelMailOutgoing` saves the message with `NextTryUtc=0` and kicks its IP (L3787–L3805), so a new message goes out within about 1 s.
- If `ToIp` is invalid: `LastError` is set and the next try is in 1 h.
- A `MSG` line is sent, and the reply decides what happens next:

| Reply | Action |
|---|---|
| `OK` or `DUP` | Set `DeliveredUtc=now` and `Via="direkt"` if empty. If the Ausgang file still exists, save to **Gesendet** and delete the Ausgang file. Emit event `SENT`. |
| `NOTME` | Attempts++. Retry in 10 min. |
| `ERR…` | Attempts++. Retry in 10 min. |
| null (unreachable, timeout, closed, banned, rate limited) | Attempts++. `NextTryUtc = now + Backoff(Attempts)`, where Backoff is `15 s, 30 s, 60 s, 2 min, 5 min, 10 min` and stays at 10 min after that (L3512–L3517). If not yet `Relayed`, call **TryRelay**. |

- The Ausgang has **no expiry**: it retries forever until the user deletes the message ("Senden abbrechen").
- Every update uses `SaveIfExists`, so a message the user deleted is not recreated (L2812).

**TryRelay** (L3605–L3642):
1. Needs the sender's own private key and a stored key for `ToIp`.
2. Candidate holders are the online peers other than `ToIp` and other than local IPs, shuffled with Fisher-Yates.
3. The sender builds the inner message, signs it (§2.1), seals it (§2.2) and sends a RELAY line (§3.4C) to the holders one by one, stopping after `MaxRelayHolders = 3` `OK` replies.
4. If at least 1 holder accepted, it sets `Relayed=1` and `RelayedTo` to the holders' names or IPs joined with `", "`. It does not relay again after that.
5. Each holder copy is the same blob. It is sealed once per TryRelay call.
6. Direct delivery attempts continue in parallel. Dedupe via `empfangen.ids` prevents duplicates.

**Holder loop** (Weiterleitung: L3542–L3548, `DeliverRelay` L3644–L3657):
- Expired records (`ExpiresUtc < now`) are deleted.
- For a record that is due or kicked, the holder sends `SEALED` with its own `MyName`, which is the display name (L3747, refreshed at L16618).
- It **deletes** the record on `OK`, `DUP`, `NOTME`, `ERR|decrypt…` or `ERR|inner…`.
- Otherwise (null, `ERR|nokey`, `ERR|save`, …): Attempts++ and `NextTryUtc = now + max(30 s, Backoff)`.

### 3.6 Dedupe: `Postfach\empfangen.ids` (L2873–L2921)
- The file holds ASCII lines of 32-hex ids, written with `AppendAllText(id+"\n")`.
- In memory, the set = valid ids from the file plus the basenames of the `Eingang\*.msg` files.
- `DUP` is checked before storing a MSG or SEALED message. After a successful store the id is added.
- A dropped message from a banned or invalid sender is also added (L3484).
- If the set grows beyond 6000, the file is rewritten with only its last 5000 lines. `File.WriteAllLines` is used, so on Windows the line endings become **CRLF**. Readers must `trim()` each line.
- Because the file keeps ids of deleted messages, a deleted message does not come back through a relay.

### 3.7 Local "online" file: `Postfach\online.txt` (L3309–L3324)
- The service host writes it at most every 4 s during `WorkOnce`: UTF-8 without BOM, lines `ip|name\n` for the peers online (< 45 s). It is written to `online.txt.tmp` first, then replaced.
- It is deleted on `Stop()` (L3152).
- Other windows on the same PC read it only if it is fresher than 30 s (L3809–L3819, L15536–L15542).
- It is **local IPC only**, not a protocol element.

---

## 4. Every message type, with examples
All examples come from `vectors.json` (secret `TestCode12345678`, sender Alex-PC 10.147.20.5, recipient Bob 10.147.20.9, holder Carol-PC 10.147.20.3, id `0123456789abcdef0123456789abcdef`, CreatedUtc `1790000000000`).

| # | Type | Transport | Example |
|---|---|---|---|
| 1 | PESTAT1 presence | UDP broadcast 9928 | `PESTAT1\|Alex-PC\|10.147.20.5\|1\|2\|5\|2026.09.23\|\|\|0\|\|hDsuSJDDJl8LBYh+TGPrb32bLalf3DjMZn12MVe6ITs=` |
| 2 | KEY request | TCP 9929 | `PEMAIL1\|KEY\|a1b2c3d4\|4mN4IRwMvdOj+JVNAzv3KrilhTyQBv9q/8t0ZJl6meU=` |
| 3 | KEY reply | TCP reply | `KEY\|PFJTQUtleVZhbHVl…PC9SU0FLZXlWYWx1ZT4=\|Yhu2juhnUhGxbCSFG2r4VokIgd8c1DapPotEuxwOACc=` (full value in App. A) |
| 4 | MSG | TCP 9929 | `PEMAIL1\|MSG\|0123456789abcdef0123456789abcdef\|QWxleC1QQw==\|10.147.20.9\|1790000000000\|SGFsbG8gVGVzdA==\|SGFsbG8gVGVzdApaZWlsZSAyIG1pdCBVbWxhdXQ6IMOkw7bDvCDDnyBcIEJhY2tzbGFzaA==\|XNtNPKOPLAMpR9xs/fmkdtKeg1d8nANVSKSJbQhbf04=` |
| 5 | RELAY | TCP 9929 | `PEMAIL1\|RELAY\|<id>\|10.147.20.9\|1790000000000\|1791209600000\|<blob>\|Uy4B8VjPjt6YmsFJesTrwRmmr9TECb9McVmVwB+2yFM=` |
| 6 | SEALED | TCP 9929 | `PEMAIL1\|SEALED\|<id>\|10.147.20.9\|<blob>\|Q2Fyb2wtUEM=\|sTo6Veg2g2mlXqz/hVSvAc4zBPC8BJdVzxxBdziE2c0=` |
| 7 | Replies | TCP reply | `OK`, `DUP`, `NOTME`, `ERR\|…` (each followed by `\n`) |

Exact MSG bytes on the wire, including the terminating LF, are in `msg_line_bytes_hex` in Appendix A. For MSG the body is `"Hallo Test\nZeile 2 mit Umlaut: äöü ß \\ Backslash"` (real LF, real backslash).

Results observed when running the original C#:
- MSG, first time: `OK`; the same MSG again: `DUP`.
- SEALED with the same id after direct delivery: `DUP`.
- Tampered HMAC: `ERR|format`.
- ToIp not local: `NOTME`.
- SEALED with a new id: `OK`, stored `Verified=1`, `Via=weitergeleitet über Carol-PC (10.147.20.3)`.
- RELAY at the holder: `OK`, with a Weiterleitung record written (App. A `holder_relay_file`).
- Python-sealed SEALED sent over real TCP to the C# node: `OK`, `Verified=True`. **Seal/sign interop works in both directions.**

---

## 5. On-disk layout: `C:\Project-Earth-Lan\Postfach\` (L2630–L2643)
```
Postfach\
  Eingang\<id>.msg        received messages (Inbox)
  Ausgang\<id>.msg        pending outgoing messages (Outbox)
  Gesendet\<id>.msg       delivered messages (Sent)
  Weiterleitung\<id>.msg  relay copies held for others (FromIp=sender, Blob=sealed blob, ExpiresUtc)
  Schluessel\<ip>.key     peer public keys (XML)
  empfangen.ids           seen ids
  online.txt              presence list (local IPC)
C:\Project-Earth-Lan\keys\postfach_schluessel.dat   own private key (DPAPI/PLAIN)
C:\Project-Earth-Lan\ip_bans.json                   ban list (read by the service, L3217)
```
`EnsureDirs` creates Root, Eingang, Ausgang, Gesendet, Weiterleitung and Schluessel (L2647–L2653).

### 5.1 File writes
- `Save` (L2793–L2808) writes UTF-8 **without BOM** to `<id>.msg.<8hex>.tmp`, then `File.Replace` (or `Move`) to `<id>.msg`. Only ids matching the regex are written.
- Reads use UTF-8 (L2785).

### 5.2 PEMSG1 record format (`ToText`/`FromText`, L2714–L2779)
- The first line is `PEMSG1`. Then come these keys, **in this order**, each as `Key=Value\n`:
  `Id, FromName, FromIp, ToName, ToIp, Subject, CreatedUtc, ReceivedUtc, DeliveredUtc, Read, Via, Verified, Attempts, NextTryUtc, LastError, Relayed, RelayedTo, ExpiresUtc, Blob, Body`
- Line endings are LF only.
- Booleans are written as `1`/`0`. Longs are decimal Unix epoch **milliseconds UTC** (`Now()`, L2645); 0 means unset.
- **Escaping** (`Esc`, L2682–L2694) applies to string values: `\` → `\\`, LF → `\n` (backslash n), CR removed.
- **Unescaping** (`Unesc`, L2696–L2712): `\n` → LF, `\\` → `\`. Any other backslash sequence is kept literally.
- **Parsing:**
  - The text must start with `PEMSG1`.
  - Split on LF and trim a trailing CR from each line.
  - Split each line at the first `=`; lines where `=` is at position ≤ 0 are skipped. Unknown keys are ignored.
  - A record whose `Id` does not match `^[0-9a-f]{32}$` is rejected (null).
- Field meanings (class `EarthMailMsg`, L2603–L2626):
  - `Via`: `"direkt"`, or `"weitergeleitet über …"`
  - `Verified`: inbox only
  - `Attempts`, `NextTryUtc`, `LastError`, `Relayed`, `RelayedTo`: outbox and relay records
  - `ExpiresUtc`: relay records
  - `Blob`: sealed blob in relay records, signature in the sealed inner record, empty otherwise
  - `FilePath`: in memory only, never serialised
- A sample inbox file (direct) is in App. A `recv_inbox_file_direct`.

### 5.3 Limits and sanitisers (L2631–L2680)
Lengths are counted in UTF-16 code units, the same as Dart `String.length`. `Substring` may cut a surrogate pair; mirror that behaviour or truncate safely.

- `MaxSubject = 100`, `MaxBody = 4000`, names 40 (in Get-PelDisplayName, 32).
- `OneLine(s,max)`: CR and LF → space, `|` → `/`, `Trim()`, truncate.
- `Clean(s,max)`: remove CR, truncate.
- `IsValidIp`: IPv4 only, and it must be canonical (`IPAddress.ToString()==input`, so no leading zeros) (L2658–L2664).

### 5.4 Sending side (`New-PelMailOutgoing`, L3787–L3805)
- `Id = Guid N`.
- `FromName` = display name.
- **`FromIp = Get-PelSourceIpFor(ToIp)`** (L3776–L3783): the local IP the OS would route to the recipient, found with a UDP "connect". The value is only used in the sealed inner record and the signature text, and the recipient uses it to pick the sender's key. A Dart sender must put the IP here under which the recipient knows it: the IP the recipient sees as TCP source and PESTAT1 source, i.e. its ZeroTier IP.
- `ToName = OneLine(40)`, `Subject = OneLine(100)`, `Body = Clean(4000)`, `CreatedUtc = now`, `NextTryUtc = 0`.
- The message is saved to Ausgang and its IP is kicked.

### 5.5 Option 11 UI behaviour that affects data (L15093–L15920)
- The service is started on open (L15104). Every 5 s the window tries to take over the service if nobody hosts it (L15871). The service stops when the window closes (L15914–L15917).
- The window polls every 1 s (L15865–L15904): it drains `NEW|` events, then uses `EarthMailStore.Signature()` (L2855) to detect folder changes.
- **Compose** (`Show-O11Compose` L15592–L15690):
  - The recipient is taken from the first IPv4 address in the combo text, and it must be a valid IP.
  - Subject or body must be non-empty.
  - Sending to one of the PC's own IPs is refused. A banned recipient needs confirmation.
  - The name comes from the friend list, else the online name.
- **Reply** (L15694–L15704):
  - Subject gets `AW: ` unless it already matches `^(AW|Re):`, then is truncated to 100.
  - Body: `"\r\n\r\n--- <FromName> schrieb am dd.MM.yyyy HH:mm: ---\r\n" + "> "`-prefixed quoted lines, truncated to 4000. The CRs are removed later by `Clean`.
- Opening an inbox message sets `Read=1` through `SaveIfExists` (L15572–L15580). "Mark unread" sets it back (L15718–L15726).
- Deleting a file deletes the message (L15707–L15717). An id deleted from Eingang stays in `empfangen.ids`, so it will not come back.
- The status column shows `(unbestätigt)` when `Verified=0` (L15383).

### 5.6 Bans (L3217–L3238)
- `C:\Project-Earth-Lan\ip_bans.json` is searched for the literal `"Ip":"<ip>"`. This relies on compact JSON with no spaces.
- A match counts unless the text up to the next `"Ip":"` contains `"Deleted":true`.
- Banned IPs get their TCP connection closed silently. A sealed message whose inner FromIp is banned is dropped (the reply is `OK`).

---

## 6. Interop checklist for the Dart implementation
1. Listen on **TCP 0.0.0.0:9929**. Read one LF-terminated line (drop CR, max 70000 bytes), answer one line plus LF, then close. Rate-limit to 40 connections per IP per minute and close silently when exceeded.
2. Broadcast **PESTAT1** to 255.255.255.255:9928 every 8 s. Listen on UDP 9928 with reuseAddress. Treat a peer as online while it was seen within 45 s; a peer not seen for more than 60 s counts as newly online, which triggers immediate retries.
3. Use HMAC-SHA256 with key `UTF8(secret)` and Base64 output, appended after the last `|`.
4. Keys: RSA-2048 with e=65537, in .NET XML format using fixed-width unsigned big-endian Base64. Fetch peer keys with `KEY` when they are missing or older than 24 h, at most once per 5 min per IP.
5. Seal: `01 | len16BE | RSA-OAEP-SHA1(aesKey32‖macKey32) | iv16 | HMAC-SHA256(macKey, iv‖ct) | AES-256-CBC-PKCS7(ct)`, then Base64.
6. Sign: RSA PKCS#1 v1.5 SHA-256 over `Id|FromIp|ToIp|CreatedUtc|Subject|Body` (UTF-8). Put it in `Blob=` of the inner PEMSG1 record.
7. The inner plaintext must be the PEMSG1 text with the exact escaping from §5.2.
8. Replies and state transitions must match §3.4 and §3.5. That includes answering `DUP` for known ids, `NOTME` for foreign ToIp, and the relay limits (30000-char blob, 300 files, 14 days).
9. Ids are 32 lowercase hex characters. Timestamps are Unix milliseconds UTC as decimal strings.

## 7. Caveats observed
- Direct `MSG` is authenticated only by the shared network secret and the TCP source IP. It is not end-to-end encrypted, because it relies on ZeroTier.
- Keys are TOFU and are overwritten every 24 h without a change check, so an attacker who knows the secret and can spoof an IP could replace a key.
- On Windows .NET Framework, `RSACryptoServiceProvider.SignData(…,"SHA256")` needs a CSP that supports SHA-256. If it throws, `TryRelay` silently skips relaying (catch at L3627). This is a Windows-side risk; it did not show up under .NET 7 on Linux.
- The relay HMAC covers only `iv‖cipher`, not the version byte or the wrapped key. The wrapped key is protected by OAEP and a key-length check.
- `recv_*` timestamps in the vectors (`ReceivedUtc`, `NextTryUtc`) are from generation time. Seal output is random per run: re-running `gen.ps1` keeps the keys but produces a new blob.

---

## Appendix A: vectors.json (verbatim)
Private keys for decryption: `recipient_private_xml` opens `sealed_blob_b64`, and `sender_public_xml` verifies `signature_b64`. The unwrapped AES and MAC keys, IV, MAC and ciphertext are given in hex so each layer can be checked on its own.

```json
{
  "sender_private_xml": "<RSAKeyValue><Modulus>rRBErlYu/43+b8hpmEnSFPI+WNcc7Z/rKBL62W8djdl5YKZe4Bxxs7aBBgQJyfphf+DEPw4STFg/19eMsHVEQ2AQ5yvrnGOQyCovC6QL6XMbTV1N4bIbjKkxXROC2qZ5UJ9YkW6lcSH0KkTrHchDjIIm/WW0z+bObOSpmPAdFAkgi6N6mG/hLQPQFm2W3uVamVyCbrO6Xas4UY7UGFzplgwy0qn7lMOtdWc2wkiHrc4dBM8HkkE4F0mrC1yWwhNCDJR6+2CaFKINKHWMwDaRmPu6sjeVVQGsE3hy+50Y8VZd/6PKHPrAbJEZ65zodg6OUKt118K/cZOGoMR0AqnxNw==</Modulus><Exponent>AQAB</Exponent><P>3PBBcXAb2PsS8N/ywoqDvTBhua0zuPGrW4iwUdMBkjiXY9Vik0iE49GypPRGVlCrRwIIbA/id8hiUxKhaQcS08YRJph+4NbYTLc96zBItdLU2PFfJ1DuKasYqigbgUKEaRMZa9Q/W3YrrAkBjMhzzwuLs2HrIUEQyvtmc6rYurE=</P><Q>yIcRNr7l919z1v/KuJiEXtkKSOVAXDg+PEV2mDr3RTsk4ty3jrLXk0krBs5pDXmoViMcJd8D/Cn7YsWdUslv3f/mZW+barIIXuqAURkrBZJrcMDex2tkZkfj7hGKMp1jnuG9kVzMUGLsSUdCWQAz5wQUq+6a+Dy1ge0UEAsxFGc=</Q><DP>zIw22pJDhfB1icKcm1XoP8jCQUhEoY5E6nqzWx3yz3BLYOdW2ysBtXYYYbWyRQlseVI9f+Z48hL4TRbrjzQ4Tw6KJGR82yatnODtl4fdWVD3NF7LjLfVt4grTqXRSSvPMQS4vWcEvWW7awvvfmq7JU34KbyXFvOJW5PDN4VOIBE=</DP><DQ>cVF6ldBdDmTfhnD4c0alDyBhon4C19pkuRScBzzTPUlF9/m4tSg1kKL5cJg2X4oPadXfcztK+jYTPGbmF8GDuRWCcnIWhr3i4xhruOibGkP6+TXU7yauDuqzUHaS/TVZ9ZAl2z5wq0CrvGFLihYGPpdcwyhMZNmRzMFX5BUfACM=</DQ><InverseQ>gyYMtOVPWMr7vzF1PWEmYxSgRweWQw7z/WoEx+sYX3PbMdSkSWwu0rNOtV/eveFORvrUlJWXHaZ5ugQ92nYSrj9qh3cwMMjTKMwtT+7oY75moU7N4GCaadIXwTa26cTlF8iGBfXLSqng9LlIAi2Wk50D7Q9U3OW9EOx4Ust3H0Y=</InverseQ><D>A1V5ZTxeymiDWsbrFdZyOBoUjmSSd5dpkcuPzol/8cAbQPvjfwC9Rf+Bi8qfH6d1ol+DmE1el97pV/CckrenmX6rxLBJaSlX3CtH3bsKybQAdiSSgAMM2dBWlZrvHeQwGRgAvkh54myLhhbuypOVjYriUmZXrdud5WYgSERz4vNj8Re/fe1zYIKtGlSZLCzObDpvVCBbv9v+ihmB3jJgUQ3mGBh9UiG1X9gfd94M3XB6LyZa/sscVTPAdPwhwB6PUPTr+37Cu5l9lflJEQie1L9LJXs7NNzGt297XtoztbrA6JNabT8dT9v5Ew8LaKi/CL28cN1/uuscrgqqmOdK0Q==</D></RSAKeyValue>",
  "sender_public_xml": "<RSAKeyValue><Modulus>rRBErlYu/43+b8hpmEnSFPI+WNcc7Z/rKBL62W8djdl5YKZe4Bxxs7aBBgQJyfphf+DEPw4STFg/19eMsHVEQ2AQ5yvrnGOQyCovC6QL6XMbTV1N4bIbjKkxXROC2qZ5UJ9YkW6lcSH0KkTrHchDjIIm/WW0z+bObOSpmPAdFAkgi6N6mG/hLQPQFm2W3uVamVyCbrO6Xas4UY7UGFzplgwy0qn7lMOtdWc2wkiHrc4dBM8HkkE4F0mrC1yWwhNCDJR6+2CaFKINKHWMwDaRmPu6sjeVVQGsE3hy+50Y8VZd/6PKHPrAbJEZ65zodg6OUKt118K/cZOGoMR0AqnxNw==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>",
  "recipient_private_xml": "<RSAKeyValue><Modulus>67xbT5qpp9v77U1wUGKyGNlsE2rRETo9RQ8/cpIMbE0F3ivmYEMuJAE7NSeJ+whCYshqFHYBgsUz5JjQaK+HK6ah0BW6MlGutSRidBPTCIxzShLHZuSGW0U4r9jkXlYcjBKs37/YvKPwstd1Q23OumtlsJp/dSph3D8wtiZ5UaQunnj44xA4NVOO0VAR1ref5t67iYtnvt0tccYGn9vkqPCesfPy2NJUihaSgphxnCkmb/xdaDJbomNiPa4bwKL03/BdzpXEvegFTWH6hIEZM5jCOeKRWMjPDlXLWegojiHF597PUZf7IEmaeOh63Jx0er2d+hit5aRsDcVHzKCSCQ==</Modulus><Exponent>AQAB</Exponent><P>/L6YLHHNYN98mTk4tFbeac2BGY72SNO4rG5HT5yX4+h7VC0fJZkKsED8rYwdT+MGRFvg7csR5dePoCeKCeikFicsCrWM5tJ+ORyHcsO3R1XZqmNebG3AseHakbJuAcfpiRtJzxqiUpRdLqcLgc0Vhw46l3zK0sYi/pTWKSUB9Fc=</P><Q>7sWtX5kK3cgk4JoZfNLa0BgwNToNJwEd5wX6VvTu2eu+DM+lrUijzlqhKdpNIgrqqC8Y/DsAN8gqG0RQtiKYjyXcG+FTLj0cJG6lhn8bx2x6iLqJ1bMWClBpWpVvtwrXNs/TWWCiZ4z1qrncHN3MdsPuzjThy1ADnMFWeBZCsJ8=</Q><DP>1HSaknGvRMlYgax6IA4NtD6NUSC9ooZm7Hte8msduvUIBsBPOFmnhHV8cZ4gXbDm6buaHgnfp6dGEkhqXt3yYLTY7r+iC73RYMy8hxpCDHL8H6CcFOVFX8IM6wBkPJcBlsEbkD5BSM1ybu74W0o72GV7ly/NhtQLQpl2VOvI8s0=</DP><DQ>edUjwcO1Z7TYHEKE/swYGlY9Qut8CornVxoVwoj31voS3zaUsvZ9nq1fzps1AEnRsj9V4F26nrvjwEX7aPP+JAyNYyx15QIJeg17KEVzRy5y15FXA1N9y4V8PFxDxIIjjjQ9Az3roCqsr5BmX9RMn80Z7N3O2I7bSQDdviidnsE=</DQ><InverseQ>GVzc9UEIXnfC/GmS0XK2QRQTRRJ9hCxvIqUsyw/Bh6tM3d3X3R/HFXCwsnnebcUew7aVNEDGJxcFspmZ9sNDeyu0zebUn7SLQRDsSMUF0YFY+lUcEa9odUosglya9Y28lWSN3sTjNoiNDAHRJT1LeRpKa5wHbJK5ShONKEhhiyg=</InverseQ><D>CbeedfYUp0A4rswB5LZkzARuYZCGJLUnYGjj/yeJDo/QPZvGp9ItHTvVwneqRuhMwECtqsFAh7D0Vih8csxFgKWiRu8WWUunrXzd+BX3HYOYnwWOJa4m4a1FTG5e34qiK537dU+1sfT6D401Hr3whxu1OeXsehpwpUEPk3qbhqNvK63R/0mzZkVgeyXTdJ4Z+1Nxh7AzJnj2MQ6bXQviiWMyTn0uTqQyBd4BLISy5O4ZaNjEg9d7ZuWyZDTXs28PuakL2aaKIt+9mhJQRnJTqN6gHZGgYVh/sYWlEdvPRkSWGBitdWlCJSBrzj7+1Kfwizts5INb1XxEtcS7nQNSjw==</D></RSAKeyValue>",
  "recipient_public_xml": "<RSAKeyValue><Modulus>67xbT5qpp9v77U1wUGKyGNlsE2rRETo9RQ8/cpIMbE0F3ivmYEMuJAE7NSeJ+whCYshqFHYBgsUz5JjQaK+HK6ah0BW6MlGutSRidBPTCIxzShLHZuSGW0U4r9jkXlYcjBKs37/YvKPwstd1Q23OumtlsJp/dSph3D8wtiZ5UaQunnj44xA4NVOO0VAR1ref5t67iYtnvt0tccYGn9vkqPCesfPy2NJUihaSgphxnCkmb/xdaDJbomNiPa4bwKL03/BdzpXEvegFTWH6hIEZM5jCOeKRWMjPDlXLWegojiHF597PUZf7IEmaeOh63Jx0er2d+hit5aRsDcVHzKCSCQ==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>",
  "hmac_of_empty": "09RBrLqcgGmItiYPFJ4GUXjSCQzoed0DzT90rS4wEe0=",
  "hmac_of_abc": "3edUm4o1RCgvgUDKFNXetHnWZvwQlIPIMS6DOkakFZo=",
  "pestat_core": "PESTAT1|Alex-PC|10.147.20.5|1|2|5|2026.09.23|||0|",
  "pestat_packet": "PESTAT1|Alex-PC|10.147.20.5|1|2|5|2026.09.23|||0||hDsuSJDDJl8LBYh+TGPrb32bLalf3DjMZn12MVe6ITs=",
  "pestat_packet_hex": "504553544154317c416c65782d50437c31302e3134372e32302e357c317c327c357c323032362e30392e32337c7c7c307c7c68447375534a44444a6c384c4259682b54475072623332624c616c6633446a4d5a6e31324d5665364954733d",
  "pestat_packet_umlaut": "PESTAT1|Jörg|10.147.20.7|1|0|3|2026.09.23|Minecraft|javaw.exe|25565||VJCwoa69tw0dY07vV65WG9bsgX3IPZMKAZpdM19LcoQ=",
  "msg_line": "PEMAIL1|MSG|0123456789abcdef0123456789abcdef|QWxleC1QQw==|10.147.20.9|1790000000000|SGFsbG8gVGVzdA==|SGFsbG8gVGVzdApaZWlsZSAyIG1pdCBVbWxhdXQ6IMOkw7bDvCDDnyBcIEJhY2tzbGFzaA==|XNtNPKOPLAMpR9xs/fmkdtKeg1d8nANVSKSJbQhbf04=",
  "msg_line_bytes_hex": "50454d41494c317c4d53477c30313233343536373839616263646566303132333435363738396162636465667c5157786c6543315151773d3d7c31302e3134372e32302e397c313739303030303030303030307c53474673624738675647567a64413d3d7c53474673624738675647567a644170615a576c735a53417949473170644342566257786864585136494d4f6b77376244764344446e79426349454a685932747a6247467a61413d3d7c584e744e504b4f504c414d70523978732f666d6b64744b65673164386e414e56534b534a625168626630343d0a",
  "key_request_line": "PEMAIL1|KEY|a1b2c3d4|4mN4IRwMvdOj+JVNAzv3KrilhTyQBv9q/8t0ZJl6meU=",
  "key_reply_line": "KEY|PFJTQUtleVZhbHVlPjxNb2R1bHVzPnJSQkVybFl1LzQzK2I4aHBtRW5TRlBJK1dOY2M3Wi9yS0JMNjJXOGRqZGw1WUtaZTRCeHhzN2FCQmdRSnlmcGhmK0RFUHc0U1RGZy8xOWVNc0hWRVEyQVE1eXZybkdPUXlDb3ZDNlFMNlhNYlRWMU40YkliaktreFhST0MycVo1VUo5WWtXNmxjU0gwS2tUckhjaERqSUltL1dXMHorYk9iT1NwbVBBZEZBa2dpNk42bUcvaExRUFFGbTJXM3VWYW1WeUNick82WGFzNFVZN1VHRnpwbGd3eTBxbjdsTU90ZFdjMndraUhyYzRkQk04SGtrRTRGMG1yQzF5V3doTkNESlI2KzJDYUZLSU5LSFdNd0RhUm1QdTZzamVWVlFHc0UzaHkrNTBZOFZaZC82UEtIUHJBYkpFWjY1em9kZzZPVUt0MTE4Sy9jWk9Hb01SMEFxbnhOdz09PC9Nb2R1bHVzPjxFeHBvbmVudD5BUUFCPC9FeHBvbmVudD48L1JTQUtleVZhbHVlPg==|Yhu2juhnUhGxbCSFG2r4VokIgd8c1DapPotEuxwOACc=",
  "sign_text": "0123456789abcdef0123456789abcdef|10.147.20.5|10.147.20.9|1790000000000|Hallo Test|Hallo Test\nZeile 2 mit Umlaut: äöü ß \\ Backslash",
  "signature_b64": "kmJSwG8jnFjodKyMWuAMlv04l0p91HBToIixwPpp7yUGx68mK9numVFeIcS1h6z5zf896ECHFTTunlZuEUmV3TmgmxcjO1ZerCA3OtnSLh6E6lJFVtr8azaPNkZjEuoVrrnIs+Q9mY1OkdEpDC8jxw4Z0BwCXOOv9w7qF9e4KfvZWWJALazyf77IPwFWGSup9AC6kqnqIdfxrG40JVVXA7E9v1qFoGzeh4zTSnwrreybIbNl7L0/NsMwe/5ENWpH9/xObYMRYGwmB5d/EasJ1RsYAJ2patrtlBrXYAok/7C0r4cw4wU+8S3JMVUlnSA4maWMeh0W95xhJuqr05q92A==",
  "signature_verifies": true,
  "inner_plaintext": "PEMSG1\nId=0123456789abcdef0123456789abcdef\nFromName=Alex-PC\nFromIp=10.147.20.5\nToName=\nToIp=10.147.20.9\nSubject=Hallo Test\nCreatedUtc=1790000000000\nReceivedUtc=0\nDeliveredUtc=0\nRead=0\nVia=\nVerified=0\nAttempts=0\nNextTryUtc=0\nLastError=\nRelayed=0\nRelayedTo=\nExpiresUtc=0\nBlob=kmJSwG8jnFjodKyMWuAMlv04l0p91HBToIixwPpp7yUGx68mK9numVFeIcS1h6z5zf896ECHFTTunlZuEUmV3TmgmxcjO1ZerCA3OtnSLh6E6lJFVtr8azaPNkZjEuoVrrnIs+Q9mY1OkdEpDC8jxw4Z0BwCXOOv9w7qF9e4KfvZWWJALazyf77IPwFWGSup9AC6kqnqIdfxrG40JVVXA7E9v1qFoGzeh4zTSnwrreybIbNl7L0/NsMwe/5ENWpH9/xObYMRYGwmB5d/EasJ1RsYAJ2patrtlBrXYAok/7C0r4cw4wU+8S3JMVUlnSA4maWMeh0W95xhJuqr05q92A==\nBody=Hallo Test\\nZeile 2 mit Umlaut: äöü ß \\\\ Backslash\n",
  "sealed_blob_b64": "AQEAMRnj5Z3Z9Zq0KcMkr0SygHhMJBnNIYx1DbN97N7/egc0C3yGUdAHhKDOsj87eSMMhudPt81JQszXow6ru2FJgDYz5wi2Wj5yK0KfW8IMgAEUvt5ySNXiOyvwyUo/3SZZQ73bbEx4dlGpn0w+X9FhsFe+W33Mj++eIilEzQwMfu7E4JkieoOZ6hWxnFGrhENLga8RoQZt5U/aHrmNyP5Y5wwcX9OhwJx5z/DP2A9UlE+/DL/CV60FakL23SrfuXY81e7qCoPtYyGO8J3exC7nH8s/smlVOPtZk5DBmi6sIxbrJwbPzED5H5AdfQtPK6uZT4nJIQP43+dUdMiiSP/JdK5eq8Q/WgZcTn9iCHvEQIJ9XBYIfFvF/y2Z6pYE1Cj4NkiAMo/PhxsR2XDn+F+VJb5SporR6qeZZ6tRrY8TgPaNYUAFuk7xfq8a2bSffsegdHFxSm44a/S5frQz2FxSUIiNZc3o/gM2iZDpl8xR0Uf9F2NpLj/yj/qVX9o1qKM7YJLIjxpy6nT/5cAWafJCf5ZYmulAs6Yvm2Sp7jFxngweoUklJz4hfFpbYPPRG9p4u9K7rwxrKy0r/8uOzmzAIjToLRtNFRIHPn/gltxu8ttwIbRdNh8Td5439ChiiVHLCewmDf5O2eRePrlaq/21NTp6mXZSLJtUtIhPgsadipT53AEyZDPtTNK/AwHf0X5vzksf4W5jD78/t+NdEORStSK18hHSL/HjCH0eBNfY+NSAnt2nIym0Sn3A+0TjKWOLbcEfuIaW3LFXvc2kKFJGAg0wWIDEi2pLJCPPBoP7e8IS/mlqlDxQkr37O/f6w+WzUL13NWKzowacO8h0QENyhWc0IyG23DjaySBRaGexvwAa2hftUNZmfegRK68NZX1C9K1e4c2bIzk4pKfdRMhqfAdU7YNfLgiUfNHyewGZHBjs4+Q2YqiyZS7Ysu5GB9f7Ut/3us6GoUtOpGewVPx3trAoqAjM1JAu5NhalKaDdPrBlF5ITLWTreNQIXbWZ6IVoNHhIkhRuRgKgzFf8//MEbV4BAeMw6NTvg6A4nYHJZIins+bab4Vyr6toJWX/MjomTxLEJp29z9Eoyi2hDNymWkGy9iKw8H/XkEVBCD32x4CEpsDtEByCel5LW/elC7WRFHjhgJevHi07lnxvCLXoEaVTdsr+KpdDaf+33lzDO95wptC66N5x8jrif0vdXnpcr5yAiifNX+AcXeWBFmHUvYOwM4IalBzGg59nPv+Gx/bIiCMGfM+j5oxA9cSfo/M5FgObUCx72+x38OpGxgh+9u/+j6PQ0AYIZDitzIoYIc=",
  "sealed_open_check": true,
  "blob_total_len": 995,
  "blob_version": 1,
  "blob_wrapped_len": 256,
  "blob_wrapped_hex": "3119e3e59dd9f59ab429c324af44b280784c2419cd218c750db37decdeff7a07340b7c8651d00784a0ceb23f3b79230c86e74fb7cd4942ccd7a30eabbb6149803633e708b65a3e722b429f5bc20c800114bede7248d5e23b2bf0c94a3fdd265943bddb6c4c787651a99f4c3e5fd161b057be5b7dcc8fef9e222944cd0c0c7eeec4e099227a8399ea15b19c51ab84434b81af11a1066de54fda1eb98dc8fe58e70c1c5fd3a1c09c79cff0cfd80f54944fbf0cbfc257ad056a42f6dd2adfb9763cd5eeea0a83ed63218ef09ddec42ee71fcb3fb2695538fb599390c19a2eac2316eb2706cfcc40f91f901d7d0b4f2bab994f89c92103f8dfe75474c8a248ffc974",
  "blob_iv_hex": "ae5eabc43f5a065c4e7f62087bc44082",
  "blob_mac_hex": "7d5c16087c5bc5ff2d99ea9604d428f8364880328fcf871b11d970e7f85f9525",
  "blob_cipher_hex": "be52a68ad1eaa79967ab51ad8f1380f68d614005ba4ef17eaf1ad9b49f7ec7a07471714a6e386bf4b97eb433d85c5250888d65cde8fe03368990e997cc51d147fd1763692e3ff28ffa955fda35a8a33b6092c88f1a72ea74ffe5c01669f2427f96589ae940b3a62f9b64a9ee31719e0c1ea14925273e217c5a5b60f3d11bda78bbd2bbaf0c6b2b2d2bffcb8ece6cc02234e82d1b4d1512073e7fe096dc6ef2db7021b45d361f13779e37f428628951cb09ec260dfe4ed9e45e3eb95aabfdb5353a7a9976522c9b54b4884f82c69d8a94f9dc01326433ed4cd2bf0301dfd17e6fce4b1fe16e630fbf3fb7e35d10e452b522b5f211d22ff1e3087d1e04d7d8f8d4809edda72329b44a7dc0fb44e329638b6dc11fb88696dcb157bdcda4285246020d305880c48b6a4b2423cf0683fb7bc212fe696a943c5092bdfb3bf7fac3e5b350bd773562b3a3069c3bc8744043728567342321b6dc38dac920516867b1bf001ada17ed50d6667de8112baf0d657d42f4ad5ee1cd9b233938a4a7dd44c86a7c0754ed835f2e08947cd1f27b01991c18ece3e43662a8b2652ed8b2ee4607d7fb52dff7bace86a14b4ea467b054fc77b6b028a808ccd4902ee4d85a94a68374fac1945e484cb593ade3502176d667a215a0d1e1224851b9180a83315ff3ffcc11b57804078cc3a353be0e80e276072592229ecf9b69be15cabeada09597fcc8e8993c4b109a76f73f44a328b6843372996906cbd88ac3c1ff5e41150420f7db1e02129b03b4407209e9792d6fde942ed64451e386025ebc78b4ee59f1bc22d7a046954ddb2bf8aa5d0da7fedf79730cef79c29b42eba379c7c8eb89fd2f7579e972be7202289f357f8071779604598752f60ec0ce086a50731a0e7d9cfbfe1b1fdb22208c19f33e8f9a3103d7127e8fcce4580e6d40b1ef6fb1dfc3a91b1821fbdbbffa3e8f4340182190e2b732286087",
  "blob_unwrapped_aes_key_hex": "a810e61c94a0b21f5ccbd59dc9cfb112901ca59fe15acdd29eb48c6a86b46555",
  "blob_unwrapped_mac_key_hex": "1e7e395b54cb2b42705f814da326354ba4d16ba5396267f0214514cb81c5a91e",
  "inner_plaintext_utf8_len": 679,
  "relay_line": "PEMAIL1|RELAY|0123456789abcdef0123456789abcdef|10.147.20.9|1790000000000|1791209600000|AQEAMRnj5Z3Z9Zq0KcMkr0SygHhMJBnNIYx1DbN97N7/egc0C3yGUdAHhKDOsj87eSMMhudPt81JQszXow6ru2FJgDYz5wi2Wj5yK0KfW8IMgAEUvt5ySNXiOyvwyUo/3SZZQ73bbEx4dlGpn0w+X9FhsFe+W33Mj++eIilEzQwMfu7E4JkieoOZ6hWxnFGrhENLga8RoQZt5U/aHrmNyP5Y5wwcX9OhwJx5z/DP2A9UlE+/DL/CV60FakL23SrfuXY81e7qCoPtYyGO8J3exC7nH8s/smlVOPtZk5DBmi6sIxbrJwbPzED5H5AdfQtPK6uZT4nJIQP43+dUdMiiSP/JdK5eq8Q/WgZcTn9iCHvEQIJ9XBYIfFvF/y2Z6pYE1Cj4NkiAMo/PhxsR2XDn+F+VJb5SporR6qeZZ6tRrY8TgPaNYUAFuk7xfq8a2bSffsegdHFxSm44a/S5frQz2FxSUIiNZc3o/gM2iZDpl8xR0Uf9F2NpLj/yj/qVX9o1qKM7YJLIjxpy6nT/5cAWafJCf5ZYmulAs6Yvm2Sp7jFxngweoUklJz4hfFpbYPPRG9p4u9K7rwxrKy0r/8uOzmzAIjToLRtNFRIHPn/gltxu8ttwIbRdNh8Td5439ChiiVHLCewmDf5O2eRePrlaq/21NTp6mXZSLJtUtIhPgsadipT53AEyZDPtTNK/AwHf0X5vzksf4W5jD78/t+NdEORStSK18hHSL/HjCH0eBNfY+NSAnt2nIym0Sn3A+0TjKWOLbcEfuIaW3LFXvc2kKFJGAg0wWIDEi2pLJCPPBoP7e8IS/mlqlDxQkr37O/f6w+WzUL13NWKzowacO8h0QENyhWc0IyG23DjaySBRaGexvwAa2hftUNZmfegRK68NZX1C9K1e4c2bIzk4pKfdRMhqfAdU7YNfLgiUfNHyewGZHBjs4+Q2YqiyZS7Ysu5GB9f7Ut/3us6GoUtOpGewVPx3trAoqAjM1JAu5NhalKaDdPrBlF5ITLWTreNQIXbWZ6IVoNHhIkhRuRgKgzFf8//MEbV4BAeMw6NTvg6A4nYHJZIins+bab4Vyr6toJWX/MjomTxLEJp29z9Eoyi2hDNymWkGy9iKw8H/XkEVBCD32x4CEpsDtEByCel5LW/elC7WRFHjhgJevHi07lnxvCLXoEaVTdsr+KpdDaf+33lzDO95wptC66N5x8jrif0vdXnpcr5yAiifNX+AcXeWBFmHUvYOwM4IalBzGg59nPv+Gx/bIiCMGfM+j5oxA9cSfo/M5FgObUCx72+x38OpGxgh+9u/+j6PQ0AYIZDitzIoYIc=|Uy4B8VjPjt6YmsFJesTrwRmmr9TECb9McVmVwB+2yFM=",
  "sealed_line": "PEMAIL1|SEALED|0123456789abcdef0123456789abcdef|10.147.20.9|AQEAMRnj5Z3Z9Zq0KcMkr0SygHhMJBnNIYx1DbN97N7/egc0C3yGUdAHhKDOsj87eSMMhudPt81JQszXow6ru2FJgDYz5wi2Wj5yK0KfW8IMgAEUvt5ySNXiOyvwyUo/3SZZQ73bbEx4dlGpn0w+X9FhsFe+W33Mj++eIilEzQwMfu7E4JkieoOZ6hWxnFGrhENLga8RoQZt5U/aHrmNyP5Y5wwcX9OhwJx5z/DP2A9UlE+/DL/CV60FakL23SrfuXY81e7qCoPtYyGO8J3exC7nH8s/smlVOPtZk5DBmi6sIxbrJwbPzED5H5AdfQtPK6uZT4nJIQP43+dUdMiiSP/JdK5eq8Q/WgZcTn9iCHvEQIJ9XBYIfFvF/y2Z6pYE1Cj4NkiAMo/PhxsR2XDn+F+VJb5SporR6qeZZ6tRrY8TgPaNYUAFuk7xfq8a2bSffsegdHFxSm44a/S5frQz2FxSUIiNZc3o/gM2iZDpl8xR0Uf9F2NpLj/yj/qVX9o1qKM7YJLIjxpy6nT/5cAWafJCf5ZYmulAs6Yvm2Sp7jFxngweoUklJz4hfFpbYPPRG9p4u9K7rwxrKy0r/8uOzmzAIjToLRtNFRIHPn/gltxu8ttwIbRdNh8Td5439ChiiVHLCewmDf5O2eRePrlaq/21NTp6mXZSLJtUtIhPgsadipT53AEyZDPtTNK/AwHf0X5vzksf4W5jD78/t+NdEORStSK18hHSL/HjCH0eBNfY+NSAnt2nIym0Sn3A+0TjKWOLbcEfuIaW3LFXvc2kKFJGAg0wWIDEi2pLJCPPBoP7e8IS/mlqlDxQkr37O/f6w+WzUL13NWKzowacO8h0QENyhWc0IyG23DjaySBRaGexvwAa2hftUNZmfegRK68NZX1C9K1e4c2bIzk4pKfdRMhqfAdU7YNfLgiUfNHyewGZHBjs4+Q2YqiyZS7Ysu5GB9f7Ut/3us6GoUtOpGewVPx3trAoqAjM1JAu5NhalKaDdPrBlF5ITLWTreNQIXbWZ6IVoNHhIkhRuRgKgzFf8//MEbV4BAeMw6NTvg6A4nYHJZIins+bab4Vyr6toJWX/MjomTxLEJp29z9Eoyi2hDNymWkGy9iKw8H/XkEVBCD32x4CEpsDtEByCel5LW/elC7WRFHjhgJevHi07lnxvCLXoEaVTdsr+KpdDaf+33lzDO95wptC66N5x8jrif0vdXnpcr5yAiifNX+AcXeWBFmHUvYOwM4IalBzGg59nPv+Gx/bIiCMGfM+j5oxA9cSfo/M5FgObUCx72+x38OpGxgh+9u/+j6PQ0AYIZDitzIoYIc=|Q2Fyb2wtUEM=|sTo6Veg2g2mlXqz/hVSvAc4zBPC8BJdVzxxBdziE2c0=",
  "recv_msg_reply": "OK",
  "recv_msg_reply_again": "DUP",
  "recv_inbox_file_direct": "PEMSG1\nId=0123456789abcdef0123456789abcdef\nFromName=Alex-PC\nFromIp=10.147.20.5\nToName=\nToIp=10.147.20.9\nSubject=Hallo Test\nCreatedUtc=1790000000000\nReceivedUtc=1790195391137\nDeliveredUtc=0\nRead=0\nVia=direkt\nVerified=1\nAttempts=0\nNextTryUtc=0\nLastError=\nRelayed=0\nRelayedTo=\nExpiresUtc=0\nBlob=\nBody=Hallo Test\\nZeile 2 mit Umlaut: äöü ß \\\\ Backslash\n",
  "recv_sealed_reply": "DUP",
  "recv_bad_hmac_reply": "ERR|format",
  "recv_notme_reply": "NOTME",
  "seen_file": "0123456789abcdef0123456789abcdef\n",
  "recv_sealed2_reply": "OK",
  "recv_inbox_file_sealed": "PEMSG1\nId=fedcba9876543210fedcba9876543210\nFromName=Alex-PC\nFromIp=10.147.20.5\nToName=\nToIp=10.147.20.9\nSubject=Hallo Test\nCreatedUtc=1790000000000\nReceivedUtc=1790195391181\nDeliveredUtc=0\nRead=0\nVia=weitergeleitet über Carol-PC (10.147.20.3)\nVerified=1\nAttempts=0\nNextTryUtc=0\nLastError=\nRelayed=0\nRelayedTo=\nExpiresUtc=0\nBlob=\nBody=Hallo Test\\nZeile 2 mit Umlaut: äöü ß \\\\ Backslash\n",
  "holder_relay_reply": "OK",
  "holder_relay_file": "PEMSG1\nId=0000000000000000000000000000abcd\nFromName=\nFromIp=10.147.20.5\nToName=\nToIp=10.147.20.9\nSubject=\nCreatedUtc=1790000000000\nReceivedUtc=1790195391186\nDeliveredUtc=0\nRead=0\nVia=\nVerified=0\nAttempts=0\nNextTryUtc=1790195394186\nLastError=\nRelayed=0\nRelayedTo=\nExpiresUtc=1791209600000\nBlob=AQEAMRnj5Z3Z9Zq0KcMkr0SygHhMJBnNIYx1DbN97N7/egc0C3yGUdAHhKDOsj87eSMMhudPt81JQszXow6ru2FJgDYz5wi2Wj5yK0KfW8IMgAEUvt5ySNXiOyvwyUo/3SZZQ73bbEx4dlGpn0w+X9FhsFe+W33Mj++eIilEzQwMfu7E4JkieoOZ6hWxnFGrhENLga8RoQZt5U/aHrmNyP5Y5wwcX9OhwJx5z/DP2A9UlE+/DL/CV60FakL23SrfuXY81e7qCoPtYyGO8J3exC7nH8s/smlVOPtZk5DBmi6sIxbrJwbPzED5H5AdfQtPK6uZT4nJIQP43+dUdMiiSP/JdK5eq8Q/WgZcTn9iCHvEQIJ9XBYIfFvF/y2Z6pYE1Cj4NkiAMo/PhxsR2XDn+F+VJb5SporR6qeZZ6tRrY8TgPaNYUAFuk7xfq8a2bSffsegdHFxSm44a/S5frQz2FxSUIiNZc3o/gM2iZDpl8xR0Uf9F2NpLj/yj/qVX9o1qKM7YJLIjxpy6nT/5cAWafJCf5ZYmulAs6Yvm2Sp7jFxngweoUklJz4hfFpbYPPRG9p4u9K7rwxrKy0r/8uOzmzAIjToLRtNFRIHPn/gltxu8ttwIbRdNh8Td5439ChiiVHLCewmDf5O2eRePrlaq/21NTp6mXZSLJtUtIhPgsadipT53AEyZDPtTNK/AwHf0X5vzksf4W5jD78/t+NdEORStSK18hHSL/HjCH0eBNfY+NSAnt2nIym0Sn3A+0TjKWOLbcEfuIaW3LFXvc2kKFJGAg0wWIDEi2pLJCPPBoP7e8IS/mlqlDxQkr37O/f6w+WzUL13NWKzowacO8h0QENyhWc0IyG23DjaySBRaGexvwAa2hftUNZmfegRK68NZX1C9K1e4c2bIzk4pKfdRMhqfAdU7YNfLgiUfNHyewGZHBjs4+Q2YqiyZS7Ysu5GB9f7Ut/3us6GoUtOpGewVPx3trAoqAjM1JAu5NhalKaDdPrBlF5ITLWTreNQIXbWZ6IVoNHhIkhRuRgKgzFf8//MEbV4BAeMw6NTvg6A4nYHJZIins+bab4Vyr6toJWX/MjomTxLEJp29z9Eoyi2hDNymWkGy9iKw8H/XkEVBCD32x4CEpsDtEByCel5LW/elC7WRFHjhgJevHi07lnxvCLXoEaVTdsr+KpdDaf+33lzDO95wptC66N5x8jrif0vdXnpcr5yAiifNX+AcXeWBFmHUvYOwM4IalBzGg59nPv+Gx/bIiCMGfM+j5oxA9cSfo/M5FgObUCx72+x38OpGxgh+9u/+j6PQ0AYIZDitzIoYIc=\nBody=\n"
}

```

Reverse-direction vector (sealed by the independent Python implementation, accepted by the C# node over TCP): see `tv/reverse.json`.
