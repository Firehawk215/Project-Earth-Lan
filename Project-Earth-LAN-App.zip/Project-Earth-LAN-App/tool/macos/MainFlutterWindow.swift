import AVFoundation
import Cocoa
import FlutterMacOS

// Hauptfenster + Kanaele fuer den Voice-Chat (Mikrofon/Lautsprecher, 16 kHz mono 16 Bit).
class MainFlutterWindow: NSWindow {
  private let pelAudio = PelAudio()

  override func awakeFromNib() {
    let flutterViewController = FlutterViewController()
    let windowFrame = self.frame
    self.contentViewController = flutterViewController
    self.setFrame(windowFrame, display: true)

    RegisterGeneratedPlugins(registry: flutterViewController)

    let messenger = flutterViewController.engine.binaryMessenger
    let audio = pelAudio
    let channel = FlutterMethodChannel(name: "projectearthlan/audio", binaryMessenger: messenger)
    channel.setMethodCallHandler { call, result in
      switch call.method {
      case "start":
        audio.start(result: result)
      case "stop":
        audio.stop()
        result(nil)
      case "play":
        if let d = call.arguments as? FlutterStandardTypedData {
          audio.play(d.data)
        }
        result(nil)
      default:
        result(FlutterMethodNotImplemented)
      }
    }
    let events = FlutterEventChannel(name: "projectearthlan/audio_in", binaryMessenger: messenger)
    events.setStreamHandler(audio)

    super.awakeFromNib()
  }
}

class PelAudio: NSObject, FlutterStreamHandler {
  private let engine = AVAudioEngine()
  private let player = AVAudioPlayerNode()
  private var sink: FlutterEventSink?
  private var converter: AVAudioConverter?
  private var running = false
  private let outFormat = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 16000, channels: 1, interleaved: true)!
  private let playFormat = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: 16000, channels: 1, interleaved: false)!

  func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
    sink = events
    return nil
  }

  func onCancel(withArguments arguments: Any?) -> FlutterError? {
    sink = nil
    return nil
  }

  func start(result: @escaping FlutterResult) {
    switch AVCaptureDevice.authorizationStatus(for: .audio) {
    case .authorized:
      startEngine(result)
    case .notDetermined:
      AVCaptureDevice.requestAccess(for: .audio) { ok in
        DispatchQueue.main.async {
          if ok {
            self.startEngine(result)
          } else {
            result(FlutterError(code: "PERM", message: "Kein Mikrofonzugriff", details: nil))
          }
        }
      }
    default:
      result(FlutterError(code: "PERM", message: "Mikrofonzugriff unter Systemeinstellungen > Datenschutz > Mikrofon erlauben", details: nil))
    }
  }

  private func startEngine(_ result: FlutterResult) {
    if running {
      result(nil)
      return
    }
    let input = engine.inputNode
    let inFormat = input.outputFormat(forBus: 0)
    guard inFormat.sampleRate > 0, let conv = AVAudioConverter(from: inFormat, to: outFormat) else {
      result(FlutterError(code: "AUDIO", message: "Kein Mikrofon gefunden", details: nil))
      return
    }
    converter = conv
    input.installTap(onBus: 0, bufferSize: 1024, format: inFormat) { [weak self] buffer, _ in
      self?.handle(buffer)
    }
    engine.attach(player)
    engine.connect(player, to: engine.mainMixerNode, format: playFormat)
    do {
      try engine.start()
      player.play()
      running = true
      result(nil)
    } catch {
      input.removeTap(onBus: 0)
      engine.detach(player)
      result(FlutterError(code: "AUDIO", message: error.localizedDescription, details: nil))
    }
  }

  private func handle(_ buffer: AVAudioPCMBuffer) {
    guard let conv = converter else { return }
    let ratio = outFormat.sampleRate / buffer.format.sampleRate
    let capacity = AVAudioFrameCount(Double(buffer.frameLength) * ratio) + 64
    guard let out = AVAudioPCMBuffer(pcmFormat: outFormat, frameCapacity: capacity) else { return }
    var fed = false
    var error: NSError?
    _ = conv.convert(to: out, error: &error) { _, status in
      if fed {
        status.pointee = .noDataNow
        return nil
      }
      fed = true
      status.pointee = .haveData
      return buffer
    }
    let n = Int(out.frameLength)
    guard n > 0, let ch = out.int16ChannelData else { return }
    let data = Data(bytes: ch[0], count: n * 2)
    DispatchQueue.main.async {
      self.sink?(FlutterStandardTypedData(bytes: data))
    }
  }

  func play(_ data: Data) {
    guard running else { return }
    let n = data.count / 2
    guard n > 0, let buf = AVAudioPCMBuffer(pcmFormat: playFormat, frameCapacity: AVAudioFrameCount(n)),
          let dst = buf.floatChannelData?[0] else { return }
    buf.frameLength = AVAudioFrameCount(n)
    let bytes = [UInt8](data)
    for i in 0..<n {
      let v = Int16(bitPattern: UInt16(bytes[2 * i]) | (UInt16(bytes[2 * i + 1]) << 8))
      dst[i] = Float(v) / 32768.0
    }
    player.scheduleBuffer(buf, completionHandler: nil)
  }

  func stop() {
    if !running { return }
    engine.inputNode.removeTap(onBus: 0)
    player.stop()
    engine.stop()
    engine.detach(player)
    running = false
  }
}
