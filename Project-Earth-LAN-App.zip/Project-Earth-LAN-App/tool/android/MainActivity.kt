package de.projectearthlan.project_earth_lan

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

// 1. MulticastLock: ohne ihn verwirft Android UDP-Broadcasts (Live-Status, Beacons).
// 2. Voice-Chat: Mikrofon/Lautsprecher mit 16 kHz, mono, 16 Bit.
class MainActivity : FlutterActivity() {
    private var lock: WifiManager.MulticastLock? = null

    private val main = Handler(Looper.getMainLooper())
    private var sink: EventChannel.EventSink? = null
    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile private var audioRunning = false
    private val playQueue = LinkedBlockingQueue<ByteArray>()
    private var pendingStart: MethodChannel.Result? = null
    private var session = 0
    @Volatile private var activeSession = 0

    companion object {
        const val RATE = 16000
        const val PERM_REQUEST = 4711
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "projectearthlan/net").setMethodCallHandler { call, result ->
            if (call.method == "multicastLock") {
                try {
                    if (lock == null) {
                        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                        lock = wifi.createMulticastLock("ProjectEarthLan").apply {
                            setReferenceCounted(false)
                            acquire()
                        }
                    }
                    result.success(null)
                } catch (e: Exception) {
                    result.error("LOCK", e.message, null)
                }
            } else {
                result.notImplemented()
            }
        }

        MethodChannel(messenger, "projectearthlan/audio").setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> startAudioChecked(result)
                "stop" -> {
                    stopAudio()
                    result.success(null)
                }
                "play" -> {
                    val data = call.arguments as? ByteArray
                    if (data != null && audioRunning) {
                        if (playQueue.size > 25) playQueue.clear()
                        playQueue.offer(data)
                    }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        EventChannel(messenger, "projectearthlan/audio_in").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                sink = events
            }

            override fun onCancel(arguments: Any?) {
                sink = null
            }
        })
    }

    private fun hasMicPermission(): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startAudioChecked(result: MethodChannel.Result) {
        if (hasMicPermission()) {
            startAudio(result)
            return
        }
        pendingStart?.error("BUSY", "Berechtigungsanfrage läuft bereits", null)
        pendingStart = result
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), PERM_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != PERM_REQUEST) return
        val r = pendingStart ?: return
        pendingStart = null
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startAudio(r)
        } else {
            r.error("PERM", "Kein Mikrofonzugriff - bitte in den Android-Einstellungen erlauben.", null)
        }
    }

    @Suppress("DEPRECATION")
    private fun startAudio(result: MethodChannel.Result) {
        if (audioRunning) {
            result.success(null)
            return
        }
        try {
            val inMin = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(inMin, 640 * 8)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                result.error("AUDIO", "Mikrofon konnte nicht geöffnet werden.", null)
                return
            }
            val outMin = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val trk = AudioTrack(
                AudioManager.STREAM_MUSIC, RATE, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(outMin, 640 * 6), AudioTrack.MODE_STREAM
            )
            recorder = rec
            track = trk
            val my = ++session
            activeSession = my
            audioRunning = true
            playQueue.clear()
            rec.startRecording()
            trk.play()

            Thread {
                val buf = ByteArray(640)
                while (audioRunning && activeSession == my) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    if (n > 0) {
                        val copy = buf.copyOf(n)
                        main.post { sink?.success(copy) }
                    }
                }
            }.start()

            Thread {
                while (audioRunning && activeSession == my) {
                    val d = playQueue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    try {
                        trk.write(d, 0, d.size)
                    } catch (e: Exception) {
                    }
                }
            }.start()

            result.success(null)
        } catch (e: Exception) {
            stopAudio()
            result.error("AUDIO", e.message, null)
        }
    }

    private fun stopAudio() {
        audioRunning = false
        try { recorder?.stop() } catch (e: Exception) {}
        try { recorder?.release() } catch (e: Exception) {}
        try { track?.stop() } catch (e: Exception) {}
        try { track?.release() } catch (e: Exception) {}
        recorder = null
        track = null
        playQueue.clear()
    }

    override fun onDestroy() {
        stopAudio()
        try { lock?.release() } catch (e: Exception) {}
        super.onDestroy()
    }
}
