#!/usr/bin/env python3
"""Passt die von `flutter create` erzeugten Plattform-Ordner an:
   - Android: Netzwerk-Rechte, MulticastLock (MainActivity), App-Name
   - macOS:   Netzwerk-Client/-Server und Dateizugriff in den Entitlements, App-Name
   - Linux:   Fenstertitel
Wird von der GitHub-Action nach `flutter create` aufgerufen (auch lokal nutzbar)."""
import pathlib
import plistlib
import re
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
APP_NAME = "Project Earth LAN"


def android():
    man = ROOT / "android/app/src/main/AndroidManifest.xml"
    if not man.exists():
        print("Android: kein Manifest (Plattform nicht erzeugt)")
        return
    t = man.read_text(encoding="utf-8")
    perms = [
        "android.permission.INTERNET",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.ACCESS_WIFI_STATE",
        "android.permission.CHANGE_WIFI_MULTICAST_STATE",
        "android.permission.RECORD_AUDIO",
        "android.permission.MODIFY_AUDIO_SETTINGS",
    ]
    add = "".join(f'    <uses-permission android:name="{p}"/>\n' for p in perms if p not in t)
    if add:
        t = re.sub(r"(<manifest[^>]*>\s*\n)", r"\g<1>" + add, t, count=1)
    t = re.sub(r'android:label="[^"]*"', f'android:label="{APP_NAME}"', t, count=1)
    if "usesCleartextTraffic" not in t:  # ZTNET-Panel laeuft ueber http://
        t = t.replace("<application", '<application\n        android:usesCleartextTraffic="true"', 1)
    man.write_text(t, encoding="utf-8")
    kt_dir = ROOT / "android/app/src/main/kotlin/de/projectearthlan/project_earth_lan"
    kt_dir.mkdir(parents=True, exist_ok=True)
    for old in kt_dir.glob("MainActivity.*"):
        old.unlink()
    shutil.copy(ROOT / "tool/android/MainActivity.kt", kt_dir / "MainActivity.kt")
    print("Android angepasst")


def macos():
    base = ROOT / "macos/Runner"
    if not base.exists():
        print("macOS: nicht erzeugt")
        return
    for name in ("DebugProfile.entitlements", "Release.entitlements"):
        p = base / name
        d = plistlib.loads(p.read_bytes()) if p.exists() else {}
        # Ohne Sandbox: sonst duerfte die App zerotier-cli nicht aufrufen und nur
        # eingeschraenkt auf Ordner zugreifen (kein App-Store-Vertrieb geplant).
        d["com.apple.security.app-sandbox"] = False
        d["com.apple.security.network.client"] = True
        d["com.apple.security.network.server"] = True
        d["com.apple.security.files.user-selected.read-write"] = True
        d["com.apple.security.files.downloads.read-write"] = True
        d["com.apple.security.device.audio-input"] = True
        p.write_bytes(plistlib.dumps(d))
    info = base / "Info.plist"
    if info.exists():
        d = plistlib.loads(info.read_bytes())
        d["NSMicrophoneUsageDescription"] = "Das Mikrofon wird fuer den Voice-Chat mit deinen Mitspielern gebraucht."
        info.write_bytes(plistlib.dumps(d))
    shutil.copy(ROOT / "tool/macos/MainFlutterWindow.swift", base / "MainFlutterWindow.swift")
    cfg = base / "Configs/AppInfo.xcconfig"
    if cfg.exists():
        t = cfg.read_text(encoding="utf-8")
        t = re.sub(r"PRODUCT_NAME = .*", f"PRODUCT_NAME = {APP_NAME}", t)
        cfg.write_text(t, encoding="utf-8")
    print("macOS angepasst")


def linux():
    cc = ROOT / "linux/runner/my_application.cc"
    if not cc.exists():
        cc = ROOT / "linux/my_application.cc"
    if not cc.exists():
        print("Linux: nicht erzeugt")
        return
    t = cc.read_text(encoding="utf-8")
    t = t.replace('"project_earth_lan"', f'"{APP_NAME}"')
    t = t.replace("gtk_window_set_default_size(window, 1280, 720)", "gtk_window_set_default_size(window, 1200, 800)")
    cc.write_text(t, encoding="utf-8")
    print("Linux angepasst")


if __name__ == "__main__":
    which = sys.argv[1:] or ["android", "macos", "linux"]
    for w in which:
        {"android": android, "macos": macos, "linux": linux}[w]()
