# Project Earth LAN Manager – Android, Linux & macOS

Eine eigene App für Android, Linux und macOS. Sie spielt **im selben Netz mit den
Windows-Managern zusammen**: gleiches Protokoll, gleiche Ports, gleicher Netzwerk-Code.
Ein Windows-Spieler sieht dich also im Live-Status, kann mit dir chatten, dir Dateien
schicken und ins Postfach schreiben – und umgekehrt.

## Was die App kann

| Bereich | Funktion | Windows-Gegenstück |
|---|---|---|
| **Live** | Wer ist online, wer spielt was (UDP 9928), selbst ein Spiel melden, Spieleabende sehen/planen/absagen, ZeroTier beitreten | Control Center |
| **Chat** | Gruppenchat, Privatnachrichten, Kanäle, automatische Suche im Netz (TCP 9874) | Option 10 – Text Chat |
| **Voice** | Sprach-Kanäle (auch mit Passwort), Privatgespräche (Anruf annehmen/ablehnen), Sprach-Erkennung oder Push-to-Talk, Lautstärke je Teilnehmer, Ping-Anzeige (UDP 9873, 16 kHz) | Option 10 – Voice |
| **Dateien** | Dateien und Ordner senden/empfangen, 2-MB-Stücke mit SHA-256, parallele Verbindungen, Fortsetzen nach Abbruch, Tempolimit (TCP 9876) | Option 10 – Dateien |
| **Postfach** | Nachrichten wie E-Mail, auch an Offline-Spieler (verschlüsselt über andere Manager weitergeleitet, bis 14 Tage) (TCP 9929) | Option 11 – Postfach |
| **Netzwerke** | Eigene ZeroTier-Netzwerke im ZTNET-Panel erstellen und verwalten, Mitglieder freischalten/sperren/umbenennen/entfernen, Token wird gespeichert | Option 13 |

**Noch nicht dabei**: Server-Browser (Option 9),
automatische Spiele-Erkennung, Spiele-Verknüpfungen, Kanal-Abgleich (Port 9776).
Firewall, Remotedesktop, Autostart und Registry gibt es auf diesen Systemen so nicht.

## So kommst du an die fertigen Dateien (ohne etwas zu installieren)

1. Neues GitHub-Repository anlegen (z. B. `Project-Earth-LAN-App`) und den **Inhalt
   dieses Ordners** hochladen – inklusive des versteckten Ordners `.github`.
2. **Netzwerk-Code hinterlegen:** im Repository unter *Settings → Secrets and variables →
   Actions → New repository secret* ein Secret mit Namen `PEL_NETWORK_CODE` anlegen und
   denselben Code eintragen, der auch in den Windows-Managern steht.
   (Ohne Secret fragt die App beim ersten Start nach dem Code.)
3. Unter *Actions* läuft der Build automatisch an (ca. 10–15 Minuten). Danach beim Lauf
   unten unter **Artifacts**:
   - `ProjectEarthLAN-Android` → `.apk` aufs Handy, installieren („Unbekannte Quellen“ erlauben)
   - `ProjectEarthLAN-Linux` → entpacken, `project_earth_lan` starten
   - `ProjectEarthLAN-macOS` → entpacken, **Rechtsklick → Öffnen** (die App ist nicht bei Apple signiert)
4. **Release mit Download-Links:** einen Tag wie `v2026.09.23` pushen
   (oder auf GitHub *Releases → Draft a new release* mit diesem Tag). Dann hängt die
   Action alle drei Dateien automatisch an das Release.

Der erste Schritt der Action prüft den Code und rechnet die echten Testpakete des
Windows-Managers nach (Live-Status, Spieleabende, Postfach inkl. Verschlüsselung und
Signatur). Schlägt dieser Schritt fehl, wird nichts gebaut – dann die Fehlermeldung
aus dem Log schicken.

## Wichtig zum Netzwerk

- **ZeroTier muss verbunden sein** (Netzwerk `091f0945fc5012f1`).
  - Linux/macOS: Button „Project Earth LAN beitreten“ im Reiter *Live* (fragt nach dem Admin-Passwort).
  - Android: ZeroTier läuft als eigene App (VPN) – dort dem Netzwerk beitreten.
- Die App nimmt automatisch den ZeroTier-Adapter. Falls nicht: *Einstellungen → Netzwerkadapter*.
- **Android:** Über das ZeroTier-VPN kommen Broadcasts nicht immer an. Dann in den
  Einstellungen unter „Feste Mitspieler-IPs“ die ZeroTier-IPs der anderen eintragen –
  der Live-Status geht dann zusätzlich direkt an diese IPs. Chat findet Mitspieler
  zusätzlich durch eine Suche im Netz.
- Der **Netzwerk-Code** muss exakt derselbe sein wie in den Windows-Builds, sonst
  ignorieren sich beide Seiten (Live-Status, Spieleabende, Postfach). Chat und Dateien
  funktionieren auch ohne passenden Code.
- Der Code steckt – genau wie in der Windows-.exe – in der App und kann ausgelesen
  werden. Er hält Fremd-Software fern, ist aber kein echter Zugangsschutz.

## Voice-Chat – was man wissen sollte

- Beim ersten „Audio starten“ fragen Android und macOS nach dem Mikrofon – erlauben.
- **Linux** nutzt `parec`/`pacat` (Paket `pulseaudio-utils`, bei PipeWire meist schon da)
  oder ersatzweise `arecord`/`aplay` (`alsa-utils`).
- Kopfhörer benutzen: Die App hat (wie der Windows-Manager) keine eigene Echo-Unterdrückung.
  Android schaltet bei Sprachaufnahme meist selbst eine ein.
- Die Windows-Mitspieler müssen in Option 10 den Voice-Bereich offen haben.

## Selbst bauen (optional)

```bash
flutter create --platforms=android,linux,macos --org de.projectearthlan --project-name project_earth_lan .
python3 tool/patch_platforms.py
flutter test
flutter build apk   --release --dart-define=PEL_NETWORK_CODE=DeinCode
flutter build linux --release --dart-define=PEL_NETWORK_CODE=DeinCode
flutter build macos --release --dart-define=PEL_NETWORK_CODE=DeinCode   # nur auf einem Mac
```

## Aufbau

```
lib/core/   Protokolle & Dienste (Live-Status, Chat, Dateien, Postfach, ZTNET, Netzwerk)
lib/ui/     Oberfläche (dunkles Design wie der Windows-Manager)
test/       Tests gegen echte Pakete des Windows-Managers
tool/       Anpassung der Plattform-Ordner (Rechte, MulticastLock, Entitlements)
Doku/       Genaue Beschreibung aller Protokolle (byte-genau, mit Testvektoren)
```
